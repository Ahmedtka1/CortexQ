function lm(e,t){for(var n=0;n<t.length;n++){const r=t[n];if(typeof r!="string"&&!Array.isArray(r)){for(const o in r)if(o!=="default"&&!(o in e)){const i=Object.getOwnPropertyDescriptor(r,o);i&&Object.defineProperty(e,o,i.get?i:{enumerable:!0,get:()=>r[o]})}}}return Object.freeze(Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}))}(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))r(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const s of i.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&r(s)}).observe(document,{childList:!0,subtree:!0});function n(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(o){if(o.ep)return;o.ep=!0;const i=n(o);fetch(o.href,i)}})();function am(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Id={exports:{}},Ki={},Fd={exports:{}},D={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var po=Symbol.for("react.element"),um=Symbol.for("react.portal"),cm=Symbol.for("react.fragment"),dm=Symbol.for("react.strict_mode"),fm=Symbol.for("react.profiler"),pm=Symbol.for("react.provider"),hm=Symbol.for("react.context"),mm=Symbol.for("react.forward_ref"),gm=Symbol.for("react.suspense"),ym=Symbol.for("react.memo"),vm=Symbol.for("react.lazy"),Lu=Symbol.iterator;function wm(e){return e===null||typeof e!="object"?null:(e=Lu&&e[Lu]||e["@@iterator"],typeof e=="function"?e:null)}var Md={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Bd=Object.assign,Ud={};function sr(e,t,n){this.props=e,this.context=t,this.refs=Ud,this.updater=n||Md}sr.prototype.isReactComponent={};sr.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};sr.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Hd(){}Hd.prototype=sr.prototype;function Ta(e,t,n){this.props=e,this.context=t,this.refs=Ud,this.updater=n||Md}var Ra=Ta.prototype=new Hd;Ra.constructor=Ta;Bd(Ra,sr.prototype);Ra.isPureReactComponent=!0;var zu=Array.isArray,Wd=Object.prototype.hasOwnProperty,$a={current:null},qd={key:!0,ref:!0,__self:!0,__source:!0};function Qd(e,t,n){var r,o={},i=null,s=null;if(t!=null)for(r in t.ref!==void 0&&(s=t.ref),t.key!==void 0&&(i=""+t.key),t)Wd.call(t,r)&&!qd.hasOwnProperty(r)&&(o[r]=t[r]);var l=arguments.length-2;if(l===1)o.children=n;else if(1<l){for(var a=Array(l),c=0;c<l;c++)a[c]=arguments[c+2];o.children=a}if(e&&e.defaultProps)for(r in l=e.defaultProps,l)o[r]===void 0&&(o[r]=l[r]);return{$$typeof:po,type:e,key:i,ref:s,props:o,_owner:$a.current}}function xm(e,t){return{$$typeof:po,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function _a(e){return typeof e=="object"&&e!==null&&e.$$typeof===po}function Sm(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var Du=/\/+/g;function Ps(e,t){return typeof e=="object"&&e!==null&&e.key!=null?Sm(""+e.key):t.toString(36)}function Xo(e,t,n,r,o){var i=typeof e;(i==="undefined"||i==="boolean")&&(e=null);var s=!1;if(e===null)s=!0;else switch(i){case"string":case"number":s=!0;break;case"object":switch(e.$$typeof){case po:case um:s=!0}}if(s)return s=e,o=o(s),e=r===""?"."+Ps(s,0):r,zu(o)?(n="",e!=null&&(n=e.replace(Du,"$&/")+"/"),Xo(o,t,n,"",function(c){return c})):o!=null&&(_a(o)&&(o=xm(o,n+(!o.key||s&&s.key===o.key?"":(""+o.key).replace(Du,"$&/")+"/")+e)),t.push(o)),1;if(s=0,r=r===""?".":r+":",zu(e))for(var l=0;l<e.length;l++){i=e[l];var a=r+Ps(i,l);s+=Xo(i,t,n,a,o)}else if(a=wm(e),typeof a=="function")for(e=a.call(e),l=0;!(i=e.next()).done;)i=i.value,a=r+Ps(i,l++),s+=Xo(i,t,n,a,o);else if(i==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return s}function Co(e,t,n){if(e==null)return e;var r=[],o=0;return Xo(e,r,"","",function(i){return t.call(n,i,o++)}),r}function km(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var xe={current:null},Jo={transition:null},Em={ReactCurrentDispatcher:xe,ReactCurrentBatchConfig:Jo,ReactCurrentOwner:$a};function Vd(){throw Error("act(...) is not supported in production builds of React.")}D.Children={map:Co,forEach:function(e,t,n){Co(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return Co(e,function(){t++}),t},toArray:function(e){return Co(e,function(t){return t})||[]},only:function(e){if(!_a(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};D.Component=sr;D.Fragment=cm;D.Profiler=fm;D.PureComponent=Ta;D.StrictMode=dm;D.Suspense=gm;D.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Em;D.act=Vd;D.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var r=Bd({},e.props),o=e.key,i=e.ref,s=e._owner;if(t!=null){if(t.ref!==void 0&&(i=t.ref,s=$a.current),t.key!==void 0&&(o=""+t.key),e.type&&e.type.defaultProps)var l=e.type.defaultProps;for(a in t)Wd.call(t,a)&&!qd.hasOwnProperty(a)&&(r[a]=t[a]===void 0&&l!==void 0?l[a]:t[a])}var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){l=Array(a);for(var c=0;c<a;c++)l[c]=arguments[c+2];r.children=l}return{$$typeof:po,type:e.type,key:o,ref:i,props:r,_owner:s}};D.createContext=function(e){return e={$$typeof:hm,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:pm,_context:e},e.Consumer=e};D.createElement=Qd;D.createFactory=function(e){var t=Qd.bind(null,e);return t.type=e,t};D.createRef=function(){return{current:null}};D.forwardRef=function(e){return{$$typeof:mm,render:e}};D.isValidElement=_a;D.lazy=function(e){return{$$typeof:vm,_payload:{_status:-1,_result:e},_init:km}};D.memo=function(e,t){return{$$typeof:ym,type:e,compare:t===void 0?null:t}};D.startTransition=function(e){var t=Jo.transition;Jo.transition={};try{e()}finally{Jo.transition=t}};D.unstable_act=Vd;D.useCallback=function(e,t){return xe.current.useCallback(e,t)};D.useContext=function(e){return xe.current.useContext(e)};D.useDebugValue=function(){};D.useDeferredValue=function(e){return xe.current.useDeferredValue(e)};D.useEffect=function(e,t){return xe.current.useEffect(e,t)};D.useId=function(){return xe.current.useId()};D.useImperativeHandle=function(e,t,n){return xe.current.useImperativeHandle(e,t,n)};D.useInsertionEffect=function(e,t){return xe.current.useInsertionEffect(e,t)};D.useLayoutEffect=function(e,t){return xe.current.useLayoutEffect(e,t)};D.useMemo=function(e,t){return xe.current.useMemo(e,t)};D.useReducer=function(e,t,n){return xe.current.useReducer(e,t,n)};D.useRef=function(e){return xe.current.useRef(e)};D.useState=function(e){return xe.current.useState(e)};D.useSyncExternalStore=function(e,t,n){return xe.current.useSyncExternalStore(e,t,n)};D.useTransition=function(){return xe.current.useTransition()};D.version="18.3.1";Fd.exports=D;var P=Fd.exports;const Ee=am(P),Cm=lm({__proto__:null,default:Ee},[P]);/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var jm=P,Pm=Symbol.for("react.element"),bm=Symbol.for("react.fragment"),Tm=Object.prototype.hasOwnProperty,Rm=jm.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,$m={key:!0,ref:!0,__self:!0,__source:!0};function Kd(e,t,n){var r,o={},i=null,s=null;n!==void 0&&(i=""+n),t.key!==void 0&&(i=""+t.key),t.ref!==void 0&&(s=t.ref);for(r in t)Tm.call(t,r)&&!$m.hasOwnProperty(r)&&(o[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps,t)o[r]===void 0&&(o[r]=t[r]);return{$$typeof:Pm,type:e,key:i,ref:s,props:o,_owner:Rm.current}}Ki.Fragment=bm;Ki.jsx=Kd;Ki.jsxs=Kd;Id.exports=Ki;var u=Id.exports,yl={},Gd={exports:{}},De={},Yd={exports:{}},Xd={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(R,N){var O=R.length;R.push(N);e:for(;0<O;){var U=O-1>>>1,H=R[U];if(0<o(H,N))R[U]=N,R[O]=H,O=U;else break e}}function n(R){return R.length===0?null:R[0]}function r(R){if(R.length===0)return null;var N=R[0],O=R.pop();if(O!==N){R[0]=O;e:for(var U=0,H=R.length,tn=H>>>1;U<tn;){var Qe=2*(U+1)-1,jt=R[Qe],_e=Qe+1,dt=R[_e];if(0>o(jt,O))_e<H&&0>o(dt,jt)?(R[U]=dt,R[_e]=O,U=_e):(R[U]=jt,R[Qe]=O,U=Qe);else if(_e<H&&0>o(dt,O))R[U]=dt,R[_e]=O,U=_e;else break e}}return N}function o(R,N){var O=R.sortIndex-N.sortIndex;return O!==0?O:R.id-N.id}if(typeof performance=="object"&&typeof performance.now=="function"){var i=performance;e.unstable_now=function(){return i.now()}}else{var s=Date,l=s.now();e.unstable_now=function(){return s.now()-l}}var a=[],c=[],f=1,d=null,m=3,w=!1,y=!1,v=!1,x=typeof setTimeout=="function"?setTimeout:null,h=typeof clearTimeout=="function"?clearTimeout:null,p=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function g(R){for(var N=n(c);N!==null;){if(N.callback===null)r(c);else if(N.startTime<=R)r(c),N.sortIndex=N.expirationTime,t(a,N);else break;N=n(c)}}function S(R){if(v=!1,g(R),!y)if(n(a)!==null)y=!0,hr(C);else{var N=n(c);N!==null&&en(S,N.startTime-R)}}function C(R,N){y=!1,v&&(v=!1,h(_),_=-1),w=!0;var O=m;try{for(g(N),d=n(a);d!==null&&(!(d.expirationTime>N)||R&&!$e());){var U=d.callback;if(typeof U=="function"){d.callback=null,m=d.priorityLevel;var H=U(d.expirationTime<=N);N=e.unstable_now(),typeof H=="function"?d.callback=H:d===n(a)&&r(a),g(N)}else r(a);d=n(a)}if(d!==null)var tn=!0;else{var Qe=n(c);Qe!==null&&en(S,Qe.startTime-N),tn=!1}return tn}finally{d=null,m=O,w=!1}}var j=!1,b=null,_=-1,M=5,z=-1;function $e(){return!(e.unstable_now()-z<M)}function Jt(){if(b!==null){var R=e.unstable_now();z=R;var N=!0;try{N=b(!0,R)}finally{N?Zt():(j=!1,b=null)}}else j=!1}var Zt;if(typeof p=="function")Zt=function(){p(Jt)};else if(typeof MessageChannel<"u"){var ko=new MessageChannel,Cs=ko.port2;ko.port1.onmessage=Jt,Zt=function(){Cs.postMessage(null)}}else Zt=function(){x(Jt,0)};function hr(R){b=R,j||(j=!0,Zt())}function en(R,N){_=x(function(){R(e.unstable_now())},N)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(R){R.callback=null},e.unstable_continueExecution=function(){y||w||(y=!0,hr(C))},e.unstable_forceFrameRate=function(R){0>R||125<R?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):M=0<R?Math.floor(1e3/R):5},e.unstable_getCurrentPriorityLevel=function(){return m},e.unstable_getFirstCallbackNode=function(){return n(a)},e.unstable_next=function(R){switch(m){case 1:case 2:case 3:var N=3;break;default:N=m}var O=m;m=N;try{return R()}finally{m=O}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(R,N){switch(R){case 1:case 2:case 3:case 4:case 5:break;default:R=3}var O=m;m=R;try{return N()}finally{m=O}},e.unstable_scheduleCallback=function(R,N,O){var U=e.unstable_now();switch(typeof O=="object"&&O!==null?(O=O.delay,O=typeof O=="number"&&0<O?U+O:U):O=U,R){case 1:var H=-1;break;case 2:H=250;break;case 5:H=1073741823;break;case 4:H=1e4;break;default:H=5e3}return H=O+H,R={id:f++,callback:N,priorityLevel:R,startTime:O,expirationTime:H,sortIndex:-1},O>U?(R.sortIndex=O,t(c,R),n(a)===null&&R===n(c)&&(v?(h(_),_=-1):v=!0,en(S,O-U))):(R.sortIndex=H,t(a,R),y||w||(y=!0,hr(C))),R},e.unstable_shouldYield=$e,e.unstable_wrapCallback=function(R){var N=m;return function(){var O=m;m=N;try{return R.apply(this,arguments)}finally{m=O}}}})(Xd);Yd.exports=Xd;var _m=Yd.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Nm=P,ze=_m;function T(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var Jd=new Set,Hr={};function Cn(e,t){Gn(e,t),Gn(e+"Capture",t)}function Gn(e,t){for(Hr[e]=t,e=0;e<t.length;e++)Jd.add(t[e])}var vt=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),vl=Object.prototype.hasOwnProperty,Om=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Iu={},Fu={};function Am(e){return vl.call(Fu,e)?!0:vl.call(Iu,e)?!1:Om.test(e)?Fu[e]=!0:(Iu[e]=!0,!1)}function Lm(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function zm(e,t,n,r){if(t===null||typeof t>"u"||Lm(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function Se(e,t,n,r,o,i,s){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=o,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=i,this.removeEmptyString=s}var fe={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){fe[e]=new Se(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];fe[t]=new Se(t,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){fe[e]=new Se(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){fe[e]=new Se(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){fe[e]=new Se(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){fe[e]=new Se(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){fe[e]=new Se(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){fe[e]=new Se(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){fe[e]=new Se(e,5,!1,e.toLowerCase(),null,!1,!1)});var Na=/[\-:]([a-z])/g;function Oa(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(Na,Oa);fe[t]=new Se(t,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(Na,Oa);fe[t]=new Se(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(Na,Oa);fe[t]=new Se(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){fe[e]=new Se(e,1,!1,e.toLowerCase(),null,!1,!1)});fe.xlinkHref=new Se("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){fe[e]=new Se(e,1,!1,e.toLowerCase(),null,!0,!0)});function Aa(e,t,n,r){var o=fe.hasOwnProperty(t)?fe[t]:null;(o!==null?o.type!==0:r||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(zm(t,n,o,r)&&(n=null),r||o===null?Am(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,""+n)):o.mustUseProperty?e[o.propertyName]=n===null?o.type===3?!1:"":n:(t=o.attributeName,r=o.attributeNamespace,n===null?e.removeAttribute(t):(o=o.type,n=o===3||o===4&&n===!0?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var kt=Nm.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,jo=Symbol.for("react.element"),Rn=Symbol.for("react.portal"),$n=Symbol.for("react.fragment"),La=Symbol.for("react.strict_mode"),wl=Symbol.for("react.profiler"),Zd=Symbol.for("react.provider"),ef=Symbol.for("react.context"),za=Symbol.for("react.forward_ref"),xl=Symbol.for("react.suspense"),Sl=Symbol.for("react.suspense_list"),Da=Symbol.for("react.memo"),Rt=Symbol.for("react.lazy"),tf=Symbol.for("react.offscreen"),Mu=Symbol.iterator;function gr(e){return e===null||typeof e!="object"?null:(e=Mu&&e[Mu]||e["@@iterator"],typeof e=="function"?e:null)}var J=Object.assign,bs;function Tr(e){if(bs===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);bs=t&&t[1]||""}return`
`+bs+e}var Ts=!1;function Rs(e,t){if(!e||Ts)return"";Ts=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(c){var r=c}Reflect.construct(e,[],t)}else{try{t.call()}catch(c){r=c}e.call(t.prototype)}else{try{throw Error()}catch(c){r=c}e()}}catch(c){if(c&&r&&typeof c.stack=="string"){for(var o=c.stack.split(`
`),i=r.stack.split(`
`),s=o.length-1,l=i.length-1;1<=s&&0<=l&&o[s]!==i[l];)l--;for(;1<=s&&0<=l;s--,l--)if(o[s]!==i[l]){if(s!==1||l!==1)do if(s--,l--,0>l||o[s]!==i[l]){var a=`
`+o[s].replace(" at new "," at ");return e.displayName&&a.includes("<anonymous>")&&(a=a.replace("<anonymous>",e.displayName)),a}while(1<=s&&0<=l);break}}}finally{Ts=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?Tr(e):""}function Dm(e){switch(e.tag){case 5:return Tr(e.type);case 16:return Tr("Lazy");case 13:return Tr("Suspense");case 19:return Tr("SuspenseList");case 0:case 2:case 15:return e=Rs(e.type,!1),e;case 11:return e=Rs(e.type.render,!1),e;case 1:return e=Rs(e.type,!0),e;default:return""}}function kl(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case $n:return"Fragment";case Rn:return"Portal";case wl:return"Profiler";case La:return"StrictMode";case xl:return"Suspense";case Sl:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case ef:return(e.displayName||"Context")+".Consumer";case Zd:return(e._context.displayName||"Context")+".Provider";case za:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Da:return t=e.displayName||null,t!==null?t:kl(e.type)||"Memo";case Rt:t=e._payload,e=e._init;try{return kl(e(t))}catch{}}return null}function Im(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return kl(t);case 8:return t===La?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function Qt(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function nf(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Fm(e){var t=nf(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var o=n.get,i=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return o.call(this)},set:function(s){r=""+s,i.call(this,s)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(s){r=""+s},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Po(e){e._valueTracker||(e._valueTracker=Fm(e))}function rf(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=nf(e)?e.checked?"true":"false":e.value),e=r,e!==n?(t.setValue(e),!0):!1}function yi(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function El(e,t){var n=t.checked;return J({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function Bu(e,t){var n=t.defaultValue==null?"":t.defaultValue,r=t.checked!=null?t.checked:t.defaultChecked;n=Qt(t.value!=null?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function of(e,t){t=t.checked,t!=null&&Aa(e,"checked",t,!1)}function Cl(e,t){of(e,t);var n=Qt(t.value),r=t.type;if(n!=null)r==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if(r==="submit"||r==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?jl(e,t.type,n):t.hasOwnProperty("defaultValue")&&jl(e,t.type,Qt(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function Uu(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!(r!=="submit"&&r!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,n!==""&&(e.name=n)}function jl(e,t,n){(t!=="number"||yi(e.ownerDocument)!==e)&&(n==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}var Rr=Array.isArray;function Un(e,t,n,r){if(e=e.options,t){t={};for(var o=0;o<n.length;o++)t["$"+n[o]]=!0;for(n=0;n<e.length;n++)o=t.hasOwnProperty("$"+e[n].value),e[n].selected!==o&&(e[n].selected=o),o&&r&&(e[n].defaultSelected=!0)}else{for(n=""+Qt(n),t=null,o=0;o<e.length;o++){if(e[o].value===n){e[o].selected=!0,r&&(e[o].defaultSelected=!0);return}t!==null||e[o].disabled||(t=e[o])}t!==null&&(t.selected=!0)}}function Pl(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(T(91));return J({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function Hu(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(T(92));if(Rr(n)){if(1<n.length)throw Error(T(93));n=n[0]}t=n}t==null&&(t=""),n=t}e._wrapperState={initialValue:Qt(n)}}function sf(e,t){var n=Qt(t.value),r=Qt(t.defaultValue);n!=null&&(n=""+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=""+r)}function Wu(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function lf(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function bl(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?lf(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var bo,af=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,n,r,o){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,o)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(bo=bo||document.createElement("div"),bo.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=bo.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function Wr(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var Or={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Mm=["Webkit","ms","Moz","O"];Object.keys(Or).forEach(function(e){Mm.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),Or[t]=Or[e]})});function uf(e,t,n){return t==null||typeof t=="boolean"||t===""?"":n||typeof t!="number"||t===0||Or.hasOwnProperty(e)&&Or[e]?(""+t).trim():t+"px"}function cf(e,t){e=e.style;for(var n in t)if(t.hasOwnProperty(n)){var r=n.indexOf("--")===0,o=uf(n,t[n],r);n==="float"&&(n="cssFloat"),r?e.setProperty(n,o):e[n]=o}}var Bm=J({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Tl(e,t){if(t){if(Bm[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(T(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(T(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(T(61))}if(t.style!=null&&typeof t.style!="object")throw Error(T(62))}}function Rl(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var $l=null;function Ia(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var _l=null,Hn=null,Wn=null;function qu(e){if(e=go(e)){if(typeof _l!="function")throw Error(T(280));var t=e.stateNode;t&&(t=Zi(t),_l(e.stateNode,e.type,t))}}function df(e){Hn?Wn?Wn.push(e):Wn=[e]:Hn=e}function ff(){if(Hn){var e=Hn,t=Wn;if(Wn=Hn=null,qu(e),t)for(e=0;e<t.length;e++)qu(t[e])}}function pf(e,t){return e(t)}function hf(){}var $s=!1;function mf(e,t,n){if($s)return e(t,n);$s=!0;try{return pf(e,t,n)}finally{$s=!1,(Hn!==null||Wn!==null)&&(hf(),ff())}}function qr(e,t){var n=e.stateNode;if(n===null)return null;var r=Zi(n);if(r===null)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(e=e.type,r=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!r;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(T(231,t,typeof n));return n}var Nl=!1;if(vt)try{var yr={};Object.defineProperty(yr,"passive",{get:function(){Nl=!0}}),window.addEventListener("test",yr,yr),window.removeEventListener("test",yr,yr)}catch{Nl=!1}function Um(e,t,n,r,o,i,s,l,a){var c=Array.prototype.slice.call(arguments,3);try{t.apply(n,c)}catch(f){this.onError(f)}}var Ar=!1,vi=null,wi=!1,Ol=null,Hm={onError:function(e){Ar=!0,vi=e}};function Wm(e,t,n,r,o,i,s,l,a){Ar=!1,vi=null,Um.apply(Hm,arguments)}function qm(e,t,n,r,o,i,s,l,a){if(Wm.apply(this,arguments),Ar){if(Ar){var c=vi;Ar=!1,vi=null}else throw Error(T(198));wi||(wi=!0,Ol=c)}}function jn(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function gf(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Qu(e){if(jn(e)!==e)throw Error(T(188))}function Qm(e){var t=e.alternate;if(!t){if(t=jn(e),t===null)throw Error(T(188));return t!==e?null:e}for(var n=e,r=t;;){var o=n.return;if(o===null)break;var i=o.alternate;if(i===null){if(r=o.return,r!==null){n=r;continue}break}if(o.child===i.child){for(i=o.child;i;){if(i===n)return Qu(o),e;if(i===r)return Qu(o),t;i=i.sibling}throw Error(T(188))}if(n.return!==r.return)n=o,r=i;else{for(var s=!1,l=o.child;l;){if(l===n){s=!0,n=o,r=i;break}if(l===r){s=!0,r=o,n=i;break}l=l.sibling}if(!s){for(l=i.child;l;){if(l===n){s=!0,n=i,r=o;break}if(l===r){s=!0,r=i,n=o;break}l=l.sibling}if(!s)throw Error(T(189))}}if(n.alternate!==r)throw Error(T(190))}if(n.tag!==3)throw Error(T(188));return n.stateNode.current===n?e:t}function yf(e){return e=Qm(e),e!==null?vf(e):null}function vf(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=vf(e);if(t!==null)return t;e=e.sibling}return null}var wf=ze.unstable_scheduleCallback,Vu=ze.unstable_cancelCallback,Vm=ze.unstable_shouldYield,Km=ze.unstable_requestPaint,ee=ze.unstable_now,Gm=ze.unstable_getCurrentPriorityLevel,Fa=ze.unstable_ImmediatePriority,xf=ze.unstable_UserBlockingPriority,xi=ze.unstable_NormalPriority,Ym=ze.unstable_LowPriority,Sf=ze.unstable_IdlePriority,Gi=null,at=null;function Xm(e){if(at&&typeof at.onCommitFiberRoot=="function")try{at.onCommitFiberRoot(Gi,e,void 0,(e.current.flags&128)===128)}catch{}}var Xe=Math.clz32?Math.clz32:eg,Jm=Math.log,Zm=Math.LN2;function eg(e){return e>>>=0,e===0?32:31-(Jm(e)/Zm|0)|0}var To=64,Ro=4194304;function $r(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Si(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,o=e.suspendedLanes,i=e.pingedLanes,s=n&268435455;if(s!==0){var l=s&~o;l!==0?r=$r(l):(i&=s,i!==0&&(r=$r(i)))}else s=n&~o,s!==0?r=$r(s):i!==0&&(r=$r(i));if(r===0)return 0;if(t!==0&&t!==r&&!(t&o)&&(o=r&-r,i=t&-t,o>=i||o===16&&(i&4194240)!==0))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Xe(t),o=1<<n,r|=e[n],t&=~o;return r}function tg(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function ng(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,o=e.expirationTimes,i=e.pendingLanes;0<i;){var s=31-Xe(i),l=1<<s,a=o[s];a===-1?(!(l&n)||l&r)&&(o[s]=tg(l,t)):a<=t&&(e.expiredLanes|=l),i&=~l}}function Al(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function kf(){var e=To;return To<<=1,!(To&4194240)&&(To=64),e}function _s(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function ho(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Xe(t),e[t]=n}function rg(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var o=31-Xe(n),i=1<<o;t[o]=0,r[o]=-1,e[o]=-1,n&=~i}}function Ma(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Xe(n),o=1<<r;o&t|e[r]&t&&(e[r]|=t),n&=~o}}var B=0;function Ef(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var Cf,Ba,jf,Pf,bf,Ll=!1,$o=[],zt=null,Dt=null,It=null,Qr=new Map,Vr=new Map,_t=[],og="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Ku(e,t){switch(e){case"focusin":case"focusout":zt=null;break;case"dragenter":case"dragleave":Dt=null;break;case"mouseover":case"mouseout":It=null;break;case"pointerover":case"pointerout":Qr.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Vr.delete(t.pointerId)}}function vr(e,t,n,r,o,i){return e===null||e.nativeEvent!==i?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:i,targetContainers:[o]},t!==null&&(t=go(t),t!==null&&Ba(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,o!==null&&t.indexOf(o)===-1&&t.push(o),e)}function ig(e,t,n,r,o){switch(t){case"focusin":return zt=vr(zt,e,t,n,r,o),!0;case"dragenter":return Dt=vr(Dt,e,t,n,r,o),!0;case"mouseover":return It=vr(It,e,t,n,r,o),!0;case"pointerover":var i=o.pointerId;return Qr.set(i,vr(Qr.get(i)||null,e,t,n,r,o)),!0;case"gotpointercapture":return i=o.pointerId,Vr.set(i,vr(Vr.get(i)||null,e,t,n,r,o)),!0}return!1}function Tf(e){var t=sn(e.target);if(t!==null){var n=jn(t);if(n!==null){if(t=n.tag,t===13){if(t=gf(n),t!==null){e.blockedOn=t,bf(e.priority,function(){jf(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Zo(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=zl(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);$l=r,n.target.dispatchEvent(r),$l=null}else return t=go(n),t!==null&&Ba(t),e.blockedOn=n,!1;t.shift()}return!0}function Gu(e,t,n){Zo(e)&&n.delete(t)}function sg(){Ll=!1,zt!==null&&Zo(zt)&&(zt=null),Dt!==null&&Zo(Dt)&&(Dt=null),It!==null&&Zo(It)&&(It=null),Qr.forEach(Gu),Vr.forEach(Gu)}function wr(e,t){e.blockedOn===t&&(e.blockedOn=null,Ll||(Ll=!0,ze.unstable_scheduleCallback(ze.unstable_NormalPriority,sg)))}function Kr(e){function t(o){return wr(o,e)}if(0<$o.length){wr($o[0],e);for(var n=1;n<$o.length;n++){var r=$o[n];r.blockedOn===e&&(r.blockedOn=null)}}for(zt!==null&&wr(zt,e),Dt!==null&&wr(Dt,e),It!==null&&wr(It,e),Qr.forEach(t),Vr.forEach(t),n=0;n<_t.length;n++)r=_t[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<_t.length&&(n=_t[0],n.blockedOn===null);)Tf(n),n.blockedOn===null&&_t.shift()}var qn=kt.ReactCurrentBatchConfig,ki=!0;function lg(e,t,n,r){var o=B,i=qn.transition;qn.transition=null;try{B=1,Ua(e,t,n,r)}finally{B=o,qn.transition=i}}function ag(e,t,n,r){var o=B,i=qn.transition;qn.transition=null;try{B=4,Ua(e,t,n,r)}finally{B=o,qn.transition=i}}function Ua(e,t,n,r){if(ki){var o=zl(e,t,n,r);if(o===null)Bs(e,t,r,Ei,n),Ku(e,r);else if(ig(o,e,t,n,r))r.stopPropagation();else if(Ku(e,r),t&4&&-1<og.indexOf(e)){for(;o!==null;){var i=go(o);if(i!==null&&Cf(i),i=zl(e,t,n,r),i===null&&Bs(e,t,r,Ei,n),i===o)break;o=i}o!==null&&r.stopPropagation()}else Bs(e,t,r,null,n)}}var Ei=null;function zl(e,t,n,r){if(Ei=null,e=Ia(r),e=sn(e),e!==null)if(t=jn(e),t===null)e=null;else if(n=t.tag,n===13){if(e=gf(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return Ei=e,null}function Rf(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Gm()){case Fa:return 1;case xf:return 4;case xi:case Ym:return 16;case Sf:return 536870912;default:return 16}default:return 16}}var Ot=null,Ha=null,ei=null;function $f(){if(ei)return ei;var e,t=Ha,n=t.length,r,o="value"in Ot?Ot.value:Ot.textContent,i=o.length;for(e=0;e<n&&t[e]===o[e];e++);var s=n-e;for(r=1;r<=s&&t[n-r]===o[i-r];r++);return ei=o.slice(e,1<r?1-r:void 0)}function ti(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function _o(){return!0}function Yu(){return!1}function Ie(e){function t(n,r,o,i,s){this._reactName=n,this._targetInst=o,this.type=r,this.nativeEvent=i,this.target=s,this.currentTarget=null;for(var l in e)e.hasOwnProperty(l)&&(n=e[l],this[l]=n?n(i):i[l]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?_o:Yu,this.isPropagationStopped=Yu,this}return J(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=_o)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=_o)},persist:function(){},isPersistent:_o}),t}var lr={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Wa=Ie(lr),mo=J({},lr,{view:0,detail:0}),ug=Ie(mo),Ns,Os,xr,Yi=J({},mo,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:qa,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==xr&&(xr&&e.type==="mousemove"?(Ns=e.screenX-xr.screenX,Os=e.screenY-xr.screenY):Os=Ns=0,xr=e),Ns)},movementY:function(e){return"movementY"in e?e.movementY:Os}}),Xu=Ie(Yi),cg=J({},Yi,{dataTransfer:0}),dg=Ie(cg),fg=J({},mo,{relatedTarget:0}),As=Ie(fg),pg=J({},lr,{animationName:0,elapsedTime:0,pseudoElement:0}),hg=Ie(pg),mg=J({},lr,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),gg=Ie(mg),yg=J({},lr,{data:0}),Ju=Ie(yg),vg={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},wg={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},xg={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Sg(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=xg[e])?!!t[e]:!1}function qa(){return Sg}var kg=J({},mo,{key:function(e){if(e.key){var t=vg[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=ti(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?wg[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:qa,charCode:function(e){return e.type==="keypress"?ti(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?ti(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Eg=Ie(kg),Cg=J({},Yi,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Zu=Ie(Cg),jg=J({},mo,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:qa}),Pg=Ie(jg),bg=J({},lr,{propertyName:0,elapsedTime:0,pseudoElement:0}),Tg=Ie(bg),Rg=J({},Yi,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),$g=Ie(Rg),_g=[9,13,27,32],Qa=vt&&"CompositionEvent"in window,Lr=null;vt&&"documentMode"in document&&(Lr=document.documentMode);var Ng=vt&&"TextEvent"in window&&!Lr,_f=vt&&(!Qa||Lr&&8<Lr&&11>=Lr),ec=" ",tc=!1;function Nf(e,t){switch(e){case"keyup":return _g.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Of(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var _n=!1;function Og(e,t){switch(e){case"compositionend":return Of(t);case"keypress":return t.which!==32?null:(tc=!0,ec);case"textInput":return e=t.data,e===ec&&tc?null:e;default:return null}}function Ag(e,t){if(_n)return e==="compositionend"||!Qa&&Nf(e,t)?(e=$f(),ei=Ha=Ot=null,_n=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return _f&&t.locale!=="ko"?null:t.data;default:return null}}var Lg={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function nc(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Lg[e.type]:t==="textarea"}function Af(e,t,n,r){df(r),t=Ci(t,"onChange"),0<t.length&&(n=new Wa("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var zr=null,Gr=null;function zg(e){qf(e,0)}function Xi(e){var t=An(e);if(rf(t))return e}function Dg(e,t){if(e==="change")return t}var Lf=!1;if(vt){var Ls;if(vt){var zs="oninput"in document;if(!zs){var rc=document.createElement("div");rc.setAttribute("oninput","return;"),zs=typeof rc.oninput=="function"}Ls=zs}else Ls=!1;Lf=Ls&&(!document.documentMode||9<document.documentMode)}function oc(){zr&&(zr.detachEvent("onpropertychange",zf),Gr=zr=null)}function zf(e){if(e.propertyName==="value"&&Xi(Gr)){var t=[];Af(t,Gr,e,Ia(e)),mf(zg,t)}}function Ig(e,t,n){e==="focusin"?(oc(),zr=t,Gr=n,zr.attachEvent("onpropertychange",zf)):e==="focusout"&&oc()}function Fg(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Xi(Gr)}function Mg(e,t){if(e==="click")return Xi(t)}function Bg(e,t){if(e==="input"||e==="change")return Xi(t)}function Ug(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var et=typeof Object.is=="function"?Object.is:Ug;function Yr(e,t){if(et(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var o=n[r];if(!vl.call(t,o)||!et(e[o],t[o]))return!1}return!0}function ic(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function sc(e,t){var n=ic(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=ic(n)}}function Df(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Df(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function If(){for(var e=window,t=yi();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=yi(e.document)}return t}function Va(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function Hg(e){var t=If(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Df(n.ownerDocument.documentElement,n)){if(r!==null&&Va(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),"selectionStart"in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var o=n.textContent.length,i=Math.min(r.start,o);r=r.end===void 0?i:Math.min(r.end,o),!e.extend&&i>r&&(o=r,r=i,i=o),o=sc(n,i);var s=sc(n,r);o&&s&&(e.rangeCount!==1||e.anchorNode!==o.node||e.anchorOffset!==o.offset||e.focusNode!==s.node||e.focusOffset!==s.offset)&&(t=t.createRange(),t.setStart(o.node,o.offset),e.removeAllRanges(),i>r?(e.addRange(t),e.extend(s.node,s.offset)):(t.setEnd(s.node,s.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Wg=vt&&"documentMode"in document&&11>=document.documentMode,Nn=null,Dl=null,Dr=null,Il=!1;function lc(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Il||Nn==null||Nn!==yi(r)||(r=Nn,"selectionStart"in r&&Va(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Dr&&Yr(Dr,r)||(Dr=r,r=Ci(Dl,"onSelect"),0<r.length&&(t=new Wa("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=Nn)))}function No(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var On={animationend:No("Animation","AnimationEnd"),animationiteration:No("Animation","AnimationIteration"),animationstart:No("Animation","AnimationStart"),transitionend:No("Transition","TransitionEnd")},Ds={},Ff={};vt&&(Ff=document.createElement("div").style,"AnimationEvent"in window||(delete On.animationend.animation,delete On.animationiteration.animation,delete On.animationstart.animation),"TransitionEvent"in window||delete On.transitionend.transition);function Ji(e){if(Ds[e])return Ds[e];if(!On[e])return e;var t=On[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Ff)return Ds[e]=t[n];return e}var Mf=Ji("animationend"),Bf=Ji("animationiteration"),Uf=Ji("animationstart"),Hf=Ji("transitionend"),Wf=new Map,ac="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Kt(e,t){Wf.set(e,t),Cn(t,[e])}for(var Is=0;Is<ac.length;Is++){var Fs=ac[Is],qg=Fs.toLowerCase(),Qg=Fs[0].toUpperCase()+Fs.slice(1);Kt(qg,"on"+Qg)}Kt(Mf,"onAnimationEnd");Kt(Bf,"onAnimationIteration");Kt(Uf,"onAnimationStart");Kt("dblclick","onDoubleClick");Kt("focusin","onFocus");Kt("focusout","onBlur");Kt(Hf,"onTransitionEnd");Gn("onMouseEnter",["mouseout","mouseover"]);Gn("onMouseLeave",["mouseout","mouseover"]);Gn("onPointerEnter",["pointerout","pointerover"]);Gn("onPointerLeave",["pointerout","pointerover"]);Cn("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Cn("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Cn("onBeforeInput",["compositionend","keypress","textInput","paste"]);Cn("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Cn("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Cn("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var _r="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Vg=new Set("cancel close invalid load scroll toggle".split(" ").concat(_r));function uc(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,qm(r,t,void 0,e),e.currentTarget=null}function qf(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var r=e[n],o=r.event;r=r.listeners;e:{var i=void 0;if(t)for(var s=r.length-1;0<=s;s--){var l=r[s],a=l.instance,c=l.currentTarget;if(l=l.listener,a!==i&&o.isPropagationStopped())break e;uc(o,l,c),i=a}else for(s=0;s<r.length;s++){if(l=r[s],a=l.instance,c=l.currentTarget,l=l.listener,a!==i&&o.isPropagationStopped())break e;uc(o,l,c),i=a}}}if(wi)throw e=Ol,wi=!1,Ol=null,e}function Q(e,t){var n=t[Hl];n===void 0&&(n=t[Hl]=new Set);var r=e+"__bubble";n.has(r)||(Qf(t,e,2,!1),n.add(r))}function Ms(e,t,n){var r=0;t&&(r|=4),Qf(n,e,r,t)}var Oo="_reactListening"+Math.random().toString(36).slice(2);function Xr(e){if(!e[Oo]){e[Oo]=!0,Jd.forEach(function(n){n!=="selectionchange"&&(Vg.has(n)||Ms(n,!1,e),Ms(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Oo]||(t[Oo]=!0,Ms("selectionchange",!1,t))}}function Qf(e,t,n,r){switch(Rf(t)){case 1:var o=lg;break;case 4:o=ag;break;default:o=Ua}n=o.bind(null,t,n,e),o=void 0,!Nl||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(o=!0),r?o!==void 0?e.addEventListener(t,n,{capture:!0,passive:o}):e.addEventListener(t,n,!0):o!==void 0?e.addEventListener(t,n,{passive:o}):e.addEventListener(t,n,!1)}function Bs(e,t,n,r,o){var i=r;if(!(t&1)&&!(t&2)&&r!==null)e:for(;;){if(r===null)return;var s=r.tag;if(s===3||s===4){var l=r.stateNode.containerInfo;if(l===o||l.nodeType===8&&l.parentNode===o)break;if(s===4)for(s=r.return;s!==null;){var a=s.tag;if((a===3||a===4)&&(a=s.stateNode.containerInfo,a===o||a.nodeType===8&&a.parentNode===o))return;s=s.return}for(;l!==null;){if(s=sn(l),s===null)return;if(a=s.tag,a===5||a===6){r=i=s;continue e}l=l.parentNode}}r=r.return}mf(function(){var c=i,f=Ia(n),d=[];e:{var m=Wf.get(e);if(m!==void 0){var w=Wa,y=e;switch(e){case"keypress":if(ti(n)===0)break e;case"keydown":case"keyup":w=Eg;break;case"focusin":y="focus",w=As;break;case"focusout":y="blur",w=As;break;case"beforeblur":case"afterblur":w=As;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":w=Xu;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":w=dg;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":w=Pg;break;case Mf:case Bf:case Uf:w=hg;break;case Hf:w=Tg;break;case"scroll":w=ug;break;case"wheel":w=$g;break;case"copy":case"cut":case"paste":w=gg;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":w=Zu}var v=(t&4)!==0,x=!v&&e==="scroll",h=v?m!==null?m+"Capture":null:m;v=[];for(var p=c,g;p!==null;){g=p;var S=g.stateNode;if(g.tag===5&&S!==null&&(g=S,h!==null&&(S=qr(p,h),S!=null&&v.push(Jr(p,S,g)))),x)break;p=p.return}0<v.length&&(m=new w(m,y,null,n,f),d.push({event:m,listeners:v}))}}if(!(t&7)){e:{if(m=e==="mouseover"||e==="pointerover",w=e==="mouseout"||e==="pointerout",m&&n!==$l&&(y=n.relatedTarget||n.fromElement)&&(sn(y)||y[wt]))break e;if((w||m)&&(m=f.window===f?f:(m=f.ownerDocument)?m.defaultView||m.parentWindow:window,w?(y=n.relatedTarget||n.toElement,w=c,y=y?sn(y):null,y!==null&&(x=jn(y),y!==x||y.tag!==5&&y.tag!==6)&&(y=null)):(w=null,y=c),w!==y)){if(v=Xu,S="onMouseLeave",h="onMouseEnter",p="mouse",(e==="pointerout"||e==="pointerover")&&(v=Zu,S="onPointerLeave",h="onPointerEnter",p="pointer"),x=w==null?m:An(w),g=y==null?m:An(y),m=new v(S,p+"leave",w,n,f),m.target=x,m.relatedTarget=g,S=null,sn(f)===c&&(v=new v(h,p+"enter",y,n,f),v.target=g,v.relatedTarget=x,S=v),x=S,w&&y)t:{for(v=w,h=y,p=0,g=v;g;g=Pn(g))p++;for(g=0,S=h;S;S=Pn(S))g++;for(;0<p-g;)v=Pn(v),p--;for(;0<g-p;)h=Pn(h),g--;for(;p--;){if(v===h||h!==null&&v===h.alternate)break t;v=Pn(v),h=Pn(h)}v=null}else v=null;w!==null&&cc(d,m,w,v,!1),y!==null&&x!==null&&cc(d,x,y,v,!0)}}e:{if(m=c?An(c):window,w=m.nodeName&&m.nodeName.toLowerCase(),w==="select"||w==="input"&&m.type==="file")var C=Dg;else if(nc(m))if(Lf)C=Bg;else{C=Fg;var j=Ig}else(w=m.nodeName)&&w.toLowerCase()==="input"&&(m.type==="checkbox"||m.type==="radio")&&(C=Mg);if(C&&(C=C(e,c))){Af(d,C,n,f);break e}j&&j(e,m,c),e==="focusout"&&(j=m._wrapperState)&&j.controlled&&m.type==="number"&&jl(m,"number",m.value)}switch(j=c?An(c):window,e){case"focusin":(nc(j)||j.contentEditable==="true")&&(Nn=j,Dl=c,Dr=null);break;case"focusout":Dr=Dl=Nn=null;break;case"mousedown":Il=!0;break;case"contextmenu":case"mouseup":case"dragend":Il=!1,lc(d,n,f);break;case"selectionchange":if(Wg)break;case"keydown":case"keyup":lc(d,n,f)}var b;if(Qa)e:{switch(e){case"compositionstart":var _="onCompositionStart";break e;case"compositionend":_="onCompositionEnd";break e;case"compositionupdate":_="onCompositionUpdate";break e}_=void 0}else _n?Nf(e,n)&&(_="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(_="onCompositionStart");_&&(_f&&n.locale!=="ko"&&(_n||_!=="onCompositionStart"?_==="onCompositionEnd"&&_n&&(b=$f()):(Ot=f,Ha="value"in Ot?Ot.value:Ot.textContent,_n=!0)),j=Ci(c,_),0<j.length&&(_=new Ju(_,e,null,n,f),d.push({event:_,listeners:j}),b?_.data=b:(b=Of(n),b!==null&&(_.data=b)))),(b=Ng?Og(e,n):Ag(e,n))&&(c=Ci(c,"onBeforeInput"),0<c.length&&(f=new Ju("onBeforeInput","beforeinput",null,n,f),d.push({event:f,listeners:c}),f.data=b))}qf(d,t)})}function Jr(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ci(e,t){for(var n=t+"Capture",r=[];e!==null;){var o=e,i=o.stateNode;o.tag===5&&i!==null&&(o=i,i=qr(e,n),i!=null&&r.unshift(Jr(e,i,o)),i=qr(e,t),i!=null&&r.push(Jr(e,i,o))),e=e.return}return r}function Pn(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function cc(e,t,n,r,o){for(var i=t._reactName,s=[];n!==null&&n!==r;){var l=n,a=l.alternate,c=l.stateNode;if(a!==null&&a===r)break;l.tag===5&&c!==null&&(l=c,o?(a=qr(n,i),a!=null&&s.unshift(Jr(n,a,l))):o||(a=qr(n,i),a!=null&&s.push(Jr(n,a,l)))),n=n.return}s.length!==0&&e.push({event:t,listeners:s})}var Kg=/\r\n?/g,Gg=/\u0000|\uFFFD/g;function dc(e){return(typeof e=="string"?e:""+e).replace(Kg,`
`).replace(Gg,"")}function Ao(e,t,n){if(t=dc(t),dc(e)!==t&&n)throw Error(T(425))}function ji(){}var Fl=null,Ml=null;function Bl(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Ul=typeof setTimeout=="function"?setTimeout:void 0,Yg=typeof clearTimeout=="function"?clearTimeout:void 0,fc=typeof Promise=="function"?Promise:void 0,Xg=typeof queueMicrotask=="function"?queueMicrotask:typeof fc<"u"?function(e){return fc.resolve(null).then(e).catch(Jg)}:Ul;function Jg(e){setTimeout(function(){throw e})}function Us(e,t){var n=t,r=0;do{var o=n.nextSibling;if(e.removeChild(n),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(r===0){e.removeChild(o),Kr(t);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=o}while(n);Kr(t)}function Ft(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function pc(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"){if(t===0)return e;t--}else n==="/$"&&t++}e=e.previousSibling}return null}var ar=Math.random().toString(36).slice(2),lt="__reactFiber$"+ar,Zr="__reactProps$"+ar,wt="__reactContainer$"+ar,Hl="__reactEvents$"+ar,Zg="__reactListeners$"+ar,ey="__reactHandles$"+ar;function sn(e){var t=e[lt];if(t)return t;for(var n=e.parentNode;n;){if(t=n[wt]||n[lt]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=pc(e);e!==null;){if(n=e[lt])return n;e=pc(e)}return t}e=n,n=e.parentNode}return null}function go(e){return e=e[lt]||e[wt],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function An(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(T(33))}function Zi(e){return e[Zr]||null}var Wl=[],Ln=-1;function Gt(e){return{current:e}}function K(e){0>Ln||(e.current=Wl[Ln],Wl[Ln]=null,Ln--)}function q(e,t){Ln++,Wl[Ln]=e.current,e.current=t}var Vt={},ye=Gt(Vt),je=Gt(!1),gn=Vt;function Yn(e,t){var n=e.type.contextTypes;if(!n)return Vt;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var o={},i;for(i in n)o[i]=t[i];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=o),o}function Pe(e){return e=e.childContextTypes,e!=null}function Pi(){K(je),K(ye)}function hc(e,t,n){if(ye.current!==Vt)throw Error(T(168));q(ye,t),q(je,n)}function Vf(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var o in r)if(!(o in t))throw Error(T(108,Im(e)||"Unknown",o));return J({},n,r)}function bi(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||Vt,gn=ye.current,q(ye,e),q(je,je.current),!0}function mc(e,t,n){var r=e.stateNode;if(!r)throw Error(T(169));n?(e=Vf(e,t,gn),r.__reactInternalMemoizedMergedChildContext=e,K(je),K(ye),q(ye,e)):K(je),q(je,n)}var ht=null,es=!1,Hs=!1;function Kf(e){ht===null?ht=[e]:ht.push(e)}function ty(e){es=!0,Kf(e)}function Yt(){if(!Hs&&ht!==null){Hs=!0;var e=0,t=B;try{var n=ht;for(B=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}ht=null,es=!1}catch(o){throw ht!==null&&(ht=ht.slice(e+1)),wf(Fa,Yt),o}finally{B=t,Hs=!1}}return null}var zn=[],Dn=0,Ti=null,Ri=0,Fe=[],Me=0,yn=null,mt=1,gt="";function rn(e,t){zn[Dn++]=Ri,zn[Dn++]=Ti,Ti=e,Ri=t}function Gf(e,t,n){Fe[Me++]=mt,Fe[Me++]=gt,Fe[Me++]=yn,yn=e;var r=mt;e=gt;var o=32-Xe(r)-1;r&=~(1<<o),n+=1;var i=32-Xe(t)+o;if(30<i){var s=o-o%5;i=(r&(1<<s)-1).toString(32),r>>=s,o-=s,mt=1<<32-Xe(t)+o|n<<o|r,gt=i+e}else mt=1<<i|n<<o|r,gt=e}function Ka(e){e.return!==null&&(rn(e,1),Gf(e,1,0))}function Ga(e){for(;e===Ti;)Ti=zn[--Dn],zn[Dn]=null,Ri=zn[--Dn],zn[Dn]=null;for(;e===yn;)yn=Fe[--Me],Fe[Me]=null,gt=Fe[--Me],Fe[Me]=null,mt=Fe[--Me],Fe[Me]=null}var Le=null,Ae=null,G=!1,Ye=null;function Yf(e,t){var n=Be(5,null,null,0);n.elementType="DELETED",n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function gc(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,Le=e,Ae=Ft(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,Le=e,Ae=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(n=yn!==null?{id:mt,overflow:gt}:null,e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=Be(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,Le=e,Ae=null,!0):!1;default:return!1}}function ql(e){return(e.mode&1)!==0&&(e.flags&128)===0}function Ql(e){if(G){var t=Ae;if(t){var n=t;if(!gc(e,t)){if(ql(e))throw Error(T(418));t=Ft(n.nextSibling);var r=Le;t&&gc(e,t)?Yf(r,n):(e.flags=e.flags&-4097|2,G=!1,Le=e)}}else{if(ql(e))throw Error(T(418));e.flags=e.flags&-4097|2,G=!1,Le=e}}}function yc(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;Le=e}function Lo(e){if(e!==Le)return!1;if(!G)return yc(e),G=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!Bl(e.type,e.memoizedProps)),t&&(t=Ae)){if(ql(e))throw Xf(),Error(T(418));for(;t;)Yf(e,t),t=Ft(t.nextSibling)}if(yc(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(T(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"){if(t===0){Ae=Ft(e.nextSibling);break e}t--}else n!=="$"&&n!=="$!"&&n!=="$?"||t++}e=e.nextSibling}Ae=null}}else Ae=Le?Ft(e.stateNode.nextSibling):null;return!0}function Xf(){for(var e=Ae;e;)e=Ft(e.nextSibling)}function Xn(){Ae=Le=null,G=!1}function Ya(e){Ye===null?Ye=[e]:Ye.push(e)}var ny=kt.ReactCurrentBatchConfig;function Sr(e,t,n){if(e=n.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(T(309));var r=n.stateNode}if(!r)throw Error(T(147,e));var o=r,i=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===i?t.ref:(t=function(s){var l=o.refs;s===null?delete l[i]:l[i]=s},t._stringRef=i,t)}if(typeof e!="string")throw Error(T(284));if(!n._owner)throw Error(T(290,e))}return e}function zo(e,t){throw e=Object.prototype.toString.call(t),Error(T(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function vc(e){var t=e._init;return t(e._payload)}function Jf(e){function t(h,p){if(e){var g=h.deletions;g===null?(h.deletions=[p],h.flags|=16):g.push(p)}}function n(h,p){if(!e)return null;for(;p!==null;)t(h,p),p=p.sibling;return null}function r(h,p){for(h=new Map;p!==null;)p.key!==null?h.set(p.key,p):h.set(p.index,p),p=p.sibling;return h}function o(h,p){return h=Ht(h,p),h.index=0,h.sibling=null,h}function i(h,p,g){return h.index=g,e?(g=h.alternate,g!==null?(g=g.index,g<p?(h.flags|=2,p):g):(h.flags|=2,p)):(h.flags|=1048576,p)}function s(h){return e&&h.alternate===null&&(h.flags|=2),h}function l(h,p,g,S){return p===null||p.tag!==6?(p=Ys(g,h.mode,S),p.return=h,p):(p=o(p,g),p.return=h,p)}function a(h,p,g,S){var C=g.type;return C===$n?f(h,p,g.props.children,S,g.key):p!==null&&(p.elementType===C||typeof C=="object"&&C!==null&&C.$$typeof===Rt&&vc(C)===p.type)?(S=o(p,g.props),S.ref=Sr(h,p,g),S.return=h,S):(S=ai(g.type,g.key,g.props,null,h.mode,S),S.ref=Sr(h,p,g),S.return=h,S)}function c(h,p,g,S){return p===null||p.tag!==4||p.stateNode.containerInfo!==g.containerInfo||p.stateNode.implementation!==g.implementation?(p=Xs(g,h.mode,S),p.return=h,p):(p=o(p,g.children||[]),p.return=h,p)}function f(h,p,g,S,C){return p===null||p.tag!==7?(p=pn(g,h.mode,S,C),p.return=h,p):(p=o(p,g),p.return=h,p)}function d(h,p,g){if(typeof p=="string"&&p!==""||typeof p=="number")return p=Ys(""+p,h.mode,g),p.return=h,p;if(typeof p=="object"&&p!==null){switch(p.$$typeof){case jo:return g=ai(p.type,p.key,p.props,null,h.mode,g),g.ref=Sr(h,null,p),g.return=h,g;case Rn:return p=Xs(p,h.mode,g),p.return=h,p;case Rt:var S=p._init;return d(h,S(p._payload),g)}if(Rr(p)||gr(p))return p=pn(p,h.mode,g,null),p.return=h,p;zo(h,p)}return null}function m(h,p,g,S){var C=p!==null?p.key:null;if(typeof g=="string"&&g!==""||typeof g=="number")return C!==null?null:l(h,p,""+g,S);if(typeof g=="object"&&g!==null){switch(g.$$typeof){case jo:return g.key===C?a(h,p,g,S):null;case Rn:return g.key===C?c(h,p,g,S):null;case Rt:return C=g._init,m(h,p,C(g._payload),S)}if(Rr(g)||gr(g))return C!==null?null:f(h,p,g,S,null);zo(h,g)}return null}function w(h,p,g,S,C){if(typeof S=="string"&&S!==""||typeof S=="number")return h=h.get(g)||null,l(p,h,""+S,C);if(typeof S=="object"&&S!==null){switch(S.$$typeof){case jo:return h=h.get(S.key===null?g:S.key)||null,a(p,h,S,C);case Rn:return h=h.get(S.key===null?g:S.key)||null,c(p,h,S,C);case Rt:var j=S._init;return w(h,p,g,j(S._payload),C)}if(Rr(S)||gr(S))return h=h.get(g)||null,f(p,h,S,C,null);zo(p,S)}return null}function y(h,p,g,S){for(var C=null,j=null,b=p,_=p=0,M=null;b!==null&&_<g.length;_++){b.index>_?(M=b,b=null):M=b.sibling;var z=m(h,b,g[_],S);if(z===null){b===null&&(b=M);break}e&&b&&z.alternate===null&&t(h,b),p=i(z,p,_),j===null?C=z:j.sibling=z,j=z,b=M}if(_===g.length)return n(h,b),G&&rn(h,_),C;if(b===null){for(;_<g.length;_++)b=d(h,g[_],S),b!==null&&(p=i(b,p,_),j===null?C=b:j.sibling=b,j=b);return G&&rn(h,_),C}for(b=r(h,b);_<g.length;_++)M=w(b,h,_,g[_],S),M!==null&&(e&&M.alternate!==null&&b.delete(M.key===null?_:M.key),p=i(M,p,_),j===null?C=M:j.sibling=M,j=M);return e&&b.forEach(function($e){return t(h,$e)}),G&&rn(h,_),C}function v(h,p,g,S){var C=gr(g);if(typeof C!="function")throw Error(T(150));if(g=C.call(g),g==null)throw Error(T(151));for(var j=C=null,b=p,_=p=0,M=null,z=g.next();b!==null&&!z.done;_++,z=g.next()){b.index>_?(M=b,b=null):M=b.sibling;var $e=m(h,b,z.value,S);if($e===null){b===null&&(b=M);break}e&&b&&$e.alternate===null&&t(h,b),p=i($e,p,_),j===null?C=$e:j.sibling=$e,j=$e,b=M}if(z.done)return n(h,b),G&&rn(h,_),C;if(b===null){for(;!z.done;_++,z=g.next())z=d(h,z.value,S),z!==null&&(p=i(z,p,_),j===null?C=z:j.sibling=z,j=z);return G&&rn(h,_),C}for(b=r(h,b);!z.done;_++,z=g.next())z=w(b,h,_,z.value,S),z!==null&&(e&&z.alternate!==null&&b.delete(z.key===null?_:z.key),p=i(z,p,_),j===null?C=z:j.sibling=z,j=z);return e&&b.forEach(function(Jt){return t(h,Jt)}),G&&rn(h,_),C}function x(h,p,g,S){if(typeof g=="object"&&g!==null&&g.type===$n&&g.key===null&&(g=g.props.children),typeof g=="object"&&g!==null){switch(g.$$typeof){case jo:e:{for(var C=g.key,j=p;j!==null;){if(j.key===C){if(C=g.type,C===$n){if(j.tag===7){n(h,j.sibling),p=o(j,g.props.children),p.return=h,h=p;break e}}else if(j.elementType===C||typeof C=="object"&&C!==null&&C.$$typeof===Rt&&vc(C)===j.type){n(h,j.sibling),p=o(j,g.props),p.ref=Sr(h,j,g),p.return=h,h=p;break e}n(h,j);break}else t(h,j);j=j.sibling}g.type===$n?(p=pn(g.props.children,h.mode,S,g.key),p.return=h,h=p):(S=ai(g.type,g.key,g.props,null,h.mode,S),S.ref=Sr(h,p,g),S.return=h,h=S)}return s(h);case Rn:e:{for(j=g.key;p!==null;){if(p.key===j)if(p.tag===4&&p.stateNode.containerInfo===g.containerInfo&&p.stateNode.implementation===g.implementation){n(h,p.sibling),p=o(p,g.children||[]),p.return=h,h=p;break e}else{n(h,p);break}else t(h,p);p=p.sibling}p=Xs(g,h.mode,S),p.return=h,h=p}return s(h);case Rt:return j=g._init,x(h,p,j(g._payload),S)}if(Rr(g))return y(h,p,g,S);if(gr(g))return v(h,p,g,S);zo(h,g)}return typeof g=="string"&&g!==""||typeof g=="number"?(g=""+g,p!==null&&p.tag===6?(n(h,p.sibling),p=o(p,g),p.return=h,h=p):(n(h,p),p=Ys(g,h.mode,S),p.return=h,h=p),s(h)):n(h,p)}return x}var Jn=Jf(!0),Zf=Jf(!1),$i=Gt(null),_i=null,In=null,Xa=null;function Ja(){Xa=In=_i=null}function Za(e){var t=$i.current;K($i),e._currentValue=t}function Vl(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,r!==null&&(r.childLanes|=t)):r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function Qn(e,t){_i=e,Xa=In=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(Ce=!0),e.firstContext=null)}function He(e){var t=e._currentValue;if(Xa!==e)if(e={context:e,memoizedValue:t,next:null},In===null){if(_i===null)throw Error(T(308));In=e,_i.dependencies={lanes:0,firstContext:e}}else In=In.next=e;return t}var ln=null;function eu(e){ln===null?ln=[e]:ln.push(e)}function ep(e,t,n,r){var o=t.interleaved;return o===null?(n.next=n,eu(t)):(n.next=o.next,o.next=n),t.interleaved=n,xt(e,r)}function xt(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var $t=!1;function tu(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function tp(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function yt(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function Mt(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,I&2){var o=r.pending;return o===null?t.next=t:(t.next=o.next,o.next=t),r.pending=t,xt(e,n)}return o=r.interleaved,o===null?(t.next=t,eu(r)):(t.next=o.next,o.next=t),r.interleaved=t,xt(e,n)}function ni(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194240)!==0)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Ma(e,n)}}function wc(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var o=null,i=null;if(n=n.firstBaseUpdate,n!==null){do{var s={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};i===null?o=i=s:i=i.next=s,n=n.next}while(n!==null);i===null?o=i=t:i=i.next=t}else o=i=t;n={baseState:r.baseState,firstBaseUpdate:o,lastBaseUpdate:i,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function Ni(e,t,n,r){var o=e.updateQueue;$t=!1;var i=o.firstBaseUpdate,s=o.lastBaseUpdate,l=o.shared.pending;if(l!==null){o.shared.pending=null;var a=l,c=a.next;a.next=null,s===null?i=c:s.next=c,s=a;var f=e.alternate;f!==null&&(f=f.updateQueue,l=f.lastBaseUpdate,l!==s&&(l===null?f.firstBaseUpdate=c:l.next=c,f.lastBaseUpdate=a))}if(i!==null){var d=o.baseState;s=0,f=c=a=null,l=i;do{var m=l.lane,w=l.eventTime;if((r&m)===m){f!==null&&(f=f.next={eventTime:w,lane:0,tag:l.tag,payload:l.payload,callback:l.callback,next:null});e:{var y=e,v=l;switch(m=t,w=n,v.tag){case 1:if(y=v.payload,typeof y=="function"){d=y.call(w,d,m);break e}d=y;break e;case 3:y.flags=y.flags&-65537|128;case 0:if(y=v.payload,m=typeof y=="function"?y.call(w,d,m):y,m==null)break e;d=J({},d,m);break e;case 2:$t=!0}}l.callback!==null&&l.lane!==0&&(e.flags|=64,m=o.effects,m===null?o.effects=[l]:m.push(l))}else w={eventTime:w,lane:m,tag:l.tag,payload:l.payload,callback:l.callback,next:null},f===null?(c=f=w,a=d):f=f.next=w,s|=m;if(l=l.next,l===null){if(l=o.shared.pending,l===null)break;m=l,l=m.next,m.next=null,o.lastBaseUpdate=m,o.shared.pending=null}}while(!0);if(f===null&&(a=d),o.baseState=a,o.firstBaseUpdate=c,o.lastBaseUpdate=f,t=o.shared.interleaved,t!==null){o=t;do s|=o.lane,o=o.next;while(o!==t)}else i===null&&(o.shared.lanes=0);wn|=s,e.lanes=s,e.memoizedState=d}}function xc(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],o=r.callback;if(o!==null){if(r.callback=null,r=n,typeof o!="function")throw Error(T(191,o));o.call(r)}}}var yo={},ut=Gt(yo),eo=Gt(yo),to=Gt(yo);function an(e){if(e===yo)throw Error(T(174));return e}function nu(e,t){switch(q(to,t),q(eo,e),q(ut,yo),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:bl(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=bl(t,e)}K(ut),q(ut,t)}function Zn(){K(ut),K(eo),K(to)}function np(e){an(to.current);var t=an(ut.current),n=bl(t,e.type);t!==n&&(q(eo,e),q(ut,n))}function ru(e){eo.current===e&&(K(ut),K(eo))}var Y=Gt(0);function Oi(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Ws=[];function ou(){for(var e=0;e<Ws.length;e++)Ws[e]._workInProgressVersionPrimary=null;Ws.length=0}var ri=kt.ReactCurrentDispatcher,qs=kt.ReactCurrentBatchConfig,vn=0,X=null,oe=null,se=null,Ai=!1,Ir=!1,no=0,ry=0;function pe(){throw Error(T(321))}function iu(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!et(e[n],t[n]))return!1;return!0}function su(e,t,n,r,o,i){if(vn=i,X=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,ri.current=e===null||e.memoizedState===null?ly:ay,e=n(r,o),Ir){i=0;do{if(Ir=!1,no=0,25<=i)throw Error(T(301));i+=1,se=oe=null,t.updateQueue=null,ri.current=uy,e=n(r,o)}while(Ir)}if(ri.current=Li,t=oe!==null&&oe.next!==null,vn=0,se=oe=X=null,Ai=!1,t)throw Error(T(300));return e}function lu(){var e=no!==0;return no=0,e}function it(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return se===null?X.memoizedState=se=e:se=se.next=e,se}function We(){if(oe===null){var e=X.alternate;e=e!==null?e.memoizedState:null}else e=oe.next;var t=se===null?X.memoizedState:se.next;if(t!==null)se=t,oe=e;else{if(e===null)throw Error(T(310));oe=e,e={memoizedState:oe.memoizedState,baseState:oe.baseState,baseQueue:oe.baseQueue,queue:oe.queue,next:null},se===null?X.memoizedState=se=e:se=se.next=e}return se}function ro(e,t){return typeof t=="function"?t(e):t}function Qs(e){var t=We(),n=t.queue;if(n===null)throw Error(T(311));n.lastRenderedReducer=e;var r=oe,o=r.baseQueue,i=n.pending;if(i!==null){if(o!==null){var s=o.next;o.next=i.next,i.next=s}r.baseQueue=o=i,n.pending=null}if(o!==null){i=o.next,r=r.baseState;var l=s=null,a=null,c=i;do{var f=c.lane;if((vn&f)===f)a!==null&&(a=a.next={lane:0,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),r=c.hasEagerState?c.eagerState:e(r,c.action);else{var d={lane:f,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null};a===null?(l=a=d,s=r):a=a.next=d,X.lanes|=f,wn|=f}c=c.next}while(c!==null&&c!==i);a===null?s=r:a.next=l,et(r,t.memoizedState)||(Ce=!0),t.memoizedState=r,t.baseState=s,t.baseQueue=a,n.lastRenderedState=r}if(e=n.interleaved,e!==null){o=e;do i=o.lane,X.lanes|=i,wn|=i,o=o.next;while(o!==e)}else o===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function Vs(e){var t=We(),n=t.queue;if(n===null)throw Error(T(311));n.lastRenderedReducer=e;var r=n.dispatch,o=n.pending,i=t.memoizedState;if(o!==null){n.pending=null;var s=o=o.next;do i=e(i,s.action),s=s.next;while(s!==o);et(i,t.memoizedState)||(Ce=!0),t.memoizedState=i,t.baseQueue===null&&(t.baseState=i),n.lastRenderedState=i}return[i,r]}function rp(){}function op(e,t){var n=X,r=We(),o=t(),i=!et(r.memoizedState,o);if(i&&(r.memoizedState=o,Ce=!0),r=r.queue,au(lp.bind(null,n,r,e),[e]),r.getSnapshot!==t||i||se!==null&&se.memoizedState.tag&1){if(n.flags|=2048,oo(9,sp.bind(null,n,r,o,t),void 0,null),ue===null)throw Error(T(349));vn&30||ip(n,t,o)}return o}function ip(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=X.updateQueue,t===null?(t={lastEffect:null,stores:null},X.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function sp(e,t,n,r){t.value=n,t.getSnapshot=r,ap(t)&&up(e)}function lp(e,t,n){return n(function(){ap(t)&&up(e)})}function ap(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!et(e,n)}catch{return!0}}function up(e){var t=xt(e,1);t!==null&&Je(t,e,1,-1)}function Sc(e){var t=it();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:ro,lastRenderedState:e},t.queue=e,e=e.dispatch=sy.bind(null,X,e),[t.memoizedState,e]}function oo(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=X.updateQueue,t===null?(t={lastEffect:null,stores:null},X.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function cp(){return We().memoizedState}function oi(e,t,n,r){var o=it();X.flags|=e,o.memoizedState=oo(1|t,n,void 0,r===void 0?null:r)}function ts(e,t,n,r){var o=We();r=r===void 0?null:r;var i=void 0;if(oe!==null){var s=oe.memoizedState;if(i=s.destroy,r!==null&&iu(r,s.deps)){o.memoizedState=oo(t,n,i,r);return}}X.flags|=e,o.memoizedState=oo(1|t,n,i,r)}function kc(e,t){return oi(8390656,8,e,t)}function au(e,t){return ts(2048,8,e,t)}function dp(e,t){return ts(4,2,e,t)}function fp(e,t){return ts(4,4,e,t)}function pp(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function hp(e,t,n){return n=n!=null?n.concat([e]):null,ts(4,4,pp.bind(null,t,e),n)}function uu(){}function mp(e,t){var n=We();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&iu(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function gp(e,t){var n=We();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&iu(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function yp(e,t,n){return vn&21?(et(n,t)||(n=kf(),X.lanes|=n,wn|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,Ce=!0),e.memoizedState=n)}function oy(e,t){var n=B;B=n!==0&&4>n?n:4,e(!0);var r=qs.transition;qs.transition={};try{e(!1),t()}finally{B=n,qs.transition=r}}function vp(){return We().memoizedState}function iy(e,t,n){var r=Ut(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},wp(e))xp(t,n);else if(n=ep(e,t,n,r),n!==null){var o=we();Je(n,e,r,o),Sp(n,t,r)}}function sy(e,t,n){var r=Ut(e),o={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(wp(e))xp(t,o);else{var i=e.alternate;if(e.lanes===0&&(i===null||i.lanes===0)&&(i=t.lastRenderedReducer,i!==null))try{var s=t.lastRenderedState,l=i(s,n);if(o.hasEagerState=!0,o.eagerState=l,et(l,s)){var a=t.interleaved;a===null?(o.next=o,eu(t)):(o.next=a.next,a.next=o),t.interleaved=o;return}}catch{}finally{}n=ep(e,t,o,r),n!==null&&(o=we(),Je(n,e,r,o),Sp(n,t,r))}}function wp(e){var t=e.alternate;return e===X||t!==null&&t===X}function xp(e,t){Ir=Ai=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Sp(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Ma(e,n)}}var Li={readContext:He,useCallback:pe,useContext:pe,useEffect:pe,useImperativeHandle:pe,useInsertionEffect:pe,useLayoutEffect:pe,useMemo:pe,useReducer:pe,useRef:pe,useState:pe,useDebugValue:pe,useDeferredValue:pe,useTransition:pe,useMutableSource:pe,useSyncExternalStore:pe,useId:pe,unstable_isNewReconciler:!1},ly={readContext:He,useCallback:function(e,t){return it().memoizedState=[e,t===void 0?null:t],e},useContext:He,useEffect:kc,useImperativeHandle:function(e,t,n){return n=n!=null?n.concat([e]):null,oi(4194308,4,pp.bind(null,t,e),n)},useLayoutEffect:function(e,t){return oi(4194308,4,e,t)},useInsertionEffect:function(e,t){return oi(4,2,e,t)},useMemo:function(e,t){var n=it();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=it();return t=n!==void 0?n(t):t,r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=iy.bind(null,X,e),[r.memoizedState,e]},useRef:function(e){var t=it();return e={current:e},t.memoizedState=e},useState:Sc,useDebugValue:uu,useDeferredValue:function(e){return it().memoizedState=e},useTransition:function(){var e=Sc(!1),t=e[0];return e=oy.bind(null,e[1]),it().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=X,o=it();if(G){if(n===void 0)throw Error(T(407));n=n()}else{if(n=t(),ue===null)throw Error(T(349));vn&30||ip(r,t,n)}o.memoizedState=n;var i={value:n,getSnapshot:t};return o.queue=i,kc(lp.bind(null,r,i,e),[e]),r.flags|=2048,oo(9,sp.bind(null,r,i,n,t),void 0,null),n},useId:function(){var e=it(),t=ue.identifierPrefix;if(G){var n=gt,r=mt;n=(r&~(1<<32-Xe(r)-1)).toString(32)+n,t=":"+t+"R"+n,n=no++,0<n&&(t+="H"+n.toString(32)),t+=":"}else n=ry++,t=":"+t+"r"+n.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},ay={readContext:He,useCallback:mp,useContext:He,useEffect:au,useImperativeHandle:hp,useInsertionEffect:dp,useLayoutEffect:fp,useMemo:gp,useReducer:Qs,useRef:cp,useState:function(){return Qs(ro)},useDebugValue:uu,useDeferredValue:function(e){var t=We();return yp(t,oe.memoizedState,e)},useTransition:function(){var e=Qs(ro)[0],t=We().memoizedState;return[e,t]},useMutableSource:rp,useSyncExternalStore:op,useId:vp,unstable_isNewReconciler:!1},uy={readContext:He,useCallback:mp,useContext:He,useEffect:au,useImperativeHandle:hp,useInsertionEffect:dp,useLayoutEffect:fp,useMemo:gp,useReducer:Vs,useRef:cp,useState:function(){return Vs(ro)},useDebugValue:uu,useDeferredValue:function(e){var t=We();return oe===null?t.memoizedState=e:yp(t,oe.memoizedState,e)},useTransition:function(){var e=Vs(ro)[0],t=We().memoizedState;return[e,t]},useMutableSource:rp,useSyncExternalStore:op,useId:vp,unstable_isNewReconciler:!1};function Ke(e,t){if(e&&e.defaultProps){t=J({},t),e=e.defaultProps;for(var n in e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function Kl(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:J({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var ns={isMounted:function(e){return(e=e._reactInternals)?jn(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=we(),o=Ut(e),i=yt(r,o);i.payload=t,n!=null&&(i.callback=n),t=Mt(e,i,o),t!==null&&(Je(t,e,o,r),ni(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=we(),o=Ut(e),i=yt(r,o);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=Mt(e,i,o),t!==null&&(Je(t,e,o,r),ni(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=we(),r=Ut(e),o=yt(n,r);o.tag=2,t!=null&&(o.callback=t),t=Mt(e,o,r),t!==null&&(Je(t,e,r,n),ni(t,e,r))}};function Ec(e,t,n,r,o,i,s){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(r,i,s):t.prototype&&t.prototype.isPureReactComponent?!Yr(n,r)||!Yr(o,i):!0}function kp(e,t,n){var r=!1,o=Vt,i=t.contextType;return typeof i=="object"&&i!==null?i=He(i):(o=Pe(t)?gn:ye.current,r=t.contextTypes,i=(r=r!=null)?Yn(e,o):Vt),t=new t(n,i),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=ns,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=o,e.__reactInternalMemoizedMaskedChildContext=i),t}function Cc(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&ns.enqueueReplaceState(t,t.state,null)}function Gl(e,t,n,r){var o=e.stateNode;o.props=n,o.state=e.memoizedState,o.refs={},tu(e);var i=t.contextType;typeof i=="object"&&i!==null?o.context=He(i):(i=Pe(t)?gn:ye.current,o.context=Yn(e,i)),o.state=e.memoizedState,i=t.getDerivedStateFromProps,typeof i=="function"&&(Kl(e,t,i,n),o.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(t=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),t!==o.state&&ns.enqueueReplaceState(o,o.state,null),Ni(e,n,o,r),o.state=e.memoizedState),typeof o.componentDidMount=="function"&&(e.flags|=4194308)}function er(e,t){try{var n="",r=t;do n+=Dm(r),r=r.return;while(r);var o=n}catch(i){o=`
Error generating stack: `+i.message+`
`+i.stack}return{value:e,source:t,stack:o,digest:null}}function Ks(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function Yl(e,t){try{console.error(t.value)}catch(n){setTimeout(function(){throw n})}}var cy=typeof WeakMap=="function"?WeakMap:Map;function Ep(e,t,n){n=yt(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){Di||(Di=!0,sa=r),Yl(e,t)},n}function Cp(e,t,n){n=yt(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r=="function"){var o=t.value;n.payload=function(){return r(o)},n.callback=function(){Yl(e,t)}}var i=e.stateNode;return i!==null&&typeof i.componentDidCatch=="function"&&(n.callback=function(){Yl(e,t),typeof r!="function"&&(Bt===null?Bt=new Set([this]):Bt.add(this));var s=t.stack;this.componentDidCatch(t.value,{componentStack:s!==null?s:""})}),n}function jc(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new cy;var o=new Set;r.set(t,o)}else o=r.get(t),o===void 0&&(o=new Set,r.set(t,o));o.has(n)||(o.add(n),e=Cy.bind(null,e,t,n),t.then(e,e))}function Pc(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function bc(e,t,n,r,o){return e.mode&1?(e.flags|=65536,e.lanes=o,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=yt(-1,1),t.tag=2,Mt(n,t,1))),n.lanes|=1),e)}var dy=kt.ReactCurrentOwner,Ce=!1;function ve(e,t,n,r){t.child=e===null?Zf(t,null,n,r):Jn(t,e.child,n,r)}function Tc(e,t,n,r,o){n=n.render;var i=t.ref;return Qn(t,o),r=su(e,t,n,r,i,o),n=lu(),e!==null&&!Ce?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~o,St(e,t,o)):(G&&n&&Ka(t),t.flags|=1,ve(e,t,r,o),t.child)}function Rc(e,t,n,r,o){if(e===null){var i=n.type;return typeof i=="function"&&!yu(i)&&i.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=i,jp(e,t,i,r,o)):(e=ai(n.type,null,r,t,t.mode,o),e.ref=t.ref,e.return=t,t.child=e)}if(i=e.child,!(e.lanes&o)){var s=i.memoizedProps;if(n=n.compare,n=n!==null?n:Yr,n(s,r)&&e.ref===t.ref)return St(e,t,o)}return t.flags|=1,e=Ht(i,r),e.ref=t.ref,e.return=t,t.child=e}function jp(e,t,n,r,o){if(e!==null){var i=e.memoizedProps;if(Yr(i,r)&&e.ref===t.ref)if(Ce=!1,t.pendingProps=r=i,(e.lanes&o)!==0)e.flags&131072&&(Ce=!0);else return t.lanes=e.lanes,St(e,t,o)}return Xl(e,t,n,r,o)}function Pp(e,t,n){var r=t.pendingProps,o=r.children,i=e!==null?e.memoizedState:null;if(r.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},q(Mn,Oe),Oe|=n;else{if(!(n&1073741824))return e=i!==null?i.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,q(Mn,Oe),Oe|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=i!==null?i.baseLanes:n,q(Mn,Oe),Oe|=r}else i!==null?(r=i.baseLanes|n,t.memoizedState=null):r=n,q(Mn,Oe),Oe|=r;return ve(e,t,o,n),t.child}function bp(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Xl(e,t,n,r,o){var i=Pe(n)?gn:ye.current;return i=Yn(t,i),Qn(t,o),n=su(e,t,n,r,i,o),r=lu(),e!==null&&!Ce?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~o,St(e,t,o)):(G&&r&&Ka(t),t.flags|=1,ve(e,t,n,o),t.child)}function $c(e,t,n,r,o){if(Pe(n)){var i=!0;bi(t)}else i=!1;if(Qn(t,o),t.stateNode===null)ii(e,t),kp(t,n,r),Gl(t,n,r,o),r=!0;else if(e===null){var s=t.stateNode,l=t.memoizedProps;s.props=l;var a=s.context,c=n.contextType;typeof c=="object"&&c!==null?c=He(c):(c=Pe(n)?gn:ye.current,c=Yn(t,c));var f=n.getDerivedStateFromProps,d=typeof f=="function"||typeof s.getSnapshotBeforeUpdate=="function";d||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(l!==r||a!==c)&&Cc(t,s,r,c),$t=!1;var m=t.memoizedState;s.state=m,Ni(t,r,s,o),a=t.memoizedState,l!==r||m!==a||je.current||$t?(typeof f=="function"&&(Kl(t,n,f,r),a=t.memoizedState),(l=$t||Ec(t,n,l,r,m,a,c))?(d||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount()),typeof s.componentDidMount=="function"&&(t.flags|=4194308)):(typeof s.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=a),s.props=r,s.state=a,s.context=c,r=l):(typeof s.componentDidMount=="function"&&(t.flags|=4194308),r=!1)}else{s=t.stateNode,tp(e,t),l=t.memoizedProps,c=t.type===t.elementType?l:Ke(t.type,l),s.props=c,d=t.pendingProps,m=s.context,a=n.contextType,typeof a=="object"&&a!==null?a=He(a):(a=Pe(n)?gn:ye.current,a=Yn(t,a));var w=n.getDerivedStateFromProps;(f=typeof w=="function"||typeof s.getSnapshotBeforeUpdate=="function")||typeof s.UNSAFE_componentWillReceiveProps!="function"&&typeof s.componentWillReceiveProps!="function"||(l!==d||m!==a)&&Cc(t,s,r,a),$t=!1,m=t.memoizedState,s.state=m,Ni(t,r,s,o);var y=t.memoizedState;l!==d||m!==y||je.current||$t?(typeof w=="function"&&(Kl(t,n,w,r),y=t.memoizedState),(c=$t||Ec(t,n,c,r,m,y,a)||!1)?(f||typeof s.UNSAFE_componentWillUpdate!="function"&&typeof s.componentWillUpdate!="function"||(typeof s.componentWillUpdate=="function"&&s.componentWillUpdate(r,y,a),typeof s.UNSAFE_componentWillUpdate=="function"&&s.UNSAFE_componentWillUpdate(r,y,a)),typeof s.componentDidUpdate=="function"&&(t.flags|=4),typeof s.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof s.componentDidUpdate!="function"||l===e.memoizedProps&&m===e.memoizedState||(t.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&m===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=y),s.props=r,s.state=y,s.context=a,r=c):(typeof s.componentDidUpdate!="function"||l===e.memoizedProps&&m===e.memoizedState||(t.flags|=4),typeof s.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&m===e.memoizedState||(t.flags|=1024),r=!1)}return Jl(e,t,n,r,i,o)}function Jl(e,t,n,r,o,i){bp(e,t);var s=(t.flags&128)!==0;if(!r&&!s)return o&&mc(t,n,!1),St(e,t,i);r=t.stateNode,dy.current=t;var l=s&&typeof n.getDerivedStateFromError!="function"?null:r.render();return t.flags|=1,e!==null&&s?(t.child=Jn(t,e.child,null,i),t.child=Jn(t,null,l,i)):ve(e,t,l,i),t.memoizedState=r.state,o&&mc(t,n,!0),t.child}function Tp(e){var t=e.stateNode;t.pendingContext?hc(e,t.pendingContext,t.pendingContext!==t.context):t.context&&hc(e,t.context,!1),nu(e,t.containerInfo)}function _c(e,t,n,r,o){return Xn(),Ya(o),t.flags|=256,ve(e,t,n,r),t.child}var Zl={dehydrated:null,treeContext:null,retryLane:0};function ea(e){return{baseLanes:e,cachePool:null,transitions:null}}function Rp(e,t,n){var r=t.pendingProps,o=Y.current,i=!1,s=(t.flags&128)!==0,l;if((l=s)||(l=e!==null&&e.memoizedState===null?!1:(o&2)!==0),l?(i=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(o|=1),q(Y,o&1),e===null)return Ql(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(s=r.children,e=r.fallback,i?(r=t.mode,i=t.child,s={mode:"hidden",children:s},!(r&1)&&i!==null?(i.childLanes=0,i.pendingProps=s):i=is(s,r,0,null),e=pn(e,r,n,null),i.return=t,e.return=t,i.sibling=e,t.child=i,t.child.memoizedState=ea(n),t.memoizedState=Zl,e):cu(t,s));if(o=e.memoizedState,o!==null&&(l=o.dehydrated,l!==null))return fy(e,t,s,r,l,o,n);if(i){i=r.fallback,s=t.mode,o=e.child,l=o.sibling;var a={mode:"hidden",children:r.children};return!(s&1)&&t.child!==o?(r=t.child,r.childLanes=0,r.pendingProps=a,t.deletions=null):(r=Ht(o,a),r.subtreeFlags=o.subtreeFlags&14680064),l!==null?i=Ht(l,i):(i=pn(i,s,n,null),i.flags|=2),i.return=t,r.return=t,r.sibling=i,t.child=r,r=i,i=t.child,s=e.child.memoizedState,s=s===null?ea(n):{baseLanes:s.baseLanes|n,cachePool:null,transitions:s.transitions},i.memoizedState=s,i.childLanes=e.childLanes&~n,t.memoizedState=Zl,r}return i=e.child,e=i.sibling,r=Ht(i,{mode:"visible",children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function cu(e,t){return t=is({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function Do(e,t,n,r){return r!==null&&Ya(r),Jn(t,e.child,null,n),e=cu(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function fy(e,t,n,r,o,i,s){if(n)return t.flags&256?(t.flags&=-257,r=Ks(Error(T(422))),Do(e,t,s,r)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(i=r.fallback,o=t.mode,r=is({mode:"visible",children:r.children},o,0,null),i=pn(i,o,s,null),i.flags|=2,r.return=t,i.return=t,r.sibling=i,t.child=r,t.mode&1&&Jn(t,e.child,null,s),t.child.memoizedState=ea(s),t.memoizedState=Zl,i);if(!(t.mode&1))return Do(e,t,s,null);if(o.data==="$!"){if(r=o.nextSibling&&o.nextSibling.dataset,r)var l=r.dgst;return r=l,i=Error(T(419)),r=Ks(i,r,void 0),Do(e,t,s,r)}if(l=(s&e.childLanes)!==0,Ce||l){if(r=ue,r!==null){switch(s&-s){case 4:o=2;break;case 16:o=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:o=32;break;case 536870912:o=268435456;break;default:o=0}o=o&(r.suspendedLanes|s)?0:o,o!==0&&o!==i.retryLane&&(i.retryLane=o,xt(e,o),Je(r,e,o,-1))}return gu(),r=Ks(Error(T(421))),Do(e,t,s,r)}return o.data==="$?"?(t.flags|=128,t.child=e.child,t=jy.bind(null,e),o._reactRetry=t,null):(e=i.treeContext,Ae=Ft(o.nextSibling),Le=t,G=!0,Ye=null,e!==null&&(Fe[Me++]=mt,Fe[Me++]=gt,Fe[Me++]=yn,mt=e.id,gt=e.overflow,yn=t),t=cu(t,r.children),t.flags|=4096,t)}function Nc(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),Vl(e.return,t,n)}function Gs(e,t,n,r,o){var i=e.memoizedState;i===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:o}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=r,i.tail=n,i.tailMode=o)}function $p(e,t,n){var r=t.pendingProps,o=r.revealOrder,i=r.tail;if(ve(e,t,r.children,n),r=Y.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Nc(e,n,t);else if(e.tag===19)Nc(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(q(Y,r),!(t.mode&1))t.memoizedState=null;else switch(o){case"forwards":for(n=t.child,o=null;n!==null;)e=n.alternate,e!==null&&Oi(e)===null&&(o=n),n=n.sibling;n=o,n===null?(o=t.child,t.child=null):(o=n.sibling,n.sibling=null),Gs(t,!1,o,n,i);break;case"backwards":for(n=null,o=t.child,t.child=null;o!==null;){if(e=o.alternate,e!==null&&Oi(e)===null){t.child=o;break}e=o.sibling,o.sibling=n,n=o,o=e}Gs(t,!0,n,null,i);break;case"together":Gs(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function ii(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function St(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),wn|=t.lanes,!(n&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(T(153));if(t.child!==null){for(e=t.child,n=Ht(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=Ht(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function py(e,t,n){switch(t.tag){case 3:Tp(t),Xn();break;case 5:np(t);break;case 1:Pe(t.type)&&bi(t);break;case 4:nu(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,o=t.memoizedProps.value;q($i,r._currentValue),r._currentValue=o;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated!==null?(q(Y,Y.current&1),t.flags|=128,null):n&t.child.childLanes?Rp(e,t,n):(q(Y,Y.current&1),e=St(e,t,n),e!==null?e.sibling:null);q(Y,Y.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return $p(e,t,n);t.flags|=128}if(o=t.memoizedState,o!==null&&(o.rendering=null,o.tail=null,o.lastEffect=null),q(Y,Y.current),r)break;return null;case 22:case 23:return t.lanes=0,Pp(e,t,n)}return St(e,t,n)}var _p,ta,Np,Op;_p=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};ta=function(){};Np=function(e,t,n,r){var o=e.memoizedProps;if(o!==r){e=t.stateNode,an(ut.current);var i=null;switch(n){case"input":o=El(e,o),r=El(e,r),i=[];break;case"select":o=J({},o,{value:void 0}),r=J({},r,{value:void 0}),i=[];break;case"textarea":o=Pl(e,o),r=Pl(e,r),i=[];break;default:typeof o.onClick!="function"&&typeof r.onClick=="function"&&(e.onclick=ji)}Tl(n,r);var s;n=null;for(c in o)if(!r.hasOwnProperty(c)&&o.hasOwnProperty(c)&&o[c]!=null)if(c==="style"){var l=o[c];for(s in l)l.hasOwnProperty(s)&&(n||(n={}),n[s]="")}else c!=="dangerouslySetInnerHTML"&&c!=="children"&&c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&c!=="autoFocus"&&(Hr.hasOwnProperty(c)?i||(i=[]):(i=i||[]).push(c,null));for(c in r){var a=r[c];if(l=o!=null?o[c]:void 0,r.hasOwnProperty(c)&&a!==l&&(a!=null||l!=null))if(c==="style")if(l){for(s in l)!l.hasOwnProperty(s)||a&&a.hasOwnProperty(s)||(n||(n={}),n[s]="");for(s in a)a.hasOwnProperty(s)&&l[s]!==a[s]&&(n||(n={}),n[s]=a[s])}else n||(i||(i=[]),i.push(c,n)),n=a;else c==="dangerouslySetInnerHTML"?(a=a?a.__html:void 0,l=l?l.__html:void 0,a!=null&&l!==a&&(i=i||[]).push(c,a)):c==="children"?typeof a!="string"&&typeof a!="number"||(i=i||[]).push(c,""+a):c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&(Hr.hasOwnProperty(c)?(a!=null&&c==="onScroll"&&Q("scroll",e),i||l===a||(i=[])):(i=i||[]).push(c,a))}n&&(i=i||[]).push("style",n);var c=i;(t.updateQueue=c)&&(t.flags|=4)}};Op=function(e,t,n,r){n!==r&&(t.flags|=4)};function kr(e,t){if(!G)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function he(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var o=e.child;o!==null;)n|=o.lanes|o.childLanes,r|=o.subtreeFlags&14680064,r|=o.flags&14680064,o.return=e,o=o.sibling;else for(o=e.child;o!==null;)n|=o.lanes|o.childLanes,r|=o.subtreeFlags,r|=o.flags,o.return=e,o=o.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function hy(e,t,n){var r=t.pendingProps;switch(Ga(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return he(t),null;case 1:return Pe(t.type)&&Pi(),he(t),null;case 3:return r=t.stateNode,Zn(),K(je),K(ye),ou(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Lo(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Ye!==null&&(ua(Ye),Ye=null))),ta(e,t),he(t),null;case 5:ru(t);var o=an(to.current);if(n=t.type,e!==null&&t.stateNode!=null)Np(e,t,n,r,o),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(T(166));return he(t),null}if(e=an(ut.current),Lo(t)){r=t.stateNode,n=t.type;var i=t.memoizedProps;switch(r[lt]=t,r[Zr]=i,e=(t.mode&1)!==0,n){case"dialog":Q("cancel",r),Q("close",r);break;case"iframe":case"object":case"embed":Q("load",r);break;case"video":case"audio":for(o=0;o<_r.length;o++)Q(_r[o],r);break;case"source":Q("error",r);break;case"img":case"image":case"link":Q("error",r),Q("load",r);break;case"details":Q("toggle",r);break;case"input":Bu(r,i),Q("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!i.multiple},Q("invalid",r);break;case"textarea":Hu(r,i),Q("invalid",r)}Tl(n,i),o=null;for(var s in i)if(i.hasOwnProperty(s)){var l=i[s];s==="children"?typeof l=="string"?r.textContent!==l&&(i.suppressHydrationWarning!==!0&&Ao(r.textContent,l,e),o=["children",l]):typeof l=="number"&&r.textContent!==""+l&&(i.suppressHydrationWarning!==!0&&Ao(r.textContent,l,e),o=["children",""+l]):Hr.hasOwnProperty(s)&&l!=null&&s==="onScroll"&&Q("scroll",r)}switch(n){case"input":Po(r),Uu(r,i,!0);break;case"textarea":Po(r),Wu(r);break;case"select":case"option":break;default:typeof i.onClick=="function"&&(r.onclick=ji)}r=o,t.updateQueue=r,r!==null&&(t.flags|=4)}else{s=o.nodeType===9?o:o.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=lf(n)),e==="http://www.w3.org/1999/xhtml"?n==="script"?(e=s.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof r.is=="string"?e=s.createElement(n,{is:r.is}):(e=s.createElement(n),n==="select"&&(s=e,r.multiple?s.multiple=!0:r.size&&(s.size=r.size))):e=s.createElementNS(e,n),e[lt]=t,e[Zr]=r,_p(e,t,!1,!1),t.stateNode=e;e:{switch(s=Rl(n,r),n){case"dialog":Q("cancel",e),Q("close",e),o=r;break;case"iframe":case"object":case"embed":Q("load",e),o=r;break;case"video":case"audio":for(o=0;o<_r.length;o++)Q(_r[o],e);o=r;break;case"source":Q("error",e),o=r;break;case"img":case"image":case"link":Q("error",e),Q("load",e),o=r;break;case"details":Q("toggle",e),o=r;break;case"input":Bu(e,r),o=El(e,r),Q("invalid",e);break;case"option":o=r;break;case"select":e._wrapperState={wasMultiple:!!r.multiple},o=J({},r,{value:void 0}),Q("invalid",e);break;case"textarea":Hu(e,r),o=Pl(e,r),Q("invalid",e);break;default:o=r}Tl(n,o),l=o;for(i in l)if(l.hasOwnProperty(i)){var a=l[i];i==="style"?cf(e,a):i==="dangerouslySetInnerHTML"?(a=a?a.__html:void 0,a!=null&&af(e,a)):i==="children"?typeof a=="string"?(n!=="textarea"||a!=="")&&Wr(e,a):typeof a=="number"&&Wr(e,""+a):i!=="suppressContentEditableWarning"&&i!=="suppressHydrationWarning"&&i!=="autoFocus"&&(Hr.hasOwnProperty(i)?a!=null&&i==="onScroll"&&Q("scroll",e):a!=null&&Aa(e,i,a,s))}switch(n){case"input":Po(e),Uu(e,r,!1);break;case"textarea":Po(e),Wu(e);break;case"option":r.value!=null&&e.setAttribute("value",""+Qt(r.value));break;case"select":e.multiple=!!r.multiple,i=r.value,i!=null?Un(e,!!r.multiple,i,!1):r.defaultValue!=null&&Un(e,!!r.multiple,r.defaultValue,!0);break;default:typeof o.onClick=="function"&&(e.onclick=ji)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return he(t),null;case 6:if(e&&t.stateNode!=null)Op(e,t,e.memoizedProps,r);else{if(typeof r!="string"&&t.stateNode===null)throw Error(T(166));if(n=an(to.current),an(ut.current),Lo(t)){if(r=t.stateNode,n=t.memoizedProps,r[lt]=t,(i=r.nodeValue!==n)&&(e=Le,e!==null))switch(e.tag){case 3:Ao(r.nodeValue,n,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&Ao(r.nodeValue,n,(e.mode&1)!==0)}i&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[lt]=t,t.stateNode=r}return he(t),null;case 13:if(K(Y),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(G&&Ae!==null&&t.mode&1&&!(t.flags&128))Xf(),Xn(),t.flags|=98560,i=!1;else if(i=Lo(t),r!==null&&r.dehydrated!==null){if(e===null){if(!i)throw Error(T(318));if(i=t.memoizedState,i=i!==null?i.dehydrated:null,!i)throw Error(T(317));i[lt]=t}else Xn(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;he(t),i=!1}else Ye!==null&&(ua(Ye),Ye=null),i=!0;if(!i)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||Y.current&1?ie===0&&(ie=3):gu())),t.updateQueue!==null&&(t.flags|=4),he(t),null);case 4:return Zn(),ta(e,t),e===null&&Xr(t.stateNode.containerInfo),he(t),null;case 10:return Za(t.type._context),he(t),null;case 17:return Pe(t.type)&&Pi(),he(t),null;case 19:if(K(Y),i=t.memoizedState,i===null)return he(t),null;if(r=(t.flags&128)!==0,s=i.rendering,s===null)if(r)kr(i,!1);else{if(ie!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(s=Oi(e),s!==null){for(t.flags|=128,kr(i,!1),r=s.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)i=n,e=r,i.flags&=14680066,s=i.alternate,s===null?(i.childLanes=0,i.lanes=e,i.child=null,i.subtreeFlags=0,i.memoizedProps=null,i.memoizedState=null,i.updateQueue=null,i.dependencies=null,i.stateNode=null):(i.childLanes=s.childLanes,i.lanes=s.lanes,i.child=s.child,i.subtreeFlags=0,i.deletions=null,i.memoizedProps=s.memoizedProps,i.memoizedState=s.memoizedState,i.updateQueue=s.updateQueue,i.type=s.type,e=s.dependencies,i.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return q(Y,Y.current&1|2),t.child}e=e.sibling}i.tail!==null&&ee()>tr&&(t.flags|=128,r=!0,kr(i,!1),t.lanes=4194304)}else{if(!r)if(e=Oi(s),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),kr(i,!0),i.tail===null&&i.tailMode==="hidden"&&!s.alternate&&!G)return he(t),null}else 2*ee()-i.renderingStartTime>tr&&n!==1073741824&&(t.flags|=128,r=!0,kr(i,!1),t.lanes=4194304);i.isBackwards?(s.sibling=t.child,t.child=s):(n=i.last,n!==null?n.sibling=s:t.child=s,i.last=s)}return i.tail!==null?(t=i.tail,i.rendering=t,i.tail=t.sibling,i.renderingStartTime=ee(),t.sibling=null,n=Y.current,q(Y,r?n&1|2:n&1),t):(he(t),null);case 22:case 23:return mu(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?Oe&1073741824&&(he(t),t.subtreeFlags&6&&(t.flags|=8192)):he(t),null;case 24:return null;case 25:return null}throw Error(T(156,t.tag))}function my(e,t){switch(Ga(t),t.tag){case 1:return Pe(t.type)&&Pi(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Zn(),K(je),K(ye),ou(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return ru(t),null;case 13:if(K(Y),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(T(340));Xn()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return K(Y),null;case 4:return Zn(),null;case 10:return Za(t.type._context),null;case 22:case 23:return mu(),null;case 24:return null;default:return null}}var Io=!1,me=!1,gy=typeof WeakSet=="function"?WeakSet:Set,$=null;function Fn(e,t){var n=e.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){Z(e,t,r)}else n.current=null}function na(e,t,n){try{n()}catch(r){Z(e,t,r)}}var Oc=!1;function yy(e,t){if(Fl=ki,e=If(),Va(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var o=r.anchorOffset,i=r.focusNode;r=r.focusOffset;try{n.nodeType,i.nodeType}catch{n=null;break e}var s=0,l=-1,a=-1,c=0,f=0,d=e,m=null;t:for(;;){for(var w;d!==n||o!==0&&d.nodeType!==3||(l=s+o),d!==i||r!==0&&d.nodeType!==3||(a=s+r),d.nodeType===3&&(s+=d.nodeValue.length),(w=d.firstChild)!==null;)m=d,d=w;for(;;){if(d===e)break t;if(m===n&&++c===o&&(l=s),m===i&&++f===r&&(a=s),(w=d.nextSibling)!==null)break;d=m,m=d.parentNode}d=w}n=l===-1||a===-1?null:{start:l,end:a}}else n=null}n=n||{start:0,end:0}}else n=null;for(Ml={focusedElem:e,selectionRange:n},ki=!1,$=t;$!==null;)if(t=$,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,$=e;else for(;$!==null;){t=$;try{var y=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(y!==null){var v=y.memoizedProps,x=y.memoizedState,h=t.stateNode,p=h.getSnapshotBeforeUpdate(t.elementType===t.type?v:Ke(t.type,v),x);h.__reactInternalSnapshotBeforeUpdate=p}break;case 3:var g=t.stateNode.containerInfo;g.nodeType===1?g.textContent="":g.nodeType===9&&g.documentElement&&g.removeChild(g.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(T(163))}}catch(S){Z(t,t.return,S)}if(e=t.sibling,e!==null){e.return=t.return,$=e;break}$=t.return}return y=Oc,Oc=!1,y}function Fr(e,t,n){var r=t.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var o=r=r.next;do{if((o.tag&e)===e){var i=o.destroy;o.destroy=void 0,i!==void 0&&na(t,n,i)}o=o.next}while(o!==r)}}function rs(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function ra(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t=="function"?t(e):t.current=e}}function Ap(e){var t=e.alternate;t!==null&&(e.alternate=null,Ap(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[lt],delete t[Zr],delete t[Hl],delete t[Zg],delete t[ey])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function Lp(e){return e.tag===5||e.tag===3||e.tag===4}function Ac(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Lp(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function oa(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=ji));else if(r!==4&&(e=e.child,e!==null))for(oa(e,t,n),e=e.sibling;e!==null;)oa(e,t,n),e=e.sibling}function ia(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(ia(e,t,n),e=e.sibling;e!==null;)ia(e,t,n),e=e.sibling}var ce=null,Ge=!1;function bt(e,t,n){for(n=n.child;n!==null;)zp(e,t,n),n=n.sibling}function zp(e,t,n){if(at&&typeof at.onCommitFiberUnmount=="function")try{at.onCommitFiberUnmount(Gi,n)}catch{}switch(n.tag){case 5:me||Fn(n,t);case 6:var r=ce,o=Ge;ce=null,bt(e,t,n),ce=r,Ge=o,ce!==null&&(Ge?(e=ce,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):ce.removeChild(n.stateNode));break;case 18:ce!==null&&(Ge?(e=ce,n=n.stateNode,e.nodeType===8?Us(e.parentNode,n):e.nodeType===1&&Us(e,n),Kr(e)):Us(ce,n.stateNode));break;case 4:r=ce,o=Ge,ce=n.stateNode.containerInfo,Ge=!0,bt(e,t,n),ce=r,Ge=o;break;case 0:case 11:case 14:case 15:if(!me&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){o=r=r.next;do{var i=o,s=i.destroy;i=i.tag,s!==void 0&&(i&2||i&4)&&na(n,t,s),o=o.next}while(o!==r)}bt(e,t,n);break;case 1:if(!me&&(Fn(n,t),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(l){Z(n,t,l)}bt(e,t,n);break;case 21:bt(e,t,n);break;case 22:n.mode&1?(me=(r=me)||n.memoizedState!==null,bt(e,t,n),me=r):bt(e,t,n);break;default:bt(e,t,n)}}function Lc(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new gy),t.forEach(function(r){var o=Py.bind(null,e,r);n.has(r)||(n.add(r),r.then(o,o))})}}function Ve(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var o=n[r];try{var i=e,s=t,l=s;e:for(;l!==null;){switch(l.tag){case 5:ce=l.stateNode,Ge=!1;break e;case 3:ce=l.stateNode.containerInfo,Ge=!0;break e;case 4:ce=l.stateNode.containerInfo,Ge=!0;break e}l=l.return}if(ce===null)throw Error(T(160));zp(i,s,o),ce=null,Ge=!1;var a=o.alternate;a!==null&&(a.return=null),o.return=null}catch(c){Z(o,t,c)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Dp(t,e),t=t.sibling}function Dp(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Ve(t,e),nt(e),r&4){try{Fr(3,e,e.return),rs(3,e)}catch(v){Z(e,e.return,v)}try{Fr(5,e,e.return)}catch(v){Z(e,e.return,v)}}break;case 1:Ve(t,e),nt(e),r&512&&n!==null&&Fn(n,n.return);break;case 5:if(Ve(t,e),nt(e),r&512&&n!==null&&Fn(n,n.return),e.flags&32){var o=e.stateNode;try{Wr(o,"")}catch(v){Z(e,e.return,v)}}if(r&4&&(o=e.stateNode,o!=null)){var i=e.memoizedProps,s=n!==null?n.memoizedProps:i,l=e.type,a=e.updateQueue;if(e.updateQueue=null,a!==null)try{l==="input"&&i.type==="radio"&&i.name!=null&&of(o,i),Rl(l,s);var c=Rl(l,i);for(s=0;s<a.length;s+=2){var f=a[s],d=a[s+1];f==="style"?cf(o,d):f==="dangerouslySetInnerHTML"?af(o,d):f==="children"?Wr(o,d):Aa(o,f,d,c)}switch(l){case"input":Cl(o,i);break;case"textarea":sf(o,i);break;case"select":var m=o._wrapperState.wasMultiple;o._wrapperState.wasMultiple=!!i.multiple;var w=i.value;w!=null?Un(o,!!i.multiple,w,!1):m!==!!i.multiple&&(i.defaultValue!=null?Un(o,!!i.multiple,i.defaultValue,!0):Un(o,!!i.multiple,i.multiple?[]:"",!1))}o[Zr]=i}catch(v){Z(e,e.return,v)}}break;case 6:if(Ve(t,e),nt(e),r&4){if(e.stateNode===null)throw Error(T(162));o=e.stateNode,i=e.memoizedProps;try{o.nodeValue=i}catch(v){Z(e,e.return,v)}}break;case 3:if(Ve(t,e),nt(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Kr(t.containerInfo)}catch(v){Z(e,e.return,v)}break;case 4:Ve(t,e),nt(e);break;case 13:Ve(t,e),nt(e),o=e.child,o.flags&8192&&(i=o.memoizedState!==null,o.stateNode.isHidden=i,!i||o.alternate!==null&&o.alternate.memoizedState!==null||(pu=ee())),r&4&&Lc(e);break;case 22:if(f=n!==null&&n.memoizedState!==null,e.mode&1?(me=(c=me)||f,Ve(t,e),me=c):Ve(t,e),nt(e),r&8192){if(c=e.memoizedState!==null,(e.stateNode.isHidden=c)&&!f&&e.mode&1)for($=e,f=e.child;f!==null;){for(d=$=f;$!==null;){switch(m=$,w=m.child,m.tag){case 0:case 11:case 14:case 15:Fr(4,m,m.return);break;case 1:Fn(m,m.return);var y=m.stateNode;if(typeof y.componentWillUnmount=="function"){r=m,n=m.return;try{t=r,y.props=t.memoizedProps,y.state=t.memoizedState,y.componentWillUnmount()}catch(v){Z(r,n,v)}}break;case 5:Fn(m,m.return);break;case 22:if(m.memoizedState!==null){Dc(d);continue}}w!==null?(w.return=m,$=w):Dc(d)}f=f.sibling}e:for(f=null,d=e;;){if(d.tag===5){if(f===null){f=d;try{o=d.stateNode,c?(i=o.style,typeof i.setProperty=="function"?i.setProperty("display","none","important"):i.display="none"):(l=d.stateNode,a=d.memoizedProps.style,s=a!=null&&a.hasOwnProperty("display")?a.display:null,l.style.display=uf("display",s))}catch(v){Z(e,e.return,v)}}}else if(d.tag===6){if(f===null)try{d.stateNode.nodeValue=c?"":d.memoizedProps}catch(v){Z(e,e.return,v)}}else if((d.tag!==22&&d.tag!==23||d.memoizedState===null||d===e)&&d.child!==null){d.child.return=d,d=d.child;continue}if(d===e)break e;for(;d.sibling===null;){if(d.return===null||d.return===e)break e;f===d&&(f=null),d=d.return}f===d&&(f=null),d.sibling.return=d.return,d=d.sibling}}break;case 19:Ve(t,e),nt(e),r&4&&Lc(e);break;case 21:break;default:Ve(t,e),nt(e)}}function nt(e){var t=e.flags;if(t&2){try{e:{for(var n=e.return;n!==null;){if(Lp(n)){var r=n;break e}n=n.return}throw Error(T(160))}switch(r.tag){case 5:var o=r.stateNode;r.flags&32&&(Wr(o,""),r.flags&=-33);var i=Ac(e);ia(e,i,o);break;case 3:case 4:var s=r.stateNode.containerInfo,l=Ac(e);oa(e,l,s);break;default:throw Error(T(161))}}catch(a){Z(e,e.return,a)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function vy(e,t,n){$=e,Ip(e)}function Ip(e,t,n){for(var r=(e.mode&1)!==0;$!==null;){var o=$,i=o.child;if(o.tag===22&&r){var s=o.memoizedState!==null||Io;if(!s){var l=o.alternate,a=l!==null&&l.memoizedState!==null||me;l=Io;var c=me;if(Io=s,(me=a)&&!c)for($=o;$!==null;)s=$,a=s.child,s.tag===22&&s.memoizedState!==null?Ic(o):a!==null?(a.return=s,$=a):Ic(o);for(;i!==null;)$=i,Ip(i),i=i.sibling;$=o,Io=l,me=c}zc(e)}else o.subtreeFlags&8772&&i!==null?(i.return=o,$=i):zc(e)}}function zc(e){for(;$!==null;){var t=$;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:me||rs(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!me)if(n===null)r.componentDidMount();else{var o=t.elementType===t.type?n.memoizedProps:Ke(t.type,n.memoizedProps);r.componentDidUpdate(o,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var i=t.updateQueue;i!==null&&xc(t,i,r);break;case 3:var s=t.updateQueue;if(s!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}xc(t,s,n)}break;case 5:var l=t.stateNode;if(n===null&&t.flags&4){n=l;var a=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":a.autoFocus&&n.focus();break;case"img":a.src&&(n.src=a.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var c=t.alternate;if(c!==null){var f=c.memoizedState;if(f!==null){var d=f.dehydrated;d!==null&&Kr(d)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(T(163))}me||t.flags&512&&ra(t)}catch(m){Z(t,t.return,m)}}if(t===e){$=null;break}if(n=t.sibling,n!==null){n.return=t.return,$=n;break}$=t.return}}function Dc(e){for(;$!==null;){var t=$;if(t===e){$=null;break}var n=t.sibling;if(n!==null){n.return=t.return,$=n;break}$=t.return}}function Ic(e){for(;$!==null;){var t=$;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{rs(4,t)}catch(a){Z(t,n,a)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount=="function"){var o=t.return;try{r.componentDidMount()}catch(a){Z(t,o,a)}}var i=t.return;try{ra(t)}catch(a){Z(t,i,a)}break;case 5:var s=t.return;try{ra(t)}catch(a){Z(t,s,a)}}}catch(a){Z(t,t.return,a)}if(t===e){$=null;break}var l=t.sibling;if(l!==null){l.return=t.return,$=l;break}$=t.return}}var wy=Math.ceil,zi=kt.ReactCurrentDispatcher,du=kt.ReactCurrentOwner,Ue=kt.ReactCurrentBatchConfig,I=0,ue=null,re=null,de=0,Oe=0,Mn=Gt(0),ie=0,io=null,wn=0,os=0,fu=0,Mr=null,ke=null,pu=0,tr=1/0,ft=null,Di=!1,sa=null,Bt=null,Fo=!1,At=null,Ii=0,Br=0,la=null,si=-1,li=0;function we(){return I&6?ee():si!==-1?si:si=ee()}function Ut(e){return e.mode&1?I&2&&de!==0?de&-de:ny.transition!==null?(li===0&&(li=kf()),li):(e=B,e!==0||(e=window.event,e=e===void 0?16:Rf(e.type)),e):1}function Je(e,t,n,r){if(50<Br)throw Br=0,la=null,Error(T(185));ho(e,n,r),(!(I&2)||e!==ue)&&(e===ue&&(!(I&2)&&(os|=n),ie===4&&Nt(e,de)),be(e,r),n===1&&I===0&&!(t.mode&1)&&(tr=ee()+500,es&&Yt()))}function be(e,t){var n=e.callbackNode;ng(e,t);var r=Si(e,e===ue?de:0);if(r===0)n!==null&&Vu(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&Vu(n),t===1)e.tag===0?ty(Fc.bind(null,e)):Kf(Fc.bind(null,e)),Xg(function(){!(I&6)&&Yt()}),n=null;else{switch(Ef(r)){case 1:n=Fa;break;case 4:n=xf;break;case 16:n=xi;break;case 536870912:n=Sf;break;default:n=xi}n=Qp(n,Fp.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function Fp(e,t){if(si=-1,li=0,I&6)throw Error(T(327));var n=e.callbackNode;if(Vn()&&e.callbackNode!==n)return null;var r=Si(e,e===ue?de:0);if(r===0)return null;if(r&30||r&e.expiredLanes||t)t=Fi(e,r);else{t=r;var o=I;I|=2;var i=Bp();(ue!==e||de!==t)&&(ft=null,tr=ee()+500,fn(e,t));do try{ky();break}catch(l){Mp(e,l)}while(!0);Ja(),zi.current=i,I=o,re!==null?t=0:(ue=null,de=0,t=ie)}if(t!==0){if(t===2&&(o=Al(e),o!==0&&(r=o,t=aa(e,o))),t===1)throw n=io,fn(e,0),Nt(e,r),be(e,ee()),n;if(t===6)Nt(e,r);else{if(o=e.current.alternate,!(r&30)&&!xy(o)&&(t=Fi(e,r),t===2&&(i=Al(e),i!==0&&(r=i,t=aa(e,i))),t===1))throw n=io,fn(e,0),Nt(e,r),be(e,ee()),n;switch(e.finishedWork=o,e.finishedLanes=r,t){case 0:case 1:throw Error(T(345));case 2:on(e,ke,ft);break;case 3:if(Nt(e,r),(r&130023424)===r&&(t=pu+500-ee(),10<t)){if(Si(e,0)!==0)break;if(o=e.suspendedLanes,(o&r)!==r){we(),e.pingedLanes|=e.suspendedLanes&o;break}e.timeoutHandle=Ul(on.bind(null,e,ke,ft),t);break}on(e,ke,ft);break;case 4:if(Nt(e,r),(r&4194240)===r)break;for(t=e.eventTimes,o=-1;0<r;){var s=31-Xe(r);i=1<<s,s=t[s],s>o&&(o=s),r&=~i}if(r=o,r=ee()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*wy(r/1960))-r,10<r){e.timeoutHandle=Ul(on.bind(null,e,ke,ft),r);break}on(e,ke,ft);break;case 5:on(e,ke,ft);break;default:throw Error(T(329))}}}return be(e,ee()),e.callbackNode===n?Fp.bind(null,e):null}function aa(e,t){var n=Mr;return e.current.memoizedState.isDehydrated&&(fn(e,t).flags|=256),e=Fi(e,t),e!==2&&(t=ke,ke=n,t!==null&&ua(t)),e}function ua(e){ke===null?ke=e:ke.push.apply(ke,e)}function xy(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var o=n[r],i=o.getSnapshot;o=o.value;try{if(!et(i(),o))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Nt(e,t){for(t&=~fu,t&=~os,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Xe(t),r=1<<n;e[n]=-1,t&=~r}}function Fc(e){if(I&6)throw Error(T(327));Vn();var t=Si(e,0);if(!(t&1))return be(e,ee()),null;var n=Fi(e,t);if(e.tag!==0&&n===2){var r=Al(e);r!==0&&(t=r,n=aa(e,r))}if(n===1)throw n=io,fn(e,0),Nt(e,t),be(e,ee()),n;if(n===6)throw Error(T(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,on(e,ke,ft),be(e,ee()),null}function hu(e,t){var n=I;I|=1;try{return e(t)}finally{I=n,I===0&&(tr=ee()+500,es&&Yt())}}function xn(e){At!==null&&At.tag===0&&!(I&6)&&Vn();var t=I;I|=1;var n=Ue.transition,r=B;try{if(Ue.transition=null,B=1,e)return e()}finally{B=r,Ue.transition=n,I=t,!(I&6)&&Yt()}}function mu(){Oe=Mn.current,K(Mn)}function fn(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Yg(n)),re!==null)for(n=re.return;n!==null;){var r=n;switch(Ga(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Pi();break;case 3:Zn(),K(je),K(ye),ou();break;case 5:ru(r);break;case 4:Zn();break;case 13:K(Y);break;case 19:K(Y);break;case 10:Za(r.type._context);break;case 22:case 23:mu()}n=n.return}if(ue=e,re=e=Ht(e.current,null),de=Oe=t,ie=0,io=null,fu=os=wn=0,ke=Mr=null,ln!==null){for(t=0;t<ln.length;t++)if(n=ln[t],r=n.interleaved,r!==null){n.interleaved=null;var o=r.next,i=n.pending;if(i!==null){var s=i.next;i.next=o,r.next=s}n.pending=r}ln=null}return e}function Mp(e,t){do{var n=re;try{if(Ja(),ri.current=Li,Ai){for(var r=X.memoizedState;r!==null;){var o=r.queue;o!==null&&(o.pending=null),r=r.next}Ai=!1}if(vn=0,se=oe=X=null,Ir=!1,no=0,du.current=null,n===null||n.return===null){ie=1,io=t,re=null;break}e:{var i=e,s=n.return,l=n,a=t;if(t=de,l.flags|=32768,a!==null&&typeof a=="object"&&typeof a.then=="function"){var c=a,f=l,d=f.tag;if(!(f.mode&1)&&(d===0||d===11||d===15)){var m=f.alternate;m?(f.updateQueue=m.updateQueue,f.memoizedState=m.memoizedState,f.lanes=m.lanes):(f.updateQueue=null,f.memoizedState=null)}var w=Pc(s);if(w!==null){w.flags&=-257,bc(w,s,l,i,t),w.mode&1&&jc(i,c,t),t=w,a=c;var y=t.updateQueue;if(y===null){var v=new Set;v.add(a),t.updateQueue=v}else y.add(a);break e}else{if(!(t&1)){jc(i,c,t),gu();break e}a=Error(T(426))}}else if(G&&l.mode&1){var x=Pc(s);if(x!==null){!(x.flags&65536)&&(x.flags|=256),bc(x,s,l,i,t),Ya(er(a,l));break e}}i=a=er(a,l),ie!==4&&(ie=2),Mr===null?Mr=[i]:Mr.push(i),i=s;do{switch(i.tag){case 3:i.flags|=65536,t&=-t,i.lanes|=t;var h=Ep(i,a,t);wc(i,h);break e;case 1:l=a;var p=i.type,g=i.stateNode;if(!(i.flags&128)&&(typeof p.getDerivedStateFromError=="function"||g!==null&&typeof g.componentDidCatch=="function"&&(Bt===null||!Bt.has(g)))){i.flags|=65536,t&=-t,i.lanes|=t;var S=Cp(i,l,t);wc(i,S);break e}}i=i.return}while(i!==null)}Hp(n)}catch(C){t=C,re===n&&n!==null&&(re=n=n.return);continue}break}while(!0)}function Bp(){var e=zi.current;return zi.current=Li,e===null?Li:e}function gu(){(ie===0||ie===3||ie===2)&&(ie=4),ue===null||!(wn&268435455)&&!(os&268435455)||Nt(ue,de)}function Fi(e,t){var n=I;I|=2;var r=Bp();(ue!==e||de!==t)&&(ft=null,fn(e,t));do try{Sy();break}catch(o){Mp(e,o)}while(!0);if(Ja(),I=n,zi.current=r,re!==null)throw Error(T(261));return ue=null,de=0,ie}function Sy(){for(;re!==null;)Up(re)}function ky(){for(;re!==null&&!Vm();)Up(re)}function Up(e){var t=qp(e.alternate,e,Oe);e.memoizedProps=e.pendingProps,t===null?Hp(e):re=t,du.current=null}function Hp(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=my(n,t),n!==null){n.flags&=32767,re=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{ie=6,re=null;return}}else if(n=hy(n,t,Oe),n!==null){re=n;return}if(t=t.sibling,t!==null){re=t;return}re=t=e}while(t!==null);ie===0&&(ie=5)}function on(e,t,n){var r=B,o=Ue.transition;try{Ue.transition=null,B=1,Ey(e,t,n,r)}finally{Ue.transition=o,B=r}return null}function Ey(e,t,n,r){do Vn();while(At!==null);if(I&6)throw Error(T(327));n=e.finishedWork;var o=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(T(177));e.callbackNode=null,e.callbackPriority=0;var i=n.lanes|n.childLanes;if(rg(e,i),e===ue&&(re=ue=null,de=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||Fo||(Fo=!0,Qp(xi,function(){return Vn(),null})),i=(n.flags&15990)!==0,n.subtreeFlags&15990||i){i=Ue.transition,Ue.transition=null;var s=B;B=1;var l=I;I|=4,du.current=null,yy(e,n),Dp(n,e),Hg(Ml),ki=!!Fl,Ml=Fl=null,e.current=n,vy(n),Km(),I=l,B=s,Ue.transition=i}else e.current=n;if(Fo&&(Fo=!1,At=e,Ii=o),i=e.pendingLanes,i===0&&(Bt=null),Xm(n.stateNode),be(e,ee()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)o=t[n],r(o.value,{componentStack:o.stack,digest:o.digest});if(Di)throw Di=!1,e=sa,sa=null,e;return Ii&1&&e.tag!==0&&Vn(),i=e.pendingLanes,i&1?e===la?Br++:(Br=0,la=e):Br=0,Yt(),null}function Vn(){if(At!==null){var e=Ef(Ii),t=Ue.transition,n=B;try{if(Ue.transition=null,B=16>e?16:e,At===null)var r=!1;else{if(e=At,At=null,Ii=0,I&6)throw Error(T(331));var o=I;for(I|=4,$=e.current;$!==null;){var i=$,s=i.child;if($.flags&16){var l=i.deletions;if(l!==null){for(var a=0;a<l.length;a++){var c=l[a];for($=c;$!==null;){var f=$;switch(f.tag){case 0:case 11:case 15:Fr(8,f,i)}var d=f.child;if(d!==null)d.return=f,$=d;else for(;$!==null;){f=$;var m=f.sibling,w=f.return;if(Ap(f),f===c){$=null;break}if(m!==null){m.return=w,$=m;break}$=w}}}var y=i.alternate;if(y!==null){var v=y.child;if(v!==null){y.child=null;do{var x=v.sibling;v.sibling=null,v=x}while(v!==null)}}$=i}}if(i.subtreeFlags&2064&&s!==null)s.return=i,$=s;else e:for(;$!==null;){if(i=$,i.flags&2048)switch(i.tag){case 0:case 11:case 15:Fr(9,i,i.return)}var h=i.sibling;if(h!==null){h.return=i.return,$=h;break e}$=i.return}}var p=e.current;for($=p;$!==null;){s=$;var g=s.child;if(s.subtreeFlags&2064&&g!==null)g.return=s,$=g;else e:for(s=p;$!==null;){if(l=$,l.flags&2048)try{switch(l.tag){case 0:case 11:case 15:rs(9,l)}}catch(C){Z(l,l.return,C)}if(l===s){$=null;break e}var S=l.sibling;if(S!==null){S.return=l.return,$=S;break e}$=l.return}}if(I=o,Yt(),at&&typeof at.onPostCommitFiberRoot=="function")try{at.onPostCommitFiberRoot(Gi,e)}catch{}r=!0}return r}finally{B=n,Ue.transition=t}}return!1}function Mc(e,t,n){t=er(n,t),t=Ep(e,t,1),e=Mt(e,t,1),t=we(),e!==null&&(ho(e,1,t),be(e,t))}function Z(e,t,n){if(e.tag===3)Mc(e,e,n);else for(;t!==null;){if(t.tag===3){Mc(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(Bt===null||!Bt.has(r))){e=er(n,e),e=Cp(t,e,1),t=Mt(t,e,1),e=we(),t!==null&&(ho(t,1,e),be(t,e));break}}t=t.return}}function Cy(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=we(),e.pingedLanes|=e.suspendedLanes&n,ue===e&&(de&n)===n&&(ie===4||ie===3&&(de&130023424)===de&&500>ee()-pu?fn(e,0):fu|=n),be(e,t)}function Wp(e,t){t===0&&(e.mode&1?(t=Ro,Ro<<=1,!(Ro&130023424)&&(Ro=4194304)):t=1);var n=we();e=xt(e,t),e!==null&&(ho(e,t,n),be(e,n))}function jy(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Wp(e,n)}function Py(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,o=e.memoizedState;o!==null&&(n=o.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(T(314))}r!==null&&r.delete(t),Wp(e,n)}var qp;qp=function(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps||je.current)Ce=!0;else{if(!(e.lanes&n)&&!(t.flags&128))return Ce=!1,py(e,t,n);Ce=!!(e.flags&131072)}else Ce=!1,G&&t.flags&1048576&&Gf(t,Ri,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;ii(e,t),e=t.pendingProps;var o=Yn(t,ye.current);Qn(t,n),o=su(null,t,r,e,o,n);var i=lu();return t.flags|=1,typeof o=="object"&&o!==null&&typeof o.render=="function"&&o.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,Pe(r)?(i=!0,bi(t)):i=!1,t.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,tu(t),o.updater=ns,t.stateNode=o,o._reactInternals=t,Gl(t,r,e,n),t=Jl(null,t,r,!0,i,n)):(t.tag=0,G&&i&&Ka(t),ve(null,t,o,n),t=t.child),t;case 16:r=t.elementType;e:{switch(ii(e,t),e=t.pendingProps,o=r._init,r=o(r._payload),t.type=r,o=t.tag=Ty(r),e=Ke(r,e),o){case 0:t=Xl(null,t,r,e,n);break e;case 1:t=$c(null,t,r,e,n);break e;case 11:t=Tc(null,t,r,e,n);break e;case 14:t=Rc(null,t,r,Ke(r.type,e),n);break e}throw Error(T(306,r,""))}return t;case 0:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:Ke(r,o),Xl(e,t,r,o,n);case 1:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:Ke(r,o),$c(e,t,r,o,n);case 3:e:{if(Tp(t),e===null)throw Error(T(387));r=t.pendingProps,i=t.memoizedState,o=i.element,tp(e,t),Ni(t,r,null,n);var s=t.memoizedState;if(r=s.element,i.isDehydrated)if(i={element:r,isDehydrated:!1,cache:s.cache,pendingSuspenseBoundaries:s.pendingSuspenseBoundaries,transitions:s.transitions},t.updateQueue.baseState=i,t.memoizedState=i,t.flags&256){o=er(Error(T(423)),t),t=_c(e,t,r,n,o);break e}else if(r!==o){o=er(Error(T(424)),t),t=_c(e,t,r,n,o);break e}else for(Ae=Ft(t.stateNode.containerInfo.firstChild),Le=t,G=!0,Ye=null,n=Zf(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(Xn(),r===o){t=St(e,t,n);break e}ve(e,t,r,n)}t=t.child}return t;case 5:return np(t),e===null&&Ql(t),r=t.type,o=t.pendingProps,i=e!==null?e.memoizedProps:null,s=o.children,Bl(r,o)?s=null:i!==null&&Bl(r,i)&&(t.flags|=32),bp(e,t),ve(e,t,s,n),t.child;case 6:return e===null&&Ql(t),null;case 13:return Rp(e,t,n);case 4:return nu(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=Jn(t,null,r,n):ve(e,t,r,n),t.child;case 11:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:Ke(r,o),Tc(e,t,r,o,n);case 7:return ve(e,t,t.pendingProps,n),t.child;case 8:return ve(e,t,t.pendingProps.children,n),t.child;case 12:return ve(e,t,t.pendingProps.children,n),t.child;case 10:e:{if(r=t.type._context,o=t.pendingProps,i=t.memoizedProps,s=o.value,q($i,r._currentValue),r._currentValue=s,i!==null)if(et(i.value,s)){if(i.children===o.children&&!je.current){t=St(e,t,n);break e}}else for(i=t.child,i!==null&&(i.return=t);i!==null;){var l=i.dependencies;if(l!==null){s=i.child;for(var a=l.firstContext;a!==null;){if(a.context===r){if(i.tag===1){a=yt(-1,n&-n),a.tag=2;var c=i.updateQueue;if(c!==null){c=c.shared;var f=c.pending;f===null?a.next=a:(a.next=f.next,f.next=a),c.pending=a}}i.lanes|=n,a=i.alternate,a!==null&&(a.lanes|=n),Vl(i.return,n,t),l.lanes|=n;break}a=a.next}}else if(i.tag===10)s=i.type===t.type?null:i.child;else if(i.tag===18){if(s=i.return,s===null)throw Error(T(341));s.lanes|=n,l=s.alternate,l!==null&&(l.lanes|=n),Vl(s,n,t),s=i.sibling}else s=i.child;if(s!==null)s.return=i;else for(s=i;s!==null;){if(s===t){s=null;break}if(i=s.sibling,i!==null){i.return=s.return,s=i;break}s=s.return}i=s}ve(e,t,o.children,n),t=t.child}return t;case 9:return o=t.type,r=t.pendingProps.children,Qn(t,n),o=He(o),r=r(o),t.flags|=1,ve(e,t,r,n),t.child;case 14:return r=t.type,o=Ke(r,t.pendingProps),o=Ke(r.type,o),Rc(e,t,r,o,n);case 15:return jp(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:Ke(r,o),ii(e,t),t.tag=1,Pe(r)?(e=!0,bi(t)):e=!1,Qn(t,n),kp(t,r,o),Gl(t,r,o,n),Jl(null,t,r,!0,e,n);case 19:return $p(e,t,n);case 22:return Pp(e,t,n)}throw Error(T(156,t.tag))};function Qp(e,t){return wf(e,t)}function by(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Be(e,t,n,r){return new by(e,t,n,r)}function yu(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Ty(e){if(typeof e=="function")return yu(e)?1:0;if(e!=null){if(e=e.$$typeof,e===za)return 11;if(e===Da)return 14}return 2}function Ht(e,t){var n=e.alternate;return n===null?(n=Be(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function ai(e,t,n,r,o,i){var s=2;if(r=e,typeof e=="function")yu(e)&&(s=1);else if(typeof e=="string")s=5;else e:switch(e){case $n:return pn(n.children,o,i,t);case La:s=8,o|=8;break;case wl:return e=Be(12,n,t,o|2),e.elementType=wl,e.lanes=i,e;case xl:return e=Be(13,n,t,o),e.elementType=xl,e.lanes=i,e;case Sl:return e=Be(19,n,t,o),e.elementType=Sl,e.lanes=i,e;case tf:return is(n,o,i,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case Zd:s=10;break e;case ef:s=9;break e;case za:s=11;break e;case Da:s=14;break e;case Rt:s=16,r=null;break e}throw Error(T(130,e==null?e:typeof e,""))}return t=Be(s,n,t,o),t.elementType=e,t.type=r,t.lanes=i,t}function pn(e,t,n,r){return e=Be(7,e,r,t),e.lanes=n,e}function is(e,t,n,r){return e=Be(22,e,r,t),e.elementType=tf,e.lanes=n,e.stateNode={isHidden:!1},e}function Ys(e,t,n){return e=Be(6,e,null,t),e.lanes=n,e}function Xs(e,t,n){return t=Be(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function Ry(e,t,n,r,o){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=_s(0),this.expirationTimes=_s(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=_s(0),this.identifierPrefix=r,this.onRecoverableError=o,this.mutableSourceEagerHydrationData=null}function vu(e,t,n,r,o,i,s,l,a){return e=new Ry(e,t,n,l,a),t===1?(t=1,i===!0&&(t|=8)):t=0,i=Be(3,null,null,t),e.current=i,i.stateNode=e,i.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},tu(i),e}function $y(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Rn,key:r==null?null:""+r,children:e,containerInfo:t,implementation:n}}function Vp(e){if(!e)return Vt;e=e._reactInternals;e:{if(jn(e)!==e||e.tag!==1)throw Error(T(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(Pe(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(T(171))}if(e.tag===1){var n=e.type;if(Pe(n))return Vf(e,n,t)}return t}function Kp(e,t,n,r,o,i,s,l,a){return e=vu(n,r,!0,e,o,i,s,l,a),e.context=Vp(null),n=e.current,r=we(),o=Ut(n),i=yt(r,o),i.callback=t??null,Mt(n,i,o),e.current.lanes=o,ho(e,o,r),be(e,r),e}function ss(e,t,n,r){var o=t.current,i=we(),s=Ut(o);return n=Vp(n),t.context===null?t.context=n:t.pendingContext=n,t=yt(i,s),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=Mt(o,t,s),e!==null&&(Je(e,o,s,i),ni(e,o,s)),s}function Mi(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function Bc(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function wu(e,t){Bc(e,t),(e=e.alternate)&&Bc(e,t)}function _y(){return null}var Gp=typeof reportError=="function"?reportError:function(e){console.error(e)};function xu(e){this._internalRoot=e}ls.prototype.render=xu.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(T(409));ss(e,t,null,null)};ls.prototype.unmount=xu.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;xn(function(){ss(null,e,null,null)}),t[wt]=null}};function ls(e){this._internalRoot=e}ls.prototype.unstable_scheduleHydration=function(e){if(e){var t=Pf();e={blockedOn:null,target:e,priority:t};for(var n=0;n<_t.length&&t!==0&&t<_t[n].priority;n++);_t.splice(n,0,e),n===0&&Tf(e)}};function Su(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function as(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function Uc(){}function Ny(e,t,n,r,o){if(o){if(typeof r=="function"){var i=r;r=function(){var c=Mi(s);i.call(c)}}var s=Kp(t,r,e,0,null,!1,!1,"",Uc);return e._reactRootContainer=s,e[wt]=s.current,Xr(e.nodeType===8?e.parentNode:e),xn(),s}for(;o=e.lastChild;)e.removeChild(o);if(typeof r=="function"){var l=r;r=function(){var c=Mi(a);l.call(c)}}var a=vu(e,0,!1,null,null,!1,!1,"",Uc);return e._reactRootContainer=a,e[wt]=a.current,Xr(e.nodeType===8?e.parentNode:e),xn(function(){ss(t,a,n,r)}),a}function us(e,t,n,r,o){var i=n._reactRootContainer;if(i){var s=i;if(typeof o=="function"){var l=o;o=function(){var a=Mi(s);l.call(a)}}ss(t,s,e,o)}else s=Ny(n,t,e,o,r);return Mi(s)}Cf=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=$r(t.pendingLanes);n!==0&&(Ma(t,n|1),be(t,ee()),!(I&6)&&(tr=ee()+500,Yt()))}break;case 13:xn(function(){var r=xt(e,1);if(r!==null){var o=we();Je(r,e,1,o)}}),wu(e,1)}};Ba=function(e){if(e.tag===13){var t=xt(e,134217728);if(t!==null){var n=we();Je(t,e,134217728,n)}wu(e,134217728)}};jf=function(e){if(e.tag===13){var t=Ut(e),n=xt(e,t);if(n!==null){var r=we();Je(n,e,t,r)}wu(e,t)}};Pf=function(){return B};bf=function(e,t){var n=B;try{return B=e,t()}finally{B=n}};_l=function(e,t,n){switch(t){case"input":if(Cl(e,n),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var o=Zi(r);if(!o)throw Error(T(90));rf(r),Cl(r,o)}}}break;case"textarea":sf(e,n);break;case"select":t=n.value,t!=null&&Un(e,!!n.multiple,t,!1)}};pf=hu;hf=xn;var Oy={usingClientEntryPoint:!1,Events:[go,An,Zi,df,ff,hu]},Er={findFiberByHostInstance:sn,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Ay={bundleType:Er.bundleType,version:Er.version,rendererPackageName:Er.rendererPackageName,rendererConfig:Er.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:kt.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=yf(e),e===null?null:e.stateNode},findFiberByHostInstance:Er.findFiberByHostInstance||_y,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Mo=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Mo.isDisabled&&Mo.supportsFiber)try{Gi=Mo.inject(Ay),at=Mo}catch{}}De.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Oy;De.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Su(t))throw Error(T(200));return $y(e,t,null,n)};De.createRoot=function(e,t){if(!Su(e))throw Error(T(299));var n=!1,r="",o=Gp;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(o=t.onRecoverableError)),t=vu(e,1,!1,null,null,n,!1,r,o),e[wt]=t.current,Xr(e.nodeType===8?e.parentNode:e),new xu(t)};De.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(T(188)):(e=Object.keys(e).join(","),Error(T(268,e)));return e=yf(t),e=e===null?null:e.stateNode,e};De.flushSync=function(e){return xn(e)};De.hydrate=function(e,t,n){if(!as(t))throw Error(T(200));return us(null,e,t,!0,n)};De.hydrateRoot=function(e,t,n){if(!Su(e))throw Error(T(405));var r=n!=null&&n.hydratedSources||null,o=!1,i="",s=Gp;if(n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(i=n.identifierPrefix),n.onRecoverableError!==void 0&&(s=n.onRecoverableError)),t=Kp(t,null,e,1,n??null,o,!1,i,s),e[wt]=t.current,Xr(e),r)for(e=0;e<r.length;e++)n=r[e],o=n._getVersion,o=o(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,o]:t.mutableSourceEagerHydrationData.push(n,o);return new ls(t)};De.render=function(e,t,n){if(!as(t))throw Error(T(200));return us(null,e,t,!1,n)};De.unmountComponentAtNode=function(e){if(!as(e))throw Error(T(40));return e._reactRootContainer?(xn(function(){us(null,null,e,!1,function(){e._reactRootContainer=null,e[wt]=null})}),!0):!1};De.unstable_batchedUpdates=hu;De.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!as(n))throw Error(T(200));if(e==null||e._reactInternals===void 0)throw Error(T(38));return us(e,t,n,!1,r)};De.version="18.3.1-next-f1338f8080-20240426";function Yp(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Yp)}catch(e){console.error(e)}}Yp(),Gd.exports=De;var Ly=Gd.exports,Hc=Ly;yl.createRoot=Hc.createRoot,yl.hydrateRoot=Hc.hydrateRoot;/**
 * @remix-run/router v1.23.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */function so(){return so=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},so.apply(this,arguments)}var Lt;(function(e){e.Pop="POP",e.Push="PUSH",e.Replace="REPLACE"})(Lt||(Lt={}));const Wc="popstate";function zy(e){e===void 0&&(e={});function t(r,o){let{pathname:i,search:s,hash:l}=r.location;return ca("",{pathname:i,search:s,hash:l},o.state&&o.state.usr||null,o.state&&o.state.key||"default")}function n(r,o){return typeof o=="string"?o:Bi(o)}return Iy(t,n,null,e)}function te(e,t){if(e===!1||e===null||typeof e>"u")throw new Error(t)}function Xp(e,t){if(!e){typeof console<"u"&&console.warn(t);try{throw new Error(t)}catch{}}}function Dy(){return Math.random().toString(36).substr(2,8)}function qc(e,t){return{usr:e.state,key:e.key,idx:t}}function ca(e,t,n,r){return n===void 0&&(n=null),so({pathname:typeof e=="string"?e:e.pathname,search:"",hash:""},typeof t=="string"?ur(t):t,{state:n,key:t&&t.key||r||Dy()})}function Bi(e){let{pathname:t="/",search:n="",hash:r=""}=e;return n&&n!=="?"&&(t+=n.charAt(0)==="?"?n:"?"+n),r&&r!=="#"&&(t+=r.charAt(0)==="#"?r:"#"+r),t}function ur(e){let t={};if(e){let n=e.indexOf("#");n>=0&&(t.hash=e.substr(n),e=e.substr(0,n));let r=e.indexOf("?");r>=0&&(t.search=e.substr(r),e=e.substr(0,r)),e&&(t.pathname=e)}return t}function Iy(e,t,n,r){r===void 0&&(r={});let{window:o=document.defaultView,v5Compat:i=!1}=r,s=o.history,l=Lt.Pop,a=null,c=f();c==null&&(c=0,s.replaceState(so({},s.state,{idx:c}),""));function f(){return(s.state||{idx:null}).idx}function d(){l=Lt.Pop;let x=f(),h=x==null?null:x-c;c=x,a&&a({action:l,location:v.location,delta:h})}function m(x,h){l=Lt.Push;let p=ca(v.location,x,h);c=f()+1;let g=qc(p,c),S=v.createHref(p);try{s.pushState(g,"",S)}catch(C){if(C instanceof DOMException&&C.name==="DataCloneError")throw C;o.location.assign(S)}i&&a&&a({action:l,location:v.location,delta:1})}function w(x,h){l=Lt.Replace;let p=ca(v.location,x,h);c=f();let g=qc(p,c),S=v.createHref(p);s.replaceState(g,"",S),i&&a&&a({action:l,location:v.location,delta:0})}function y(x){let h=o.location.origin!=="null"?o.location.origin:o.location.href,p=typeof x=="string"?x:Bi(x);return p=p.replace(/ $/,"%20"),te(h,"No window.location.(origin|href) available to create URL for href: "+p),new URL(p,h)}let v={get action(){return l},get location(){return e(o,s)},listen(x){if(a)throw new Error("A history only accepts one active listener");return o.addEventListener(Wc,d),a=x,()=>{o.removeEventListener(Wc,d),a=null}},createHref(x){return t(o,x)},createURL:y,encodeLocation(x){let h=y(x);return{pathname:h.pathname,search:h.search,hash:h.hash}},push:m,replace:w,go(x){return s.go(x)}};return v}var Qc;(function(e){e.data="data",e.deferred="deferred",e.redirect="redirect",e.error="error"})(Qc||(Qc={}));function Fy(e,t,n){return n===void 0&&(n="/"),My(e,t,n)}function My(e,t,n,r){let o=typeof t=="string"?ur(t):t,i=ku(o.pathname||"/",n);if(i==null)return null;let s=Jp(e);By(s);let l=null;for(let a=0;l==null&&a<s.length;++a){let c=Zy(i);l=Yy(s[a],c)}return l}function Jp(e,t,n,r){t===void 0&&(t=[]),n===void 0&&(n=[]),r===void 0&&(r="");let o=(i,s,l)=>{let a={relativePath:l===void 0?i.path||"":l,caseSensitive:i.caseSensitive===!0,childrenIndex:s,route:i};a.relativePath.startsWith("/")&&(te(a.relativePath.startsWith(r),'Absolute route path "'+a.relativePath+'" nested under path '+('"'+r+'" is not valid. An absolute child route path ')+"must start with the combined path of all its parent routes."),a.relativePath=a.relativePath.slice(r.length));let c=Wt([r,a.relativePath]),f=n.concat(a);i.children&&i.children.length>0&&(te(i.index!==!0,"Index routes must not have child routes. Please remove "+('all child routes from route path "'+c+'".')),Jp(i.children,t,f,c)),!(i.path==null&&!i.index)&&t.push({path:c,score:Ky(c,i.index),routesMeta:f})};return e.forEach((i,s)=>{var l;if(i.path===""||!((l=i.path)!=null&&l.includes("?")))o(i,s);else for(let a of Zp(i.path))o(i,s,a)}),t}function Zp(e){let t=e.split("/");if(t.length===0)return[];let[n,...r]=t,o=n.endsWith("?"),i=n.replace(/\?$/,"");if(r.length===0)return o?[i,""]:[i];let s=Zp(r.join("/")),l=[];return l.push(...s.map(a=>a===""?i:[i,a].join("/"))),o&&l.push(...s),l.map(a=>e.startsWith("/")&&a===""?"/":a)}function By(e){e.sort((t,n)=>t.score!==n.score?n.score-t.score:Gy(t.routesMeta.map(r=>r.childrenIndex),n.routesMeta.map(r=>r.childrenIndex)))}const Uy=/^:[\w-]+$/,Hy=3,Wy=2,qy=1,Qy=10,Vy=-2,Vc=e=>e==="*";function Ky(e,t){let n=e.split("/"),r=n.length;return n.some(Vc)&&(r+=Vy),t&&(r+=Wy),n.filter(o=>!Vc(o)).reduce((o,i)=>o+(Uy.test(i)?Hy:i===""?qy:Qy),r)}function Gy(e,t){return e.length===t.length&&e.slice(0,-1).every((r,o)=>r===t[o])?e[e.length-1]-t[t.length-1]:0}function Yy(e,t,n){let{routesMeta:r}=e,o={},i="/",s=[];for(let l=0;l<r.length;++l){let a=r[l],c=l===r.length-1,f=i==="/"?t:t.slice(i.length)||"/",d=Xy({path:a.relativePath,caseSensitive:a.caseSensitive,end:c},f),m=a.route;if(!d)return null;Object.assign(o,d.params),s.push({params:o,pathname:Wt([i,d.pathname]),pathnameBase:rv(Wt([i,d.pathnameBase])),route:m}),d.pathnameBase!=="/"&&(i=Wt([i,d.pathnameBase]))}return s}function Xy(e,t){typeof e=="string"&&(e={path:e,caseSensitive:!1,end:!0});let[n,r]=Jy(e.path,e.caseSensitive,e.end),o=t.match(n);if(!o)return null;let i=o[0],s=i.replace(/(.)\/+$/,"$1"),l=o.slice(1);return{params:r.reduce((c,f,d)=>{let{paramName:m,isOptional:w}=f;if(m==="*"){let v=l[d]||"";s=i.slice(0,i.length-v.length).replace(/(.)\/+$/,"$1")}const y=l[d];return w&&!y?c[m]=void 0:c[m]=(y||"").replace(/%2F/g,"/"),c},{}),pathname:i,pathnameBase:s,pattern:e}}function Jy(e,t,n){t===void 0&&(t=!1),n===void 0&&(n=!0),Xp(e==="*"||!e.endsWith("*")||e.endsWith("/*"),'Route path "'+e+'" will be treated as if it were '+('"'+e.replace(/\*$/,"/*")+'" because the `*` character must ')+"always follow a `/` in the pattern. To get rid of this warning, "+('please change the route path to "'+e.replace(/\*$/,"/*")+'".'));let r=[],o="^"+e.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(s,l,a)=>(r.push({paramName:l,isOptional:a!=null}),a?"/?([^\\/]+)?":"/([^\\/]+)"));return e.endsWith("*")?(r.push({paramName:"*"}),o+=e==="*"||e==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):n?o+="\\/*$":e!==""&&e!=="/"&&(o+="(?:(?=\\/|$))"),[new RegExp(o,t?void 0:"i"),r]}function Zy(e){try{return e.split("/").map(t=>decodeURIComponent(t).replace(/\//g,"%2F")).join("/")}catch(t){return Xp(!1,'The URL path "'+e+'" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent '+("encoding ("+t+").")),e}}function ku(e,t){if(t==="/")return e;if(!e.toLowerCase().startsWith(t.toLowerCase()))return null;let n=t.endsWith("/")?t.length-1:t.length,r=e.charAt(n);return r&&r!=="/"?null:e.slice(n)||"/"}function ev(e,t){t===void 0&&(t="/");let{pathname:n,search:r="",hash:o=""}=typeof e=="string"?ur(e):e;return{pathname:n?n.startsWith("/")?n:tv(n,t):t,search:ov(r),hash:iv(o)}}function tv(e,t){let n=t.replace(/\/+$/,"").split("/");return e.split("/").forEach(o=>{o===".."?n.length>1&&n.pop():o!=="."&&n.push(o)}),n.length>1?n.join("/"):"/"}function Js(e,t,n,r){return"Cannot include a '"+e+"' character in a manually specified "+("`to."+t+"` field ["+JSON.stringify(r)+"].  Please separate it out to the ")+("`to."+n+"` field. Alternatively you may provide the full path as ")+'a string in <Link to="..."> and the router will parse it for you.'}function nv(e){return e.filter((t,n)=>n===0||t.route.path&&t.route.path.length>0)}function Eu(e,t){let n=nv(e);return t?n.map((r,o)=>o===n.length-1?r.pathname:r.pathnameBase):n.map(r=>r.pathnameBase)}function Cu(e,t,n,r){r===void 0&&(r=!1);let o;typeof e=="string"?o=ur(e):(o=so({},e),te(!o.pathname||!o.pathname.includes("?"),Js("?","pathname","search",o)),te(!o.pathname||!o.pathname.includes("#"),Js("#","pathname","hash",o)),te(!o.search||!o.search.includes("#"),Js("#","search","hash",o)));let i=e===""||o.pathname==="",s=i?"/":o.pathname,l;if(s==null)l=n;else{let d=t.length-1;if(!r&&s.startsWith("..")){let m=s.split("/");for(;m[0]==="..";)m.shift(),d-=1;o.pathname=m.join("/")}l=d>=0?t[d]:"/"}let a=ev(o,l),c=s&&s!=="/"&&s.endsWith("/"),f=(i||s===".")&&n.endsWith("/");return!a.pathname.endsWith("/")&&(c||f)&&(a.pathname+="/"),a}const Wt=e=>e.join("/").replace(/\/\/+/g,"/"),rv=e=>e.replace(/\/+$/,"").replace(/^\/*/,"/"),ov=e=>!e||e==="?"?"":e.startsWith("?")?e:"?"+e,iv=e=>!e||e==="#"?"":e.startsWith("#")?e:"#"+e;function sv(e){return e!=null&&typeof e.status=="number"&&typeof e.statusText=="string"&&typeof e.internal=="boolean"&&"data"in e}const eh=["post","put","patch","delete"];new Set(eh);const lv=["get",...eh];new Set(lv);/**
 * React Router v6.30.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */function lo(){return lo=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},lo.apply(this,arguments)}const ju=P.createContext(null),av=P.createContext(null),Xt=P.createContext(null),cs=P.createContext(null),Et=P.createContext({outlet:null,matches:[],isDataRoute:!1}),th=P.createContext(null);function uv(e,t){let{relative:n}=t===void 0?{}:t;cr()||te(!1);let{basename:r,navigator:o}=P.useContext(Xt),{hash:i,pathname:s,search:l}=rh(e,{relative:n}),a=s;return r!=="/"&&(a=s==="/"?r:Wt([r,s])),o.createHref({pathname:a,search:l,hash:i})}function cr(){return P.useContext(cs)!=null}function vo(){return cr()||te(!1),P.useContext(cs).location}function nh(e){P.useContext(Xt).static||P.useLayoutEffect(e)}function wo(){let{isDataRoute:e}=P.useContext(Et);return e?Cv():cv()}function cv(){cr()||te(!1);let e=P.useContext(ju),{basename:t,future:n,navigator:r}=P.useContext(Xt),{matches:o}=P.useContext(Et),{pathname:i}=vo(),s=JSON.stringify(Eu(o,n.v7_relativeSplatPath)),l=P.useRef(!1);return nh(()=>{l.current=!0}),P.useCallback(function(c,f){if(f===void 0&&(f={}),!l.current)return;if(typeof c=="number"){r.go(c);return}let d=Cu(c,JSON.parse(s),i,f.relative==="path");e==null&&t!=="/"&&(d.pathname=d.pathname==="/"?t:Wt([t,d.pathname])),(f.replace?r.replace:r.push)(d,f.state,f)},[t,r,s,i,e])}const dv=P.createContext(null);function fv(e){let t=P.useContext(Et).outlet;return t&&P.createElement(dv.Provider,{value:e},t)}function rh(e,t){let{relative:n}=t===void 0?{}:t,{future:r}=P.useContext(Xt),{matches:o}=P.useContext(Et),{pathname:i}=vo(),s=JSON.stringify(Eu(o,r.v7_relativeSplatPath));return P.useMemo(()=>Cu(e,JSON.parse(s),i,n==="path"),[e,s,i,n])}function pv(e,t){return hv(e,t)}function hv(e,t,n,r){cr()||te(!1);let{navigator:o}=P.useContext(Xt),{matches:i}=P.useContext(Et),s=i[i.length-1],l=s?s.params:{};s&&s.pathname;let a=s?s.pathnameBase:"/";s&&s.route;let c=vo(),f;if(t){var d;let x=typeof t=="string"?ur(t):t;a==="/"||(d=x.pathname)!=null&&d.startsWith(a)||te(!1),f=x}else f=c;let m=f.pathname||"/",w=m;if(a!=="/"){let x=a.replace(/^\//,"").split("/");w="/"+m.replace(/^\//,"").split("/").slice(x.length).join("/")}let y=Fy(e,{pathname:w}),v=wv(y&&y.map(x=>Object.assign({},x,{params:Object.assign({},l,x.params),pathname:Wt([a,o.encodeLocation?o.encodeLocation(x.pathname).pathname:x.pathname]),pathnameBase:x.pathnameBase==="/"?a:Wt([a,o.encodeLocation?o.encodeLocation(x.pathnameBase).pathname:x.pathnameBase])})),i,n,r);return t&&v?P.createElement(cs.Provider,{value:{location:lo({pathname:"/",search:"",hash:"",state:null,key:"default"},f),navigationType:Lt.Pop}},v):v}function mv(){let e=Ev(),t=sv(e)?e.status+" "+e.statusText:e instanceof Error?e.message:JSON.stringify(e),n=e instanceof Error?e.stack:null,o={padding:"0.5rem",backgroundColor:"rgba(200,200,200, 0.5)"};return P.createElement(P.Fragment,null,P.createElement("h2",null,"Unexpected Application Error!"),P.createElement("h3",{style:{fontStyle:"italic"}},t),n?P.createElement("pre",{style:o},n):null,null)}const gv=P.createElement(mv,null);class yv extends P.Component{constructor(t){super(t),this.state={location:t.location,revalidation:t.revalidation,error:t.error}}static getDerivedStateFromError(t){return{error:t}}static getDerivedStateFromProps(t,n){return n.location!==t.location||n.revalidation!=="idle"&&t.revalidation==="idle"?{error:t.error,location:t.location,revalidation:t.revalidation}:{error:t.error!==void 0?t.error:n.error,location:n.location,revalidation:t.revalidation||n.revalidation}}componentDidCatch(t,n){console.error("React Router caught the following error during render",t,n)}render(){return this.state.error!==void 0?P.createElement(Et.Provider,{value:this.props.routeContext},P.createElement(th.Provider,{value:this.state.error,children:this.props.component})):this.props.children}}function vv(e){let{routeContext:t,match:n,children:r}=e,o=P.useContext(ju);return o&&o.static&&o.staticContext&&(n.route.errorElement||n.route.ErrorBoundary)&&(o.staticContext._deepestRenderedBoundaryId=n.route.id),P.createElement(Et.Provider,{value:t},r)}function wv(e,t,n,r){var o;if(t===void 0&&(t=[]),n===void 0&&(n=null),r===void 0&&(r=null),e==null){var i;if(!n)return null;if(n.errors)e=n.matches;else if((i=r)!=null&&i.v7_partialHydration&&t.length===0&&!n.initialized&&n.matches.length>0)e=n.matches;else return null}let s=e,l=(o=n)==null?void 0:o.errors;if(l!=null){let f=s.findIndex(d=>d.route.id&&(l==null?void 0:l[d.route.id])!==void 0);f>=0||te(!1),s=s.slice(0,Math.min(s.length,f+1))}let a=!1,c=-1;if(n&&r&&r.v7_partialHydration)for(let f=0;f<s.length;f++){let d=s[f];if((d.route.HydrateFallback||d.route.hydrateFallbackElement)&&(c=f),d.route.id){let{loaderData:m,errors:w}=n,y=d.route.loader&&m[d.route.id]===void 0&&(!w||w[d.route.id]===void 0);if(d.route.lazy||y){a=!0,c>=0?s=s.slice(0,c+1):s=[s[0]];break}}}return s.reduceRight((f,d,m)=>{let w,y=!1,v=null,x=null;n&&(w=l&&d.route.id?l[d.route.id]:void 0,v=d.route.errorElement||gv,a&&(c<0&&m===0?(jv("route-fallback"),y=!0,x=null):c===m&&(y=!0,x=d.route.hydrateFallbackElement||null)));let h=t.concat(s.slice(0,m+1)),p=()=>{let g;return w?g=v:y?g=x:d.route.Component?g=P.createElement(d.route.Component,null):d.route.element?g=d.route.element:g=f,P.createElement(vv,{match:d,routeContext:{outlet:f,matches:h,isDataRoute:n!=null},children:g})};return n&&(d.route.ErrorBoundary||d.route.errorElement||m===0)?P.createElement(yv,{location:n.location,revalidation:n.revalidation,component:v,error:w,children:p(),routeContext:{outlet:null,matches:h,isDataRoute:!0}}):p()},null)}var oh=function(e){return e.UseBlocker="useBlocker",e.UseRevalidator="useRevalidator",e.UseNavigateStable="useNavigate",e}(oh||{}),ih=function(e){return e.UseBlocker="useBlocker",e.UseLoaderData="useLoaderData",e.UseActionData="useActionData",e.UseRouteError="useRouteError",e.UseNavigation="useNavigation",e.UseRouteLoaderData="useRouteLoaderData",e.UseMatches="useMatches",e.UseRevalidator="useRevalidator",e.UseNavigateStable="useNavigate",e.UseRouteId="useRouteId",e}(ih||{});function xv(e){let t=P.useContext(ju);return t||te(!1),t}function Sv(e){let t=P.useContext(av);return t||te(!1),t}function kv(e){let t=P.useContext(Et);return t||te(!1),t}function sh(e){let t=kv(),n=t.matches[t.matches.length-1];return n.route.id||te(!1),n.route.id}function Ev(){var e;let t=P.useContext(th),n=Sv(),r=sh();return t!==void 0?t:(e=n.errors)==null?void 0:e[r]}function Cv(){let{router:e}=xv(oh.UseNavigateStable),t=sh(ih.UseNavigateStable),n=P.useRef(!1);return nh(()=>{n.current=!0}),P.useCallback(function(o,i){i===void 0&&(i={}),n.current&&(typeof o=="number"?e.navigate(o):e.navigate(o,lo({fromRouteId:t},i)))},[e,t])}const Kc={};function jv(e,t,n){Kc[e]||(Kc[e]=!0)}function Pv(e,t){e==null||e.v7_startTransition,e==null||e.v7_relativeSplatPath}function bv(e){let{to:t,replace:n,state:r,relative:o}=e;cr()||te(!1);let{future:i,static:s}=P.useContext(Xt),{matches:l}=P.useContext(Et),{pathname:a}=vo(),c=wo(),f=Cu(t,Eu(l,i.v7_relativeSplatPath),a,o==="path"),d=JSON.stringify(f);return P.useEffect(()=>c(JSON.parse(d),{replace:n,state:r,relative:o}),[c,d,o,n,r]),null}function Tv(e){return fv(e.context)}function ot(e){te(!1)}function Rv(e){let{basename:t="/",children:n=null,location:r,navigationType:o=Lt.Pop,navigator:i,static:s=!1,future:l}=e;cr()&&te(!1);let a=t.replace(/^\/*/,"/"),c=P.useMemo(()=>({basename:a,navigator:i,static:s,future:lo({v7_relativeSplatPath:!1},l)}),[a,l,i,s]);typeof r=="string"&&(r=ur(r));let{pathname:f="/",search:d="",hash:m="",state:w=null,key:y="default"}=r,v=P.useMemo(()=>{let x=ku(f,a);return x==null?null:{location:{pathname:x,search:d,hash:m,state:w,key:y},navigationType:o}},[a,f,d,m,w,y,o]);return v==null?null:P.createElement(Xt.Provider,{value:c},P.createElement(cs.Provider,{children:n,value:v}))}function $v(e){let{children:t,location:n}=e;return pv(da(t),n)}new Promise(()=>{});function da(e,t){t===void 0&&(t=[]);let n=[];return P.Children.forEach(e,(r,o)=>{if(!P.isValidElement(r))return;let i=[...t,o];if(r.type===P.Fragment){n.push.apply(n,da(r.props.children,i));return}r.type!==ot&&te(!1),!r.props.index||!r.props.children||te(!1);let s={id:r.props.id||i.join("-"),caseSensitive:r.props.caseSensitive,element:r.props.element,Component:r.props.Component,index:r.props.index,path:r.props.path,loader:r.props.loader,action:r.props.action,errorElement:r.props.errorElement,ErrorBoundary:r.props.ErrorBoundary,hasErrorBoundary:r.props.ErrorBoundary!=null||r.props.errorElement!=null,shouldRevalidate:r.props.shouldRevalidate,handle:r.props.handle,lazy:r.props.lazy};r.props.children&&(s.children=da(r.props.children,i)),n.push(s)}),n}/**
 * React Router DOM v6.30.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */function fa(){return fa=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},fa.apply(this,arguments)}function _v(e,t){if(e==null)return{};var n={},r=Object.keys(e),o,i;for(i=0;i<r.length;i++)o=r[i],!(t.indexOf(o)>=0)&&(n[o]=e[o]);return n}function Nv(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}function Ov(e,t){return e.button===0&&(!t||t==="_self")&&!Nv(e)}const Av=["onClick","relative","reloadDocument","replace","state","target","to","preventScrollReset","viewTransition"],Lv="6";try{window.__reactRouterVersion=Lv}catch{}const zv="startTransition",Gc=Cm[zv];function Dv(e){let{basename:t,children:n,future:r,window:o}=e,i=P.useRef();i.current==null&&(i.current=zy({window:o,v5Compat:!0}));let s=i.current,[l,a]=P.useState({action:s.action,location:s.location}),{v7_startTransition:c}=r||{},f=P.useCallback(d=>{c&&Gc?Gc(()=>a(d)):a(d)},[a,c]);return P.useLayoutEffect(()=>s.listen(f),[s,f]),P.useEffect(()=>Pv(r),[r]),P.createElement(Rv,{basename:t,children:n,location:l.location,navigationType:l.action,navigator:s,future:r})}const Iv=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u",Fv=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,ct=P.forwardRef(function(t,n){let{onClick:r,relative:o,reloadDocument:i,replace:s,state:l,target:a,to:c,preventScrollReset:f,viewTransition:d}=t,m=_v(t,Av),{basename:w}=P.useContext(Xt),y,v=!1;if(typeof c=="string"&&Fv.test(c)&&(y=c,Iv))try{let g=new URL(window.location.href),S=c.startsWith("//")?new URL(g.protocol+c):new URL(c),C=ku(S.pathname,w);S.origin===g.origin&&C!=null?c=C+S.search+S.hash:v=!0}catch{}let x=uv(c,{relative:o}),h=Mv(c,{replace:s,state:l,target:a,preventScrollReset:f,relative:o,viewTransition:d});function p(g){r&&r(g),g.defaultPrevented||h(g)}return P.createElement("a",fa({},m,{href:y||x,onClick:v||i?r:p,ref:n,target:a}))});var Yc;(function(e){e.UseScrollRestoration="useScrollRestoration",e.UseSubmit="useSubmit",e.UseSubmitFetcher="useSubmitFetcher",e.UseFetcher="useFetcher",e.useViewTransitionState="useViewTransitionState"})(Yc||(Yc={}));var Xc;(function(e){e.UseFetcher="useFetcher",e.UseFetchers="useFetchers",e.UseScrollRestoration="useScrollRestoration"})(Xc||(Xc={}));function Mv(e,t){let{target:n,replace:r,state:o,preventScrollReset:i,relative:s,viewTransition:l}=t===void 0?{}:t,a=wo(),c=vo(),f=rh(e,{relative:s});return P.useCallback(d=>{if(Ov(d,n)){d.preventDefault();let m=r!==void 0?r:Bi(c)===Bi(f);a(e,{replace:m,state:o,preventScrollReset:i,relative:s,viewTransition:l})}},[c,a,f,r,o,n,e,i,s,l])}var ae=function(){return ae=Object.assign||function(t){for(var n,r=1,o=arguments.length;r<o;r++){n=arguments[r];for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(t[i]=n[i])}return t},ae.apply(this,arguments)};function ao(e,t,n){if(n||arguments.length===2)for(var r=0,o=t.length,i;r<o;r++)(i||!(r in t))&&(i||(i=Array.prototype.slice.call(t,0,r)),i[r]=t[r]);return e.concat(i||Array.prototype.slice.call(t))}var V="-ms-",Ur="-moz-",F="-webkit-",lh="comm",ds="rule",Pu="decl",Bv="@import",ah="@keyframes",Uv="@layer",uh=Math.abs,bu=String.fromCharCode,pa=Object.assign;function Hv(e,t){return le(e,0)^45?(((t<<2^le(e,0))<<2^le(e,1))<<2^le(e,2))<<2^le(e,3):0}function ch(e){return e.trim()}function pt(e,t){return(e=t.exec(e))?e[0]:e}function L(e,t,n){return e.replace(t,n)}function ui(e,t,n){return e.indexOf(t,n)}function le(e,t){return e.charCodeAt(t)|0}function nr(e,t,n){return e.slice(t,n)}function st(e){return e.length}function dh(e){return e.length}function Nr(e,t){return t.push(e),e}function Wv(e,t){return e.map(t).join("")}function Jc(e,t){return e.filter(function(n){return!pt(n,t)})}var fs=1,rr=1,fh=0,qe=0,ne=0,dr="";function ps(e,t,n,r,o,i,s,l){return{value:e,root:t,parent:n,type:r,props:o,children:i,line:fs,column:rr,length:s,return:"",siblings:l}}function Tt(e,t){return pa(ps("",null,null,"",null,null,0,e.siblings),e,{length:-e.length},t)}function bn(e){for(;e.root;)e=Tt(e.root,{children:[e]});Nr(e,e.siblings)}function qv(){return ne}function Qv(){return ne=qe>0?le(dr,--qe):0,rr--,ne===10&&(rr=1,fs--),ne}function Ze(){return ne=qe<fh?le(dr,qe++):0,rr++,ne===10&&(rr=1,fs++),ne}function hn(){return le(dr,qe)}function ci(){return qe}function hs(e,t){return nr(dr,e,t)}function ha(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function Vv(e){return fs=rr=1,fh=st(dr=e),qe=0,[]}function Kv(e){return dr="",e}function Zs(e){return ch(hs(qe-1,ma(e===91?e+2:e===40?e+1:e)))}function Gv(e){for(;(ne=hn())&&ne<33;)Ze();return ha(e)>2||ha(ne)>3?"":" "}function Yv(e,t){for(;--t&&Ze()&&!(ne<48||ne>102||ne>57&&ne<65||ne>70&&ne<97););return hs(e,ci()+(t<6&&hn()==32&&Ze()==32))}function ma(e){for(;Ze();)switch(ne){case e:return qe;case 34:case 39:e!==34&&e!==39&&ma(ne);break;case 40:e===41&&ma(e);break;case 92:Ze();break}return qe}function Xv(e,t){for(;Ze()&&e+ne!==57;)if(e+ne===84&&hn()===47)break;return"/*"+hs(t,qe-1)+"*"+bu(e===47?e:Ze())}function Jv(e){for(;!ha(hn());)Ze();return hs(e,qe)}function Zv(e){return Kv(di("",null,null,null,[""],e=Vv(e),0,[0],e))}function di(e,t,n,r,o,i,s,l,a){for(var c=0,f=0,d=s,m=0,w=0,y=0,v=1,x=1,h=1,p=0,g="",S=o,C=i,j=r,b=g;x;)switch(y=p,p=Ze()){case 40:if(y!=108&&le(b,d-1)==58){ui(b+=L(Zs(p),"&","&\f"),"&\f",uh(c?l[c-1]:0))!=-1&&(h=-1);break}case 34:case 39:case 91:b+=Zs(p);break;case 9:case 10:case 13:case 32:b+=Gv(y);break;case 92:b+=Yv(ci()-1,7);continue;case 47:switch(hn()){case 42:case 47:Nr(e0(Xv(Ze(),ci()),t,n,a),a);break;default:b+="/"}break;case 123*v:l[c++]=st(b)*h;case 125*v:case 59:case 0:switch(p){case 0:case 125:x=0;case 59+f:h==-1&&(b=L(b,/\f/g,"")),w>0&&st(b)-d&&Nr(w>32?ed(b+";",r,n,d-1,a):ed(L(b," ","")+";",r,n,d-2,a),a);break;case 59:b+=";";default:if(Nr(j=Zc(b,t,n,c,f,o,l,g,S=[],C=[],d,i),i),p===123)if(f===0)di(b,t,j,j,S,i,d,l,C);else switch(m===99&&le(b,3)===110?100:m){case 100:case 108:case 109:case 115:di(e,j,j,r&&Nr(Zc(e,j,j,0,0,o,l,g,o,S=[],d,C),C),o,C,d,l,r?S:C);break;default:di(b,j,j,j,[""],C,0,l,C)}}c=f=w=0,v=h=1,g=b="",d=s;break;case 58:d=1+st(b),w=y;default:if(v<1){if(p==123)--v;else if(p==125&&v++==0&&Qv()==125)continue}switch(b+=bu(p),p*v){case 38:h=f>0?1:(b+="\f",-1);break;case 44:l[c++]=(st(b)-1)*h,h=1;break;case 64:hn()===45&&(b+=Zs(Ze())),m=hn(),f=d=st(g=b+=Jv(ci())),p++;break;case 45:y===45&&st(b)==2&&(v=0)}}return i}function Zc(e,t,n,r,o,i,s,l,a,c,f,d){for(var m=o-1,w=o===0?i:[""],y=dh(w),v=0,x=0,h=0;v<r;++v)for(var p=0,g=nr(e,m+1,m=uh(x=s[v])),S=e;p<y;++p)(S=ch(x>0?w[p]+" "+g:L(g,/&\f/g,w[p])))&&(a[h++]=S);return ps(e,t,n,o===0?ds:l,a,c,f,d)}function e0(e,t,n,r){return ps(e,t,n,lh,bu(qv()),nr(e,2,-2),0,r)}function ed(e,t,n,r,o){return ps(e,t,n,Pu,nr(e,0,r),nr(e,r+1,-1),r,o)}function ph(e,t,n){switch(Hv(e,t)){case 5103:return F+"print-"+e+e;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return F+e+e;case 4789:return Ur+e+e;case 5349:case 4246:case 4810:case 6968:case 2756:return F+e+Ur+e+V+e+e;case 5936:switch(le(e,t+11)){case 114:return F+e+V+L(e,/[svh]\w+-[tblr]{2}/,"tb")+e;case 108:return F+e+V+L(e,/[svh]\w+-[tblr]{2}/,"tb-rl")+e;case 45:return F+e+V+L(e,/[svh]\w+-[tblr]{2}/,"lr")+e}case 6828:case 4268:case 2903:return F+e+V+e+e;case 6165:return F+e+V+"flex-"+e+e;case 5187:return F+e+L(e,/(\w+).+(:[^]+)/,F+"box-$1$2"+V+"flex-$1$2")+e;case 5443:return F+e+V+"flex-item-"+L(e,/flex-|-self/g,"")+(pt(e,/flex-|baseline/)?"":V+"grid-row-"+L(e,/flex-|-self/g,""))+e;case 4675:return F+e+V+"flex-line-pack"+L(e,/align-content|flex-|-self/g,"")+e;case 5548:return F+e+V+L(e,"shrink","negative")+e;case 5292:return F+e+V+L(e,"basis","preferred-size")+e;case 6060:return F+"box-"+L(e,"-grow","")+F+e+V+L(e,"grow","positive")+e;case 4554:return F+L(e,/([^-])(transform)/g,"$1"+F+"$2")+e;case 6187:return L(L(L(e,/(zoom-|grab)/,F+"$1"),/(image-set)/,F+"$1"),e,"")+e;case 5495:case 3959:return L(e,/(image-set\([^]*)/,F+"$1$`$1");case 4968:return L(L(e,/(.+:)(flex-)?(.*)/,F+"box-pack:$3"+V+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+F+e+e;case 4200:if(!pt(e,/flex-|baseline/))return V+"grid-column-align"+nr(e,t)+e;break;case 2592:case 3360:return V+L(e,"template-","")+e;case 4384:case 3616:return n&&n.some(function(r,o){return t=o,pt(r.props,/grid-\w+-end/)})?~ui(e+(n=n[t].value),"span",0)?e:V+L(e,"-start","")+e+V+"grid-row-span:"+(~ui(n,"span",0)?pt(n,/\d+/):+pt(n,/\d+/)-+pt(e,/\d+/))+";":V+L(e,"-start","")+e;case 4896:case 4128:return n&&n.some(function(r){return pt(r.props,/grid-\w+-start/)})?e:V+L(L(e,"-end","-span"),"span ","")+e;case 4095:case 3583:case 4068:case 2532:return L(e,/(.+)-inline(.+)/,F+"$1$2")+e;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(st(e)-1-t>6)switch(le(e,t+1)){case 109:if(le(e,t+4)!==45)break;case 102:return L(e,/(.+:)(.+)-([^]+)/,"$1"+F+"$2-$3$1"+Ur+(le(e,t+3)==108?"$3":"$2-$3"))+e;case 115:return~ui(e,"stretch",0)?ph(L(e,"stretch","fill-available"),t,n)+e:e}break;case 5152:case 5920:return L(e,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,function(r,o,i,s,l,a,c){return V+o+":"+i+c+(s?V+o+"-span:"+(l?a:+a-+i)+c:"")+e});case 4949:if(le(e,t+6)===121)return L(e,":",":"+F)+e;break;case 6444:switch(le(e,le(e,14)===45?18:11)){case 120:return L(e,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+F+(le(e,14)===45?"inline-":"")+"box$3$1"+F+"$2$3$1"+V+"$2box$3")+e;case 100:return L(e,":",":"+V)+e}break;case 5719:case 2647:case 2135:case 3927:case 2391:return L(e,"scroll-","scroll-snap-")+e}return e}function Ui(e,t){for(var n="",r=0;r<e.length;r++)n+=t(e[r],r,e,t)||"";return n}function t0(e,t,n,r){switch(e.type){case Uv:if(e.children.length)break;case Bv:case Pu:return e.return=e.return||e.value;case lh:return"";case ah:return e.return=e.value+"{"+Ui(e.children,r)+"}";case ds:if(!st(e.value=e.props.join(",")))return""}return st(n=Ui(e.children,r))?e.return=e.value+"{"+n+"}":""}function n0(e){var t=dh(e);return function(n,r,o,i){for(var s="",l=0;l<t;l++)s+=e[l](n,r,o,i)||"";return s}}function r0(e){return function(t){t.root||(t=t.return)&&e(t)}}function o0(e,t,n,r){if(e.length>-1&&!e.return)switch(e.type){case Pu:e.return=ph(e.value,e.length,n);return;case ah:return Ui([Tt(e,{value:L(e.value,"@","@"+F)})],r);case ds:if(e.length)return Wv(n=e.props,function(o){switch(pt(o,r=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":bn(Tt(e,{props:[L(o,/:(read-\w+)/,":"+Ur+"$1")]})),bn(Tt(e,{props:[o]})),pa(e,{props:Jc(n,r)});break;case"::placeholder":bn(Tt(e,{props:[L(o,/:(plac\w+)/,":"+F+"input-$1")]})),bn(Tt(e,{props:[L(o,/:(plac\w+)/,":"+Ur+"$1")]})),bn(Tt(e,{props:[L(o,/:(plac\w+)/,V+"input-$1")]})),bn(Tt(e,{props:[o]})),pa(e,{props:Jc(n,r)});break}return""})}}var i0={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},Ne={},or=typeof process<"u"&&Ne!==void 0&&(Ne.REACT_APP_SC_ATTR||Ne.SC_ATTR)||"data-styled",hh="active",mh="data-styled-version",ms="6.1.18",Tu=`/*!sc*/
`,Hi=typeof window<"u"&&typeof document<"u",s0=!!(typeof SC_DISABLE_SPEEDY=="boolean"?SC_DISABLE_SPEEDY:typeof process<"u"&&Ne!==void 0&&Ne.REACT_APP_SC_DISABLE_SPEEDY!==void 0&&Ne.REACT_APP_SC_DISABLE_SPEEDY!==""?Ne.REACT_APP_SC_DISABLE_SPEEDY!=="false"&&Ne.REACT_APP_SC_DISABLE_SPEEDY:typeof process<"u"&&Ne!==void 0&&Ne.SC_DISABLE_SPEEDY!==void 0&&Ne.SC_DISABLE_SPEEDY!==""&&Ne.SC_DISABLE_SPEEDY!=="false"&&Ne.SC_DISABLE_SPEEDY),l0={},gs=Object.freeze([]),ir=Object.freeze({});function gh(e,t,n){return n===void 0&&(n=ir),e.theme!==n.theme&&e.theme||t||n.theme}var yh=new Set(["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","tr","track","u","ul","use","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"]),a0=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,u0=/(^-|-$)/g;function td(e){return e.replace(a0,"-").replace(u0,"")}var c0=/(a)(d)/gi,Bo=52,nd=function(e){return String.fromCharCode(e+(e>25?39:97))};function ga(e){var t,n="";for(t=Math.abs(e);t>Bo;t=t/Bo|0)n=nd(t%Bo)+n;return(nd(t%Bo)+n).replace(c0,"$1-$2")}var el,vh=5381,Bn=function(e,t){for(var n=t.length;n;)e=33*e^t.charCodeAt(--n);return e},wh=function(e){return Bn(vh,e)};function xh(e){return ga(wh(e)>>>0)}function d0(e){return e.displayName||e.name||"Component"}function tl(e){return typeof e=="string"&&!0}var Sh=typeof Symbol=="function"&&Symbol.for,kh=Sh?Symbol.for("react.memo"):60115,f0=Sh?Symbol.for("react.forward_ref"):60112,p0={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},h0={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},Eh={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},m0=((el={})[f0]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},el[kh]=Eh,el);function rd(e){return("type"in(t=e)&&t.type.$$typeof)===kh?Eh:"$$typeof"in e?m0[e.$$typeof]:p0;var t}var g0=Object.defineProperty,y0=Object.getOwnPropertyNames,od=Object.getOwnPropertySymbols,v0=Object.getOwnPropertyDescriptor,w0=Object.getPrototypeOf,id=Object.prototype;function Ch(e,t,n){if(typeof t!="string"){if(id){var r=w0(t);r&&r!==id&&Ch(e,r,n)}var o=y0(t);od&&(o=o.concat(od(t)));for(var i=rd(e),s=rd(t),l=0;l<o.length;++l){var a=o[l];if(!(a in h0||n&&n[a]||s&&a in s||i&&a in i)){var c=v0(t,a);try{g0(e,a,c)}catch{}}}}return e}function Sn(e){return typeof e=="function"}function Ru(e){return typeof e=="object"&&"styledComponentId"in e}function un(e,t){return e&&t?"".concat(e," ").concat(t):e||t||""}function ya(e,t){if(e.length===0)return"";for(var n=e[0],r=1;r<e.length;r++)n+=e[r];return n}function uo(e){return e!==null&&typeof e=="object"&&e.constructor.name===Object.name&&!("props"in e&&e.$$typeof)}function va(e,t,n){if(n===void 0&&(n=!1),!n&&!uo(e)&&!Array.isArray(e))return t;if(Array.isArray(t))for(var r=0;r<t.length;r++)e[r]=va(e[r],t[r]);else if(uo(t))for(var r in t)e[r]=va(e[r],t[r]);return e}function $u(e,t){Object.defineProperty(e,"toString",{value:t})}function kn(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];return new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(e," for more information.").concat(t.length>0?" Args: ".concat(t.join(", ")):""))}var x0=function(){function e(t){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=t}return e.prototype.indexOfGroup=function(t){for(var n=0,r=0;r<t;r++)n+=this.groupSizes[r];return n},e.prototype.insertRules=function(t,n){if(t>=this.groupSizes.length){for(var r=this.groupSizes,o=r.length,i=o;t>=i;)if((i<<=1)<0)throw kn(16,"".concat(t));this.groupSizes=new Uint32Array(i),this.groupSizes.set(r),this.length=i;for(var s=o;s<i;s++)this.groupSizes[s]=0}for(var l=this.indexOfGroup(t+1),a=(s=0,n.length);s<a;s++)this.tag.insertRule(l,n[s])&&(this.groupSizes[t]++,l++)},e.prototype.clearGroup=function(t){if(t<this.length){var n=this.groupSizes[t],r=this.indexOfGroup(t),o=r+n;this.groupSizes[t]=0;for(var i=r;i<o;i++)this.tag.deleteRule(r)}},e.prototype.getGroup=function(t){var n="";if(t>=this.length||this.groupSizes[t]===0)return n;for(var r=this.groupSizes[t],o=this.indexOfGroup(t),i=o+r,s=o;s<i;s++)n+="".concat(this.tag.getRule(s)).concat(Tu);return n},e}(),fi=new Map,Wi=new Map,pi=1,Uo=function(e){if(fi.has(e))return fi.get(e);for(;Wi.has(pi);)pi++;var t=pi++;return fi.set(e,t),Wi.set(t,e),t},S0=function(e,t){pi=t+1,fi.set(e,t),Wi.set(t,e)},k0="style[".concat(or,"][").concat(mh,'="').concat(ms,'"]'),E0=new RegExp("^".concat(or,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),C0=function(e,t,n){for(var r,o=n.split(","),i=0,s=o.length;i<s;i++)(r=o[i])&&e.registerName(t,r)},j0=function(e,t){for(var n,r=((n=t.textContent)!==null&&n!==void 0?n:"").split(Tu),o=[],i=0,s=r.length;i<s;i++){var l=r[i].trim();if(l){var a=l.match(E0);if(a){var c=0|parseInt(a[1],10),f=a[2];c!==0&&(S0(f,c),C0(e,f,a[3]),e.getTag().insertRules(c,o)),o.length=0}else o.push(l)}}},sd=function(e){for(var t=document.querySelectorAll(k0),n=0,r=t.length;n<r;n++){var o=t[n];o&&o.getAttribute(or)!==hh&&(j0(e,o),o.parentNode&&o.parentNode.removeChild(o))}};function P0(){return typeof __webpack_nonce__<"u"?__webpack_nonce__:null}var jh=function(e){var t=document.head,n=e||t,r=document.createElement("style"),o=function(l){var a=Array.from(l.querySelectorAll("style[".concat(or,"]")));return a[a.length-1]}(n),i=o!==void 0?o.nextSibling:null;r.setAttribute(or,hh),r.setAttribute(mh,ms);var s=P0();return s&&r.setAttribute("nonce",s),n.insertBefore(r,i),r},b0=function(){function e(t){this.element=jh(t),this.element.appendChild(document.createTextNode("")),this.sheet=function(n){if(n.sheet)return n.sheet;for(var r=document.styleSheets,o=0,i=r.length;o<i;o++){var s=r[o];if(s.ownerNode===n)return s}throw kn(17)}(this.element),this.length=0}return e.prototype.insertRule=function(t,n){try{return this.sheet.insertRule(n,t),this.length++,!0}catch{return!1}},e.prototype.deleteRule=function(t){this.sheet.deleteRule(t),this.length--},e.prototype.getRule=function(t){var n=this.sheet.cssRules[t];return n&&n.cssText?n.cssText:""},e}(),T0=function(){function e(t){this.element=jh(t),this.nodes=this.element.childNodes,this.length=0}return e.prototype.insertRule=function(t,n){if(t<=this.length&&t>=0){var r=document.createTextNode(n);return this.element.insertBefore(r,this.nodes[t]||null),this.length++,!0}return!1},e.prototype.deleteRule=function(t){this.element.removeChild(this.nodes[t]),this.length--},e.prototype.getRule=function(t){return t<this.length?this.nodes[t].textContent:""},e}(),R0=function(){function e(t){this.rules=[],this.length=0}return e.prototype.insertRule=function(t,n){return t<=this.length&&(this.rules.splice(t,0,n),this.length++,!0)},e.prototype.deleteRule=function(t){this.rules.splice(t,1),this.length--},e.prototype.getRule=function(t){return t<this.length?this.rules[t]:""},e}(),ld=Hi,$0={isServer:!Hi,useCSSOMInjection:!s0},qi=function(){function e(t,n,r){t===void 0&&(t=ir),n===void 0&&(n={});var o=this;this.options=ae(ae({},$0),t),this.gs=n,this.names=new Map(r),this.server=!!t.isServer,!this.server&&Hi&&ld&&(ld=!1,sd(this)),$u(this,function(){return function(i){for(var s=i.getTag(),l=s.length,a="",c=function(d){var m=function(h){return Wi.get(h)}(d);if(m===void 0)return"continue";var w=i.names.get(m),y=s.getGroup(d);if(w===void 0||!w.size||y.length===0)return"continue";var v="".concat(or,".g").concat(d,'[id="').concat(m,'"]'),x="";w!==void 0&&w.forEach(function(h){h.length>0&&(x+="".concat(h,","))}),a+="".concat(y).concat(v,'{content:"').concat(x,'"}').concat(Tu)},f=0;f<l;f++)c(f);return a}(o)})}return e.registerId=function(t){return Uo(t)},e.prototype.rehydrate=function(){!this.server&&Hi&&sd(this)},e.prototype.reconstructWithOptions=function(t,n){return n===void 0&&(n=!0),new e(ae(ae({},this.options),t),this.gs,n&&this.names||void 0)},e.prototype.allocateGSInstance=function(t){return this.gs[t]=(this.gs[t]||0)+1},e.prototype.getTag=function(){return this.tag||(this.tag=(t=function(n){var r=n.useCSSOMInjection,o=n.target;return n.isServer?new R0(o):r?new b0(o):new T0(o)}(this.options),new x0(t)));var t},e.prototype.hasNameForId=function(t,n){return this.names.has(t)&&this.names.get(t).has(n)},e.prototype.registerName=function(t,n){if(Uo(t),this.names.has(t))this.names.get(t).add(n);else{var r=new Set;r.add(n),this.names.set(t,r)}},e.prototype.insertRules=function(t,n,r){this.registerName(t,n),this.getTag().insertRules(Uo(t),r)},e.prototype.clearNames=function(t){this.names.has(t)&&this.names.get(t).clear()},e.prototype.clearRules=function(t){this.getTag().clearGroup(Uo(t)),this.clearNames(t)},e.prototype.clearTag=function(){this.tag=void 0},e}(),_0=/&/g,N0=/^\s*\/\/.*$/gm;function Ph(e,t){return e.map(function(n){return n.type==="rule"&&(n.value="".concat(t," ").concat(n.value),n.value=n.value.replaceAll(",",",".concat(t," ")),n.props=n.props.map(function(r){return"".concat(t," ").concat(r)})),Array.isArray(n.children)&&n.type!=="@keyframes"&&(n.children=Ph(n.children,t)),n})}function O0(e){var t,n,r,o=ir,i=o.options,s=i===void 0?ir:i,l=o.plugins,a=l===void 0?gs:l,c=function(m,w,y){return y.startsWith(n)&&y.endsWith(n)&&y.replaceAll(n,"").length>0?".".concat(t):m},f=a.slice();f.push(function(m){m.type===ds&&m.value.includes("&")&&(m.props[0]=m.props[0].replace(_0,n).replace(r,c))}),s.prefix&&f.push(o0),f.push(t0);var d=function(m,w,y,v){w===void 0&&(w=""),y===void 0&&(y=""),v===void 0&&(v="&"),t=v,n=w,r=new RegExp("\\".concat(n,"\\b"),"g");var x=m.replace(N0,""),h=Zv(y||w?"".concat(y," ").concat(w," { ").concat(x," }"):x);s.namespace&&(h=Ph(h,s.namespace));var p=[];return Ui(h,n0(f.concat(r0(function(g){return p.push(g)})))),p};return d.hash=a.length?a.reduce(function(m,w){return w.name||kn(15),Bn(m,w.name)},vh).toString():"",d}var A0=new qi,wa=O0(),bh=Ee.createContext({shouldForwardProp:void 0,styleSheet:A0,stylis:wa});bh.Consumer;Ee.createContext(void 0);function xa(){return P.useContext(bh)}var L0=function(){function e(t,n){var r=this;this.inject=function(o,i){i===void 0&&(i=wa);var s=r.name+i.hash;o.hasNameForId(r.id,s)||o.insertRules(r.id,s,i(r.rules,s,"@keyframes"))},this.name=t,this.id="sc-keyframes-".concat(t),this.rules=n,$u(this,function(){throw kn(12,String(r.name))})}return e.prototype.getName=function(t){return t===void 0&&(t=wa),this.name+t.hash},e}(),z0=function(e){return e>="A"&&e<="Z"};function ad(e){for(var t="",n=0;n<e.length;n++){var r=e[n];if(n===1&&r==="-"&&e[0]==="-")return e;z0(r)?t+="-"+r.toLowerCase():t+=r}return t.startsWith("ms-")?"-"+t:t}var Th=function(e){return e==null||e===!1||e===""},Rh=function(e){var t,n,r=[];for(var o in e){var i=e[o];e.hasOwnProperty(o)&&!Th(i)&&(Array.isArray(i)&&i.isCss||Sn(i)?r.push("".concat(ad(o),":"),i,";"):uo(i)?r.push.apply(r,ao(ao(["".concat(o," {")],Rh(i),!1),["}"],!1)):r.push("".concat(ad(o),": ").concat((t=o,(n=i)==null||typeof n=="boolean"||n===""?"":typeof n!="number"||n===0||t in i0||t.startsWith("--")?String(n).trim():"".concat(n,"px")),";")))}return r};function qt(e,t,n,r){if(Th(e))return[];if(Ru(e))return[".".concat(e.styledComponentId)];if(Sn(e)){if(!Sn(i=e)||i.prototype&&i.prototype.isReactComponent||!t)return[e];var o=e(t);return qt(o,t,n,r)}var i;return e instanceof L0?n?(e.inject(n,r),[e.getName(r)]):[e]:uo(e)?Rh(e):Array.isArray(e)?Array.prototype.concat.apply(gs,e.map(function(s){return qt(s,t,n,r)})):[e.toString()]}function $h(e){for(var t=0;t<e.length;t+=1){var n=e[t];if(Sn(n)&&!Ru(n))return!1}return!0}var D0=wh(ms),I0=function(){function e(t,n,r){this.rules=t,this.staticRulesId="",this.isStatic=(r===void 0||r.isStatic)&&$h(t),this.componentId=n,this.baseHash=Bn(D0,n),this.baseStyle=r,qi.registerId(n)}return e.prototype.generateAndInjectStyles=function(t,n,r){var o=this.baseStyle?this.baseStyle.generateAndInjectStyles(t,n,r):"";if(this.isStatic&&!r.hash)if(this.staticRulesId&&n.hasNameForId(this.componentId,this.staticRulesId))o=un(o,this.staticRulesId);else{var i=ya(qt(this.rules,t,n,r)),s=ga(Bn(this.baseHash,i)>>>0);if(!n.hasNameForId(this.componentId,s)){var l=r(i,".".concat(s),void 0,this.componentId);n.insertRules(this.componentId,s,l)}o=un(o,s),this.staticRulesId=s}else{for(var a=Bn(this.baseHash,r.hash),c="",f=0;f<this.rules.length;f++){var d=this.rules[f];if(typeof d=="string")c+=d;else if(d){var m=ya(qt(d,t,n,r));a=Bn(a,m+f),c+=m}}if(c){var w=ga(a>>>0);n.hasNameForId(this.componentId,w)||n.insertRules(this.componentId,w,r(c,".".concat(w),void 0,this.componentId)),o=un(o,w)}}return o},e}(),co=Ee.createContext(void 0);co.Consumer;function F0(e){var t=Ee.useContext(co),n=P.useMemo(function(){return function(r,o){if(!r)throw kn(14);if(Sn(r)){var i=r(o);return i}if(Array.isArray(r)||typeof r!="object")throw kn(8);return o?ae(ae({},o),r):r}(e.theme,t)},[e.theme,t]);return e.children?Ee.createElement(co.Provider,{value:n},e.children):null}var nl={};function M0(e,t,n){var r=Ru(e),o=e,i=!tl(e),s=t.attrs,l=s===void 0?gs:s,a=t.componentId,c=a===void 0?function(S,C){var j=typeof S!="string"?"sc":td(S);nl[j]=(nl[j]||0)+1;var b="".concat(j,"-").concat(xh(ms+j+nl[j]));return C?"".concat(C,"-").concat(b):b}(t.displayName,t.parentComponentId):a,f=t.displayName,d=f===void 0?function(S){return tl(S)?"styled.".concat(S):"Styled(".concat(d0(S),")")}(e):f,m=t.displayName&&t.componentId?"".concat(td(t.displayName),"-").concat(t.componentId):t.componentId||c,w=r&&o.attrs?o.attrs.concat(l).filter(Boolean):l,y=t.shouldForwardProp;if(r&&o.shouldForwardProp){var v=o.shouldForwardProp;if(t.shouldForwardProp){var x=t.shouldForwardProp;y=function(S,C){return v(S,C)&&x(S,C)}}else y=v}var h=new I0(n,m,r?o.componentStyle:void 0);function p(S,C){return function(j,b,_){var M=j.attrs,z=j.componentStyle,$e=j.defaultProps,Jt=j.foldedComponentIds,Zt=j.styledComponentId,ko=j.target,Cs=Ee.useContext(co),hr=xa(),en=j.shouldForwardProp||hr.shouldForwardProp,R=gh(b,Cs,$e)||ir,N=function(jt,_e,dt){for(var mr,nn=ae(ae({},_e),{className:void 0,theme:dt}),js=0;js<jt.length;js+=1){var Eo=Sn(mr=jt[js])?mr(nn):mr;for(var Pt in Eo)nn[Pt]=Pt==="className"?un(nn[Pt],Eo[Pt]):Pt==="style"?ae(ae({},nn[Pt]),Eo[Pt]):Eo[Pt]}return _e.className&&(nn.className=un(nn.className,_e.className)),nn}(M,b,R),O=N.as||ko,U={};for(var H in N)N[H]===void 0||H[0]==="$"||H==="as"||H==="theme"&&N.theme===R||(H==="forwardedAs"?U.as=N.forwardedAs:en&&!en(H,O)||(U[H]=N[H]));var tn=function(jt,_e){var dt=xa(),mr=jt.generateAndInjectStyles(_e,dt.styleSheet,dt.stylis);return mr}(z,N),Qe=un(Jt,Zt);return tn&&(Qe+=" "+tn),N.className&&(Qe+=" "+N.className),U[tl(O)&&!yh.has(O)?"class":"className"]=Qe,_&&(U.ref=_),P.createElement(O,U)}(g,S,C)}p.displayName=d;var g=Ee.forwardRef(p);return g.attrs=w,g.componentStyle=h,g.displayName=d,g.shouldForwardProp=y,g.foldedComponentIds=r?un(o.foldedComponentIds,o.styledComponentId):"",g.styledComponentId=m,g.target=r?o.target:e,Object.defineProperty(g,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(S){this._foldedDefaultProps=r?function(C){for(var j=[],b=1;b<arguments.length;b++)j[b-1]=arguments[b];for(var _=0,M=j;_<M.length;_++)va(C,M[_],!0);return C}({},o.defaultProps,S):S}}),$u(g,function(){return".".concat(g.styledComponentId)}),i&&Ch(g,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),g}function ud(e,t){for(var n=[e[0]],r=0,o=t.length;r<o;r+=1)n.push(t[r],e[r+1]);return n}var cd=function(e){return Object.assign(e,{isCss:!0})};function _h(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];if(Sn(e)||uo(e))return cd(qt(ud(gs,ao([e],t,!0))));var r=e;return t.length===0&&r.length===1&&typeof r[0]=="string"?qt(r):cd(qt(ud(r,t)))}function Sa(e,t,n){if(n===void 0&&(n=ir),!t)throw kn(1,t);var r=function(o){for(var i=[],s=1;s<arguments.length;s++)i[s-1]=arguments[s];return e(t,n,_h.apply(void 0,ao([o],i,!1)))};return r.attrs=function(o){return Sa(e,t,ae(ae({},n),{attrs:Array.prototype.concat(n.attrs,o).filter(Boolean)}))},r.withConfig=function(o){return Sa(e,t,ae(ae({},n),o))},r}var Nh=function(e){return Sa(M0,e)},k=Nh;yh.forEach(function(e){k[e]=Nh(e)});var B0=function(){function e(t,n){this.rules=t,this.componentId=n,this.isStatic=$h(t),qi.registerId(this.componentId+1)}return e.prototype.createStyles=function(t,n,r,o){var i=o(ya(qt(this.rules,n,r,o)),""),s=this.componentId+t;r.insertRules(s,s,i)},e.prototype.removeStyles=function(t,n){n.clearRules(this.componentId+t)},e.prototype.renderStyles=function(t,n,r,o){t>2&&qi.registerId(this.componentId+t),this.removeStyles(t,r),this.createStyles(t,n,r,o)},e}();function U0(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];var r=_h.apply(void 0,ao([e],t,!1)),o="sc-global-".concat(xh(JSON.stringify(r))),i=new B0(r,o),s=function(a){var c=xa(),f=Ee.useContext(co),d=Ee.useRef(c.styleSheet.allocateGSInstance(o)).current;return c.styleSheet.server&&l(d,a,c.styleSheet,f,c.stylis),Ee.useLayoutEffect(function(){if(!c.styleSheet.server)return l(d,a,c.styleSheet,f,c.stylis),function(){return i.removeStyles(d,c.styleSheet)}},[d,a,c.styleSheet,f,c.stylis]),null};function l(a,c,f,d,m){if(i.isStatic)i.renderStyles(a,l0,f,m);else{var w=ae(ae({},c),{theme:gh(c,d,s.defaultProps)});i.renderStyles(a,w,f,m)}}return Ee.memo(s)}const H0=U0`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
      'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
      sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    background-color: ${e=>e.theme.colors.background};
    color: ${e=>e.theme.colors.text};
    line-height: 1.6;
  }

  h1, h2, h3, h4, h5, h6 {
    font-weight: 700;
    margin-bottom: 1rem;
    color: ${e=>e.theme.colors.primary};
  }

  a {
    color: ${e=>e.theme.colors.primary};
    text-decoration: none;
    transition: color 0.3s ease;
    
    &:hover {
      color: ${e=>e.theme.colors.secondary};
    }
  }

  button {
    cursor: pointer;
    border: none;
    border-radius: 4px;
    padding: 0.75rem 1.5rem;
    font-weight: 600;
    transition: all 0.3s ease;
    
    &:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
  }

  input, textarea, select {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid ${e=>e.theme.colors.border};
    border-radius: 4px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
    
    &:focus {
      outline: none;
      border-color: ${e=>e.theme.colors.primary};
    }
  }

  .container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
  }

  .btn-primary {
    background-color: ${e=>e.theme.colors.primary};
    color: white;
    
    &:hover {
      background-color: ${e=>e.theme.colors.primaryDark};
    }
  }

  .btn-secondary {
    background-color: ${e=>e.theme.colors.secondary};
    color: white;
    
    &:hover {
      background-color: ${e=>e.theme.colors.secondaryDark};
    }
  }

  .btn-outline {
    background-color: transparent;
    border: 2px solid ${e=>e.theme.colors.primary};
    color: ${e=>e.theme.colors.primary};
    
    &:hover {
      background-color: ${e=>e.theme.colors.primary};
      color: white;
    }
  }
`,W0={colors:{primary:"#3a86ff",primaryDark:"#2a75ee",secondary:"#ff006e",secondaryDark:"#e0005d",background:"#f8f9fa",backgroundDark:"#e9ecef",text:"#212529",textLight:"#6c757d",border:"#dee2e6",success:"#38b000",error:"#d90429",warning:"#ffbe0b"},fonts:{body:"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",heading:"'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif"},breakpoints:{mobile:"576px",tablet:"768px",desktop:"992px",wide:"1200px"},shadows:{small:"0 2px 4px rgba(0, 0, 0, 0.1)",medium:"0 4px 6px rgba(0, 0, 0, 0.1)",large:"0 10px 15px rgba(0, 0, 0, 0.1)"},transitions:{default:"0.3s ease",fast:"0.15s ease",slow:"0.5s ease"}};function Oh(e,t){return function(){return e.apply(t,arguments)}}const{toString:q0}=Object.prototype,{getPrototypeOf:_u}=Object,{iterator:ys,toStringTag:Ah}=Symbol,vs=(e=>t=>{const n=q0.call(t);return e[n]||(e[n]=n.slice(8,-1).toLowerCase())})(Object.create(null)),tt=e=>(e=e.toLowerCase(),t=>vs(t)===e),ws=e=>t=>typeof t===e,{isArray:fr}=Array,fo=ws("undefined");function Q0(e){return e!==null&&!fo(e)&&e.constructor!==null&&!fo(e.constructor)&&Te(e.constructor.isBuffer)&&e.constructor.isBuffer(e)}const Lh=tt("ArrayBuffer");function V0(e){let t;return typeof ArrayBuffer<"u"&&ArrayBuffer.isView?t=ArrayBuffer.isView(e):t=e&&e.buffer&&Lh(e.buffer),t}const K0=ws("string"),Te=ws("function"),zh=ws("number"),xs=e=>e!==null&&typeof e=="object",G0=e=>e===!0||e===!1,hi=e=>{if(vs(e)!=="object")return!1;const t=_u(e);return(t===null||t===Object.prototype||Object.getPrototypeOf(t)===null)&&!(Ah in e)&&!(ys in e)},Y0=tt("Date"),X0=tt("File"),J0=tt("Blob"),Z0=tt("FileList"),e1=e=>xs(e)&&Te(e.pipe),t1=e=>{let t;return e&&(typeof FormData=="function"&&e instanceof FormData||Te(e.append)&&((t=vs(e))==="formdata"||t==="object"&&Te(e.toString)&&e.toString()==="[object FormData]"))},n1=tt("URLSearchParams"),[r1,o1,i1,s1]=["ReadableStream","Request","Response","Headers"].map(tt),l1=e=>e.trim?e.trim():e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"");function xo(e,t,{allOwnKeys:n=!1}={}){if(e===null||typeof e>"u")return;let r,o;if(typeof e!="object"&&(e=[e]),fr(e))for(r=0,o=e.length;r<o;r++)t.call(null,e[r],r,e);else{const i=n?Object.getOwnPropertyNames(e):Object.keys(e),s=i.length;let l;for(r=0;r<s;r++)l=i[r],t.call(null,e[l],l,e)}}function Dh(e,t){t=t.toLowerCase();const n=Object.keys(e);let r=n.length,o;for(;r-- >0;)if(o=n[r],t===o.toLowerCase())return o;return null}const cn=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:global,Ih=e=>!fo(e)&&e!==cn;function ka(){const{caseless:e}=Ih(this)&&this||{},t={},n=(r,o)=>{const i=e&&Dh(t,o)||o;hi(t[i])&&hi(r)?t[i]=ka(t[i],r):hi(r)?t[i]=ka({},r):fr(r)?t[i]=r.slice():t[i]=r};for(let r=0,o=arguments.length;r<o;r++)arguments[r]&&xo(arguments[r],n);return t}const a1=(e,t,n,{allOwnKeys:r}={})=>(xo(t,(o,i)=>{n&&Te(o)?e[i]=Oh(o,n):e[i]=o},{allOwnKeys:r}),e),u1=e=>(e.charCodeAt(0)===65279&&(e=e.slice(1)),e),c1=(e,t,n,r)=>{e.prototype=Object.create(t.prototype,r),e.prototype.constructor=e,Object.defineProperty(e,"super",{value:t.prototype}),n&&Object.assign(e.prototype,n)},d1=(e,t,n,r)=>{let o,i,s;const l={};if(t=t||{},e==null)return t;do{for(o=Object.getOwnPropertyNames(e),i=o.length;i-- >0;)s=o[i],(!r||r(s,e,t))&&!l[s]&&(t[s]=e[s],l[s]=!0);e=n!==!1&&_u(e)}while(e&&(!n||n(e,t))&&e!==Object.prototype);return t},f1=(e,t,n)=>{e=String(e),(n===void 0||n>e.length)&&(n=e.length),n-=t.length;const r=e.indexOf(t,n);return r!==-1&&r===n},p1=e=>{if(!e)return null;if(fr(e))return e;let t=e.length;if(!zh(t))return null;const n=new Array(t);for(;t-- >0;)n[t]=e[t];return n},h1=(e=>t=>e&&t instanceof e)(typeof Uint8Array<"u"&&_u(Uint8Array)),m1=(e,t)=>{const r=(e&&e[ys]).call(e);let o;for(;(o=r.next())&&!o.done;){const i=o.value;t.call(e,i[0],i[1])}},g1=(e,t)=>{let n;const r=[];for(;(n=e.exec(t))!==null;)r.push(n);return r},y1=tt("HTMLFormElement"),v1=e=>e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g,function(n,r,o){return r.toUpperCase()+o}),dd=(({hasOwnProperty:e})=>(t,n)=>e.call(t,n))(Object.prototype),w1=tt("RegExp"),Fh=(e,t)=>{const n=Object.getOwnPropertyDescriptors(e),r={};xo(n,(o,i)=>{let s;(s=t(o,i,e))!==!1&&(r[i]=s||o)}),Object.defineProperties(e,r)},x1=e=>{Fh(e,(t,n)=>{if(Te(e)&&["arguments","caller","callee"].indexOf(n)!==-1)return!1;const r=e[n];if(Te(r)){if(t.enumerable=!1,"writable"in t){t.writable=!1;return}t.set||(t.set=()=>{throw Error("Can not rewrite read-only method '"+n+"'")})}})},S1=(e,t)=>{const n={},r=o=>{o.forEach(i=>{n[i]=!0})};return fr(e)?r(e):r(String(e).split(t)),n},k1=()=>{},E1=(e,t)=>e!=null&&Number.isFinite(e=+e)?e:t;function C1(e){return!!(e&&Te(e.append)&&e[Ah]==="FormData"&&e[ys])}const j1=e=>{const t=new Array(10),n=(r,o)=>{if(xs(r)){if(t.indexOf(r)>=0)return;if(!("toJSON"in r)){t[o]=r;const i=fr(r)?[]:{};return xo(r,(s,l)=>{const a=n(s,o+1);!fo(a)&&(i[l]=a)}),t[o]=void 0,i}}return r};return n(e,0)},P1=tt("AsyncFunction"),b1=e=>e&&(xs(e)||Te(e))&&Te(e.then)&&Te(e.catch),Mh=((e,t)=>e?setImmediate:t?((n,r)=>(cn.addEventListener("message",({source:o,data:i})=>{o===cn&&i===n&&r.length&&r.shift()()},!1),o=>{r.push(o),cn.postMessage(n,"*")}))(`axios@${Math.random()}`,[]):n=>setTimeout(n))(typeof setImmediate=="function",Te(cn.postMessage)),T1=typeof queueMicrotask<"u"?queueMicrotask.bind(cn):typeof process<"u"&&process.nextTick||Mh,R1=e=>e!=null&&Te(e[ys]),E={isArray:fr,isArrayBuffer:Lh,isBuffer:Q0,isFormData:t1,isArrayBufferView:V0,isString:K0,isNumber:zh,isBoolean:G0,isObject:xs,isPlainObject:hi,isReadableStream:r1,isRequest:o1,isResponse:i1,isHeaders:s1,isUndefined:fo,isDate:Y0,isFile:X0,isBlob:J0,isRegExp:w1,isFunction:Te,isStream:e1,isURLSearchParams:n1,isTypedArray:h1,isFileList:Z0,forEach:xo,merge:ka,extend:a1,trim:l1,stripBOM:u1,inherits:c1,toFlatObject:d1,kindOf:vs,kindOfTest:tt,endsWith:f1,toArray:p1,forEachEntry:m1,matchAll:g1,isHTMLForm:y1,hasOwnProperty:dd,hasOwnProp:dd,reduceDescriptors:Fh,freezeMethods:x1,toObjectSet:S1,toCamelCase:v1,noop:k1,toFiniteNumber:E1,findKey:Dh,global:cn,isContextDefined:Ih,isSpecCompliantForm:C1,toJSONObject:j1,isAsyncFn:P1,isThenable:b1,setImmediate:Mh,asap:T1,isIterable:R1};function A(e,t,n,r,o){Error.call(this),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=new Error().stack,this.message=e,this.name="AxiosError",t&&(this.code=t),n&&(this.config=n),r&&(this.request=r),o&&(this.response=o,this.status=o.status?o.status:null)}E.inherits(A,Error,{toJSON:function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:E.toJSONObject(this.config),code:this.code,status:this.status}}});const Bh=A.prototype,Uh={};["ERR_BAD_OPTION_VALUE","ERR_BAD_OPTION","ECONNABORTED","ETIMEDOUT","ERR_NETWORK","ERR_FR_TOO_MANY_REDIRECTS","ERR_DEPRECATED","ERR_BAD_RESPONSE","ERR_BAD_REQUEST","ERR_CANCELED","ERR_NOT_SUPPORT","ERR_INVALID_URL"].forEach(e=>{Uh[e]={value:e}});Object.defineProperties(A,Uh);Object.defineProperty(Bh,"isAxiosError",{value:!0});A.from=(e,t,n,r,o,i)=>{const s=Object.create(Bh);return E.toFlatObject(e,s,function(a){return a!==Error.prototype},l=>l!=="isAxiosError"),A.call(s,e.message,t,n,r,o),s.cause=e,s.name=e.name,i&&Object.assign(s,i),s};const $1=null;function Ea(e){return E.isPlainObject(e)||E.isArray(e)}function Hh(e){return E.endsWith(e,"[]")?e.slice(0,-2):e}function fd(e,t,n){return e?e.concat(t).map(function(o,i){return o=Hh(o),!n&&i?"["+o+"]":o}).join(n?".":""):t}function _1(e){return E.isArray(e)&&!e.some(Ea)}const N1=E.toFlatObject(E,{},null,function(t){return/^is[A-Z]/.test(t)});function Ss(e,t,n){if(!E.isObject(e))throw new TypeError("target must be an object");t=t||new FormData,n=E.toFlatObject(n,{metaTokens:!0,dots:!1,indexes:!1},!1,function(v,x){return!E.isUndefined(x[v])});const r=n.metaTokens,o=n.visitor||f,i=n.dots,s=n.indexes,a=(n.Blob||typeof Blob<"u"&&Blob)&&E.isSpecCompliantForm(t);if(!E.isFunction(o))throw new TypeError("visitor must be a function");function c(y){if(y===null)return"";if(E.isDate(y))return y.toISOString();if(!a&&E.isBlob(y))throw new A("Blob is not supported. Use a Buffer instead.");return E.isArrayBuffer(y)||E.isTypedArray(y)?a&&typeof Blob=="function"?new Blob([y]):Buffer.from(y):y}function f(y,v,x){let h=y;if(y&&!x&&typeof y=="object"){if(E.endsWith(v,"{}"))v=r?v:v.slice(0,-2),y=JSON.stringify(y);else if(E.isArray(y)&&_1(y)||(E.isFileList(y)||E.endsWith(v,"[]"))&&(h=E.toArray(y)))return v=Hh(v),h.forEach(function(g,S){!(E.isUndefined(g)||g===null)&&t.append(s===!0?fd([v],S,i):s===null?v:v+"[]",c(g))}),!1}return Ea(y)?!0:(t.append(fd(x,v,i),c(y)),!1)}const d=[],m=Object.assign(N1,{defaultVisitor:f,convertValue:c,isVisitable:Ea});function w(y,v){if(!E.isUndefined(y)){if(d.indexOf(y)!==-1)throw Error("Circular reference detected in "+v.join("."));d.push(y),E.forEach(y,function(h,p){(!(E.isUndefined(h)||h===null)&&o.call(t,h,E.isString(p)?p.trim():p,v,m))===!0&&w(h,v?v.concat(p):[p])}),d.pop()}}if(!E.isObject(e))throw new TypeError("data must be an object");return w(e),t}function pd(e){const t={"!":"%21","'":"%27","(":"%28",")":"%29","~":"%7E","%20":"+","%00":"\0"};return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g,function(r){return t[r]})}function Nu(e,t){this._pairs=[],e&&Ss(e,this,t)}const Wh=Nu.prototype;Wh.append=function(t,n){this._pairs.push([t,n])};Wh.toString=function(t){const n=t?function(r){return t.call(this,r,pd)}:pd;return this._pairs.map(function(o){return n(o[0])+"="+n(o[1])},"").join("&")};function O1(e){return encodeURIComponent(e).replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}function qh(e,t,n){if(!t)return e;const r=n&&n.encode||O1;E.isFunction(n)&&(n={serialize:n});const o=n&&n.serialize;let i;if(o?i=o(t,n):i=E.isURLSearchParams(t)?t.toString():new Nu(t,n).toString(r),i){const s=e.indexOf("#");s!==-1&&(e=e.slice(0,s)),e+=(e.indexOf("?")===-1?"?":"&")+i}return e}class hd{constructor(){this.handlers=[]}use(t,n,r){return this.handlers.push({fulfilled:t,rejected:n,synchronous:r?r.synchronous:!1,runWhen:r?r.runWhen:null}),this.handlers.length-1}eject(t){this.handlers[t]&&(this.handlers[t]=null)}clear(){this.handlers&&(this.handlers=[])}forEach(t){E.forEach(this.handlers,function(r){r!==null&&t(r)})}}const Qh={silentJSONParsing:!0,forcedJSONParsing:!0,clarifyTimeoutError:!1},A1=typeof URLSearchParams<"u"?URLSearchParams:Nu,L1=typeof FormData<"u"?FormData:null,z1=typeof Blob<"u"?Blob:null,D1={isBrowser:!0,classes:{URLSearchParams:A1,FormData:L1,Blob:z1},protocols:["http","https","file","blob","url","data"]},Ou=typeof window<"u"&&typeof document<"u",Ca=typeof navigator=="object"&&navigator||void 0,I1=Ou&&(!Ca||["ReactNative","NativeScript","NS"].indexOf(Ca.product)<0),F1=typeof WorkerGlobalScope<"u"&&self instanceof WorkerGlobalScope&&typeof self.importScripts=="function",M1=Ou&&window.location.href||"http://localhost",B1=Object.freeze(Object.defineProperty({__proto__:null,hasBrowserEnv:Ou,hasStandardBrowserEnv:I1,hasStandardBrowserWebWorkerEnv:F1,navigator:Ca,origin:M1},Symbol.toStringTag,{value:"Module"})),ge={...B1,...D1};function U1(e,t){return Ss(e,new ge.classes.URLSearchParams,Object.assign({visitor:function(n,r,o,i){return ge.isNode&&E.isBuffer(n)?(this.append(r,n.toString("base64")),!1):i.defaultVisitor.apply(this,arguments)}},t))}function H1(e){return E.matchAll(/\w+|\[(\w*)]/g,e).map(t=>t[0]==="[]"?"":t[1]||t[0])}function W1(e){const t={},n=Object.keys(e);let r;const o=n.length;let i;for(r=0;r<o;r++)i=n[r],t[i]=e[i];return t}function Vh(e){function t(n,r,o,i){let s=n[i++];if(s==="__proto__")return!0;const l=Number.isFinite(+s),a=i>=n.length;return s=!s&&E.isArray(o)?o.length:s,a?(E.hasOwnProp(o,s)?o[s]=[o[s],r]:o[s]=r,!l):((!o[s]||!E.isObject(o[s]))&&(o[s]=[]),t(n,r,o[s],i)&&E.isArray(o[s])&&(o[s]=W1(o[s])),!l)}if(E.isFormData(e)&&E.isFunction(e.entries)){const n={};return E.forEachEntry(e,(r,o)=>{t(H1(r),o,n,0)}),n}return null}function q1(e,t,n){if(E.isString(e))try{return(t||JSON.parse)(e),E.trim(e)}catch(r){if(r.name!=="SyntaxError")throw r}return(n||JSON.stringify)(e)}const So={transitional:Qh,adapter:["xhr","http","fetch"],transformRequest:[function(t,n){const r=n.getContentType()||"",o=r.indexOf("application/json")>-1,i=E.isObject(t);if(i&&E.isHTMLForm(t)&&(t=new FormData(t)),E.isFormData(t))return o?JSON.stringify(Vh(t)):t;if(E.isArrayBuffer(t)||E.isBuffer(t)||E.isStream(t)||E.isFile(t)||E.isBlob(t)||E.isReadableStream(t))return t;if(E.isArrayBufferView(t))return t.buffer;if(E.isURLSearchParams(t))return n.setContentType("application/x-www-form-urlencoded;charset=utf-8",!1),t.toString();let l;if(i){if(r.indexOf("application/x-www-form-urlencoded")>-1)return U1(t,this.formSerializer).toString();if((l=E.isFileList(t))||r.indexOf("multipart/form-data")>-1){const a=this.env&&this.env.FormData;return Ss(l?{"files[]":t}:t,a&&new a,this.formSerializer)}}return i||o?(n.setContentType("application/json",!1),q1(t)):t}],transformResponse:[function(t){const n=this.transitional||So.transitional,r=n&&n.forcedJSONParsing,o=this.responseType==="json";if(E.isResponse(t)||E.isReadableStream(t))return t;if(t&&E.isString(t)&&(r&&!this.responseType||o)){const s=!(n&&n.silentJSONParsing)&&o;try{return JSON.parse(t)}catch(l){if(s)throw l.name==="SyntaxError"?A.from(l,A.ERR_BAD_RESPONSE,this,null,this.response):l}}return t}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,maxBodyLength:-1,env:{FormData:ge.classes.FormData,Blob:ge.classes.Blob},validateStatus:function(t){return t>=200&&t<300},headers:{common:{Accept:"application/json, text/plain, */*","Content-Type":void 0}}};E.forEach(["delete","get","head","post","put","patch"],e=>{So.headers[e]={}});const Q1=E.toObjectSet(["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"]),V1=e=>{const t={};let n,r,o;return e&&e.split(`
`).forEach(function(s){o=s.indexOf(":"),n=s.substring(0,o).trim().toLowerCase(),r=s.substring(o+1).trim(),!(!n||t[n]&&Q1[n])&&(n==="set-cookie"?t[n]?t[n].push(r):t[n]=[r]:t[n]=t[n]?t[n]+", "+r:r)}),t},md=Symbol("internals");function Cr(e){return e&&String(e).trim().toLowerCase()}function mi(e){return e===!1||e==null?e:E.isArray(e)?e.map(mi):String(e)}function K1(e){const t=Object.create(null),n=/([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;let r;for(;r=n.exec(e);)t[r[1]]=r[2];return t}const G1=e=>/^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());function rl(e,t,n,r,o){if(E.isFunction(r))return r.call(this,t,n);if(o&&(t=n),!!E.isString(t)){if(E.isString(r))return t.indexOf(r)!==-1;if(E.isRegExp(r))return r.test(t)}}function Y1(e){return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g,(t,n,r)=>n.toUpperCase()+r)}function X1(e,t){const n=E.toCamelCase(" "+t);["get","set","has"].forEach(r=>{Object.defineProperty(e,r+n,{value:function(o,i,s){return this[r].call(this,t,o,i,s)},configurable:!0})})}let Re=class{constructor(t){t&&this.set(t)}set(t,n,r){const o=this;function i(l,a,c){const f=Cr(a);if(!f)throw new Error("header name must be a non-empty string");const d=E.findKey(o,f);(!d||o[d]===void 0||c===!0||c===void 0&&o[d]!==!1)&&(o[d||a]=mi(l))}const s=(l,a)=>E.forEach(l,(c,f)=>i(c,f,a));if(E.isPlainObject(t)||t instanceof this.constructor)s(t,n);else if(E.isString(t)&&(t=t.trim())&&!G1(t))s(V1(t),n);else if(E.isObject(t)&&E.isIterable(t)){let l={},a,c;for(const f of t){if(!E.isArray(f))throw TypeError("Object iterator must return a key-value pair");l[c=f[0]]=(a=l[c])?E.isArray(a)?[...a,f[1]]:[a,f[1]]:f[1]}s(l,n)}else t!=null&&i(n,t,r);return this}get(t,n){if(t=Cr(t),t){const r=E.findKey(this,t);if(r){const o=this[r];if(!n)return o;if(n===!0)return K1(o);if(E.isFunction(n))return n.call(this,o,r);if(E.isRegExp(n))return n.exec(o);throw new TypeError("parser must be boolean|regexp|function")}}}has(t,n){if(t=Cr(t),t){const r=E.findKey(this,t);return!!(r&&this[r]!==void 0&&(!n||rl(this,this[r],r,n)))}return!1}delete(t,n){const r=this;let o=!1;function i(s){if(s=Cr(s),s){const l=E.findKey(r,s);l&&(!n||rl(r,r[l],l,n))&&(delete r[l],o=!0)}}return E.isArray(t)?t.forEach(i):i(t),o}clear(t){const n=Object.keys(this);let r=n.length,o=!1;for(;r--;){const i=n[r];(!t||rl(this,this[i],i,t,!0))&&(delete this[i],o=!0)}return o}normalize(t){const n=this,r={};return E.forEach(this,(o,i)=>{const s=E.findKey(r,i);if(s){n[s]=mi(o),delete n[i];return}const l=t?Y1(i):String(i).trim();l!==i&&delete n[i],n[l]=mi(o),r[l]=!0}),this}concat(...t){return this.constructor.concat(this,...t)}toJSON(t){const n=Object.create(null);return E.forEach(this,(r,o)=>{r!=null&&r!==!1&&(n[o]=t&&E.isArray(r)?r.join(", "):r)}),n}[Symbol.iterator](){return Object.entries(this.toJSON())[Symbol.iterator]()}toString(){return Object.entries(this.toJSON()).map(([t,n])=>t+": "+n).join(`
`)}getSetCookie(){return this.get("set-cookie")||[]}get[Symbol.toStringTag](){return"AxiosHeaders"}static from(t){return t instanceof this?t:new this(t)}static concat(t,...n){const r=new this(t);return n.forEach(o=>r.set(o)),r}static accessor(t){const r=(this[md]=this[md]={accessors:{}}).accessors,o=this.prototype;function i(s){const l=Cr(s);r[l]||(X1(o,s),r[l]=!0)}return E.isArray(t)?t.forEach(i):i(t),this}};Re.accessor(["Content-Type","Content-Length","Accept","Accept-Encoding","User-Agent","Authorization"]);E.reduceDescriptors(Re.prototype,({value:e},t)=>{let n=t[0].toUpperCase()+t.slice(1);return{get:()=>e,set(r){this[n]=r}}});E.freezeMethods(Re);function ol(e,t){const n=this||So,r=t||n,o=Re.from(r.headers);let i=r.data;return E.forEach(e,function(l){i=l.call(n,i,o.normalize(),t?t.status:void 0)}),o.normalize(),i}function Kh(e){return!!(e&&e.__CANCEL__)}function pr(e,t,n){A.call(this,e??"canceled",A.ERR_CANCELED,t,n),this.name="CanceledError"}E.inherits(pr,A,{__CANCEL__:!0});function Gh(e,t,n){const r=n.config.validateStatus;!n.status||!r||r(n.status)?e(n):t(new A("Request failed with status code "+n.status,[A.ERR_BAD_REQUEST,A.ERR_BAD_RESPONSE][Math.floor(n.status/100)-4],n.config,n.request,n))}function J1(e){const t=/^([-+\w]{1,25})(:?\/\/|:)/.exec(e);return t&&t[1]||""}function Z1(e,t){e=e||10;const n=new Array(e),r=new Array(e);let o=0,i=0,s;return t=t!==void 0?t:1e3,function(a){const c=Date.now(),f=r[i];s||(s=c),n[o]=a,r[o]=c;let d=i,m=0;for(;d!==o;)m+=n[d++],d=d%e;if(o=(o+1)%e,o===i&&(i=(i+1)%e),c-s<t)return;const w=f&&c-f;return w?Math.round(m*1e3/w):void 0}}function ew(e,t){let n=0,r=1e3/t,o,i;const s=(c,f=Date.now())=>{n=f,o=null,i&&(clearTimeout(i),i=null),e.apply(null,c)};return[(...c)=>{const f=Date.now(),d=f-n;d>=r?s(c,f):(o=c,i||(i=setTimeout(()=>{i=null,s(o)},r-d)))},()=>o&&s(o)]}const Qi=(e,t,n=3)=>{let r=0;const o=Z1(50,250);return ew(i=>{const s=i.loaded,l=i.lengthComputable?i.total:void 0,a=s-r,c=o(a),f=s<=l;r=s;const d={loaded:s,total:l,progress:l?s/l:void 0,bytes:a,rate:c||void 0,estimated:c&&l&&f?(l-s)/c:void 0,event:i,lengthComputable:l!=null,[t?"download":"upload"]:!0};e(d)},n)},gd=(e,t)=>{const n=e!=null;return[r=>t[0]({lengthComputable:n,total:e,loaded:r}),t[1]]},yd=e=>(...t)=>E.asap(()=>e(...t)),tw=ge.hasStandardBrowserEnv?((e,t)=>n=>(n=new URL(n,ge.origin),e.protocol===n.protocol&&e.host===n.host&&(t||e.port===n.port)))(new URL(ge.origin),ge.navigator&&/(msie|trident)/i.test(ge.navigator.userAgent)):()=>!0,nw=ge.hasStandardBrowserEnv?{write(e,t,n,r,o,i){const s=[e+"="+encodeURIComponent(t)];E.isNumber(n)&&s.push("expires="+new Date(n).toGMTString()),E.isString(r)&&s.push("path="+r),E.isString(o)&&s.push("domain="+o),i===!0&&s.push("secure"),document.cookie=s.join("; ")},read(e){const t=document.cookie.match(new RegExp("(^|;\\s*)("+e+")=([^;]*)"));return t?decodeURIComponent(t[3]):null},remove(e){this.write(e,"",Date.now()-864e5)}}:{write(){},read(){return null},remove(){}};function rw(e){return/^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)}function ow(e,t){return t?e.replace(/\/?\/$/,"")+"/"+t.replace(/^\/+/,""):e}function Yh(e,t,n){let r=!rw(t);return e&&(r||n==!1)?ow(e,t):t}const vd=e=>e instanceof Re?{...e}:e;function En(e,t){t=t||{};const n={};function r(c,f,d,m){return E.isPlainObject(c)&&E.isPlainObject(f)?E.merge.call({caseless:m},c,f):E.isPlainObject(f)?E.merge({},f):E.isArray(f)?f.slice():f}function o(c,f,d,m){if(E.isUndefined(f)){if(!E.isUndefined(c))return r(void 0,c,d,m)}else return r(c,f,d,m)}function i(c,f){if(!E.isUndefined(f))return r(void 0,f)}function s(c,f){if(E.isUndefined(f)){if(!E.isUndefined(c))return r(void 0,c)}else return r(void 0,f)}function l(c,f,d){if(d in t)return r(c,f);if(d in e)return r(void 0,c)}const a={url:i,method:i,data:i,baseURL:s,transformRequest:s,transformResponse:s,paramsSerializer:s,timeout:s,timeoutMessage:s,withCredentials:s,withXSRFToken:s,adapter:s,responseType:s,xsrfCookieName:s,xsrfHeaderName:s,onUploadProgress:s,onDownloadProgress:s,decompress:s,maxContentLength:s,maxBodyLength:s,beforeRedirect:s,transport:s,httpAgent:s,httpsAgent:s,cancelToken:s,socketPath:s,responseEncoding:s,validateStatus:l,headers:(c,f,d)=>o(vd(c),vd(f),d,!0)};return E.forEach(Object.keys(Object.assign({},e,t)),function(f){const d=a[f]||o,m=d(e[f],t[f],f);E.isUndefined(m)&&d!==l||(n[f]=m)}),n}const Xh=e=>{const t=En({},e);let{data:n,withXSRFToken:r,xsrfHeaderName:o,xsrfCookieName:i,headers:s,auth:l}=t;t.headers=s=Re.from(s),t.url=qh(Yh(t.baseURL,t.url,t.allowAbsoluteUrls),e.params,e.paramsSerializer),l&&s.set("Authorization","Basic "+btoa((l.username||"")+":"+(l.password?unescape(encodeURIComponent(l.password)):"")));let a;if(E.isFormData(n)){if(ge.hasStandardBrowserEnv||ge.hasStandardBrowserWebWorkerEnv)s.setContentType(void 0);else if((a=s.getContentType())!==!1){const[c,...f]=a?a.split(";").map(d=>d.trim()).filter(Boolean):[];s.setContentType([c||"multipart/form-data",...f].join("; "))}}if(ge.hasStandardBrowserEnv&&(r&&E.isFunction(r)&&(r=r(t)),r||r!==!1&&tw(t.url))){const c=o&&i&&nw.read(i);c&&s.set(o,c)}return t},iw=typeof XMLHttpRequest<"u",sw=iw&&function(e){return new Promise(function(n,r){const o=Xh(e);let i=o.data;const s=Re.from(o.headers).normalize();let{responseType:l,onUploadProgress:a,onDownloadProgress:c}=o,f,d,m,w,y;function v(){w&&w(),y&&y(),o.cancelToken&&o.cancelToken.unsubscribe(f),o.signal&&o.signal.removeEventListener("abort",f)}let x=new XMLHttpRequest;x.open(o.method.toUpperCase(),o.url,!0),x.timeout=o.timeout;function h(){if(!x)return;const g=Re.from("getAllResponseHeaders"in x&&x.getAllResponseHeaders()),C={data:!l||l==="text"||l==="json"?x.responseText:x.response,status:x.status,statusText:x.statusText,headers:g,config:e,request:x};Gh(function(b){n(b),v()},function(b){r(b),v()},C),x=null}"onloadend"in x?x.onloadend=h:x.onreadystatechange=function(){!x||x.readyState!==4||x.status===0&&!(x.responseURL&&x.responseURL.indexOf("file:")===0)||setTimeout(h)},x.onabort=function(){x&&(r(new A("Request aborted",A.ECONNABORTED,e,x)),x=null)},x.onerror=function(){r(new A("Network Error",A.ERR_NETWORK,e,x)),x=null},x.ontimeout=function(){let S=o.timeout?"timeout of "+o.timeout+"ms exceeded":"timeout exceeded";const C=o.transitional||Qh;o.timeoutErrorMessage&&(S=o.timeoutErrorMessage),r(new A(S,C.clarifyTimeoutError?A.ETIMEDOUT:A.ECONNABORTED,e,x)),x=null},i===void 0&&s.setContentType(null),"setRequestHeader"in x&&E.forEach(s.toJSON(),function(S,C){x.setRequestHeader(C,S)}),E.isUndefined(o.withCredentials)||(x.withCredentials=!!o.withCredentials),l&&l!=="json"&&(x.responseType=o.responseType),c&&([m,y]=Qi(c,!0),x.addEventListener("progress",m)),a&&x.upload&&([d,w]=Qi(a),x.upload.addEventListener("progress",d),x.upload.addEventListener("loadend",w)),(o.cancelToken||o.signal)&&(f=g=>{x&&(r(!g||g.type?new pr(null,e,x):g),x.abort(),x=null)},o.cancelToken&&o.cancelToken.subscribe(f),o.signal&&(o.signal.aborted?f():o.signal.addEventListener("abort",f)));const p=J1(o.url);if(p&&ge.protocols.indexOf(p)===-1){r(new A("Unsupported protocol "+p+":",A.ERR_BAD_REQUEST,e));return}x.send(i||null)})},lw=(e,t)=>{const{length:n}=e=e?e.filter(Boolean):[];if(t||n){let r=new AbortController,o;const i=function(c){if(!o){o=!0,l();const f=c instanceof Error?c:this.reason;r.abort(f instanceof A?f:new pr(f instanceof Error?f.message:f))}};let s=t&&setTimeout(()=>{s=null,i(new A(`timeout ${t} of ms exceeded`,A.ETIMEDOUT))},t);const l=()=>{e&&(s&&clearTimeout(s),s=null,e.forEach(c=>{c.unsubscribe?c.unsubscribe(i):c.removeEventListener("abort",i)}),e=null)};e.forEach(c=>c.addEventListener("abort",i));const{signal:a}=r;return a.unsubscribe=()=>E.asap(l),a}},aw=function*(e,t){let n=e.byteLength;if(n<t){yield e;return}let r=0,o;for(;r<n;)o=r+t,yield e.slice(r,o),r=o},uw=async function*(e,t){for await(const n of cw(e))yield*aw(n,t)},cw=async function*(e){if(e[Symbol.asyncIterator]){yield*e;return}const t=e.getReader();try{for(;;){const{done:n,value:r}=await t.read();if(n)break;yield r}}finally{await t.cancel()}},wd=(e,t,n,r)=>{const o=uw(e,t);let i=0,s,l=a=>{s||(s=!0,r&&r(a))};return new ReadableStream({async pull(a){try{const{done:c,value:f}=await o.next();if(c){l(),a.close();return}let d=f.byteLength;if(n){let m=i+=d;n(m)}a.enqueue(new Uint8Array(f))}catch(c){throw l(c),c}},cancel(a){return l(a),o.return()}},{highWaterMark:2})},ks=typeof fetch=="function"&&typeof Request=="function"&&typeof Response=="function",Jh=ks&&typeof ReadableStream=="function",dw=ks&&(typeof TextEncoder=="function"?(e=>t=>e.encode(t))(new TextEncoder):async e=>new Uint8Array(await new Response(e).arrayBuffer())),Zh=(e,...t)=>{try{return!!e(...t)}catch{return!1}},fw=Jh&&Zh(()=>{let e=!1;const t=new Request(ge.origin,{body:new ReadableStream,method:"POST",get duplex(){return e=!0,"half"}}).headers.has("Content-Type");return e&&!t}),xd=64*1024,ja=Jh&&Zh(()=>E.isReadableStream(new Response("").body)),Vi={stream:ja&&(e=>e.body)};ks&&(e=>{["text","arrayBuffer","blob","formData","stream"].forEach(t=>{!Vi[t]&&(Vi[t]=E.isFunction(e[t])?n=>n[t]():(n,r)=>{throw new A(`Response type '${t}' is not supported`,A.ERR_NOT_SUPPORT,r)})})})(new Response);const pw=async e=>{if(e==null)return 0;if(E.isBlob(e))return e.size;if(E.isSpecCompliantForm(e))return(await new Request(ge.origin,{method:"POST",body:e}).arrayBuffer()).byteLength;if(E.isArrayBufferView(e)||E.isArrayBuffer(e))return e.byteLength;if(E.isURLSearchParams(e)&&(e=e+""),E.isString(e))return(await dw(e)).byteLength},hw=async(e,t)=>{const n=E.toFiniteNumber(e.getContentLength());return n??pw(t)},mw=ks&&(async e=>{let{url:t,method:n,data:r,signal:o,cancelToken:i,timeout:s,onDownloadProgress:l,onUploadProgress:a,responseType:c,headers:f,withCredentials:d="same-origin",fetchOptions:m}=Xh(e);c=c?(c+"").toLowerCase():"text";let w=lw([o,i&&i.toAbortSignal()],s),y;const v=w&&w.unsubscribe&&(()=>{w.unsubscribe()});let x;try{if(a&&fw&&n!=="get"&&n!=="head"&&(x=await hw(f,r))!==0){let C=new Request(t,{method:"POST",body:r,duplex:"half"}),j;if(E.isFormData(r)&&(j=C.headers.get("content-type"))&&f.setContentType(j),C.body){const[b,_]=gd(x,Qi(yd(a)));r=wd(C.body,xd,b,_)}}E.isString(d)||(d=d?"include":"omit");const h="credentials"in Request.prototype;y=new Request(t,{...m,signal:w,method:n.toUpperCase(),headers:f.normalize().toJSON(),body:r,duplex:"half",credentials:h?d:void 0});let p=await fetch(y);const g=ja&&(c==="stream"||c==="response");if(ja&&(l||g&&v)){const C={};["status","statusText","headers"].forEach(M=>{C[M]=p[M]});const j=E.toFiniteNumber(p.headers.get("content-length")),[b,_]=l&&gd(j,Qi(yd(l),!0))||[];p=new Response(wd(p.body,xd,b,()=>{_&&_(),v&&v()}),C)}c=c||"text";let S=await Vi[E.findKey(Vi,c)||"text"](p,e);return!g&&v&&v(),await new Promise((C,j)=>{Gh(C,j,{data:S,headers:Re.from(p.headers),status:p.status,statusText:p.statusText,config:e,request:y})})}catch(h){throw v&&v(),h&&h.name==="TypeError"&&/Load failed|fetch/i.test(h.message)?Object.assign(new A("Network Error",A.ERR_NETWORK,e,y),{cause:h.cause||h}):A.from(h,h&&h.code,e,y)}}),Pa={http:$1,xhr:sw,fetch:mw};E.forEach(Pa,(e,t)=>{if(e){try{Object.defineProperty(e,"name",{value:t})}catch{}Object.defineProperty(e,"adapterName",{value:t})}});const Sd=e=>`- ${e}`,gw=e=>E.isFunction(e)||e===null||e===!1,em={getAdapter:e=>{e=E.isArray(e)?e:[e];const{length:t}=e;let n,r;const o={};for(let i=0;i<t;i++){n=e[i];let s;if(r=n,!gw(n)&&(r=Pa[(s=String(n)).toLowerCase()],r===void 0))throw new A(`Unknown adapter '${s}'`);if(r)break;o[s||"#"+i]=r}if(!r){const i=Object.entries(o).map(([l,a])=>`adapter ${l} `+(a===!1?"is not supported by the environment":"is not available in the build"));let s=t?i.length>1?`since :
`+i.map(Sd).join(`
`):" "+Sd(i[0]):"as no adapter specified";throw new A("There is no suitable adapter to dispatch the request "+s,"ERR_NOT_SUPPORT")}return r},adapters:Pa};function il(e){if(e.cancelToken&&e.cancelToken.throwIfRequested(),e.signal&&e.signal.aborted)throw new pr(null,e)}function kd(e){return il(e),e.headers=Re.from(e.headers),e.data=ol.call(e,e.transformRequest),["post","put","patch"].indexOf(e.method)!==-1&&e.headers.setContentType("application/x-www-form-urlencoded",!1),em.getAdapter(e.adapter||So.adapter)(e).then(function(r){return il(e),r.data=ol.call(e,e.transformResponse,r),r.headers=Re.from(r.headers),r},function(r){return Kh(r)||(il(e),r&&r.response&&(r.response.data=ol.call(e,e.transformResponse,r.response),r.response.headers=Re.from(r.response.headers))),Promise.reject(r)})}const tm="1.9.0",Es={};["object","boolean","number","function","string","symbol"].forEach((e,t)=>{Es[e]=function(r){return typeof r===e||"a"+(t<1?"n ":" ")+e}});const Ed={};Es.transitional=function(t,n,r){function o(i,s){return"[Axios v"+tm+"] Transitional option '"+i+"'"+s+(r?". "+r:"")}return(i,s,l)=>{if(t===!1)throw new A(o(s," has been removed"+(n?" in "+n:"")),A.ERR_DEPRECATED);return n&&!Ed[s]&&(Ed[s]=!0,console.warn(o(s," has been deprecated since v"+n+" and will be removed in the near future"))),t?t(i,s,l):!0}};Es.spelling=function(t){return(n,r)=>(console.warn(`${r} is likely a misspelling of ${t}`),!0)};function yw(e,t,n){if(typeof e!="object")throw new A("options must be an object",A.ERR_BAD_OPTION_VALUE);const r=Object.keys(e);let o=r.length;for(;o-- >0;){const i=r[o],s=t[i];if(s){const l=e[i],a=l===void 0||s(l,i,e);if(a!==!0)throw new A("option "+i+" must be "+a,A.ERR_BAD_OPTION_VALUE);continue}if(n!==!0)throw new A("Unknown option "+i,A.ERR_BAD_OPTION)}}const gi={assertOptions:yw,validators:Es},rt=gi.validators;let mn=class{constructor(t){this.defaults=t||{},this.interceptors={request:new hd,response:new hd}}async request(t,n){try{return await this._request(t,n)}catch(r){if(r instanceof Error){let o={};Error.captureStackTrace?Error.captureStackTrace(o):o=new Error;const i=o.stack?o.stack.replace(/^.+\n/,""):"";try{r.stack?i&&!String(r.stack).endsWith(i.replace(/^.+\n.+\n/,""))&&(r.stack+=`
`+i):r.stack=i}catch{}}throw r}}_request(t,n){typeof t=="string"?(n=n||{},n.url=t):n=t||{},n=En(this.defaults,n);const{transitional:r,paramsSerializer:o,headers:i}=n;r!==void 0&&gi.assertOptions(r,{silentJSONParsing:rt.transitional(rt.boolean),forcedJSONParsing:rt.transitional(rt.boolean),clarifyTimeoutError:rt.transitional(rt.boolean)},!1),o!=null&&(E.isFunction(o)?n.paramsSerializer={serialize:o}:gi.assertOptions(o,{encode:rt.function,serialize:rt.function},!0)),n.allowAbsoluteUrls!==void 0||(this.defaults.allowAbsoluteUrls!==void 0?n.allowAbsoluteUrls=this.defaults.allowAbsoluteUrls:n.allowAbsoluteUrls=!0),gi.assertOptions(n,{baseUrl:rt.spelling("baseURL"),withXsrfToken:rt.spelling("withXSRFToken")},!0),n.method=(n.method||this.defaults.method||"get").toLowerCase();let s=i&&E.merge(i.common,i[n.method]);i&&E.forEach(["delete","get","head","post","put","patch","common"],y=>{delete i[y]}),n.headers=Re.concat(s,i);const l=[];let a=!0;this.interceptors.request.forEach(function(v){typeof v.runWhen=="function"&&v.runWhen(n)===!1||(a=a&&v.synchronous,l.unshift(v.fulfilled,v.rejected))});const c=[];this.interceptors.response.forEach(function(v){c.push(v.fulfilled,v.rejected)});let f,d=0,m;if(!a){const y=[kd.bind(this),void 0];for(y.unshift.apply(y,l),y.push.apply(y,c),m=y.length,f=Promise.resolve(n);d<m;)f=f.then(y[d++],y[d++]);return f}m=l.length;let w=n;for(d=0;d<m;){const y=l[d++],v=l[d++];try{w=y(w)}catch(x){v.call(this,x);break}}try{f=kd.call(this,w)}catch(y){return Promise.reject(y)}for(d=0,m=c.length;d<m;)f=f.then(c[d++],c[d++]);return f}getUri(t){t=En(this.defaults,t);const n=Yh(t.baseURL,t.url,t.allowAbsoluteUrls);return qh(n,t.params,t.paramsSerializer)}};E.forEach(["delete","get","head","options"],function(t){mn.prototype[t]=function(n,r){return this.request(En(r||{},{method:t,url:n,data:(r||{}).data}))}});E.forEach(["post","put","patch"],function(t){function n(r){return function(i,s,l){return this.request(En(l||{},{method:t,headers:r?{"Content-Type":"multipart/form-data"}:{},url:i,data:s}))}}mn.prototype[t]=n(),mn.prototype[t+"Form"]=n(!0)});let vw=class nm{constructor(t){if(typeof t!="function")throw new TypeError("executor must be a function.");let n;this.promise=new Promise(function(i){n=i});const r=this;this.promise.then(o=>{if(!r._listeners)return;let i=r._listeners.length;for(;i-- >0;)r._listeners[i](o);r._listeners=null}),this.promise.then=o=>{let i;const s=new Promise(l=>{r.subscribe(l),i=l}).then(o);return s.cancel=function(){r.unsubscribe(i)},s},t(function(i,s,l){r.reason||(r.reason=new pr(i,s,l),n(r.reason))})}throwIfRequested(){if(this.reason)throw this.reason}subscribe(t){if(this.reason){t(this.reason);return}this._listeners?this._listeners.push(t):this._listeners=[t]}unsubscribe(t){if(!this._listeners)return;const n=this._listeners.indexOf(t);n!==-1&&this._listeners.splice(n,1)}toAbortSignal(){const t=new AbortController,n=r=>{t.abort(r)};return this.subscribe(n),t.signal.unsubscribe=()=>this.unsubscribe(n),t.signal}static source(){let t;return{token:new nm(function(o){t=o}),cancel:t}}};function ww(e){return function(n){return e.apply(null,n)}}function xw(e){return E.isObject(e)&&e.isAxiosError===!0}const ba={Continue:100,SwitchingProtocols:101,Processing:102,EarlyHints:103,Ok:200,Created:201,Accepted:202,NonAuthoritativeInformation:203,NoContent:204,ResetContent:205,PartialContent:206,MultiStatus:207,AlreadyReported:208,ImUsed:226,MultipleChoices:300,MovedPermanently:301,Found:302,SeeOther:303,NotModified:304,UseProxy:305,Unused:306,TemporaryRedirect:307,PermanentRedirect:308,BadRequest:400,Unauthorized:401,PaymentRequired:402,Forbidden:403,NotFound:404,MethodNotAllowed:405,NotAcceptable:406,ProxyAuthenticationRequired:407,RequestTimeout:408,Conflict:409,Gone:410,LengthRequired:411,PreconditionFailed:412,PayloadTooLarge:413,UriTooLong:414,UnsupportedMediaType:415,RangeNotSatisfiable:416,ExpectationFailed:417,ImATeapot:418,MisdirectedRequest:421,UnprocessableEntity:422,Locked:423,FailedDependency:424,TooEarly:425,UpgradeRequired:426,PreconditionRequired:428,TooManyRequests:429,RequestHeaderFieldsTooLarge:431,UnavailableForLegalReasons:451,InternalServerError:500,NotImplemented:501,BadGateway:502,ServiceUnavailable:503,GatewayTimeout:504,HttpVersionNotSupported:505,VariantAlsoNegotiates:506,InsufficientStorage:507,LoopDetected:508,NotExtended:510,NetworkAuthenticationRequired:511};Object.entries(ba).forEach(([e,t])=>{ba[t]=e});function rm(e){const t=new mn(e),n=Oh(mn.prototype.request,t);return E.extend(n,mn.prototype,t,{allOwnKeys:!0}),E.extend(n,t,null,{allOwnKeys:!0}),n.create=function(o){return rm(En(e,o))},n}const W=rm(So);W.Axios=mn;W.CanceledError=pr;W.CancelToken=vw;W.isCancel=Kh;W.VERSION=tm;W.toFormData=Ss;W.AxiosError=A;W.Cancel=W.CanceledError;W.all=function(t){return Promise.all(t)};W.spread=ww;W.isAxiosError=xw;W.mergeConfig=En;W.AxiosHeaders=Re;W.formToJSON=e=>Vh(E.isHTMLForm(e)?new FormData(e):e);W.getAdapter=em.getAdapter;W.HttpStatusCode=ba;W.default=W;const{Axios:tk,AxiosError:nk,CanceledError:rk,isCancel:ok,CancelToken:ik,VERSION:sk,all:lk,Cancel:ak,isAxiosError:uk,spread:ck,toFormData:dk,AxiosHeaders:fk,HttpStatusCode:pk,formToJSON:hk,getAdapter:mk,mergeConfig:gk}=W,Kn="https://t2ykh1mw5l.execute-api.us-east-1.amazonaws.com/prod";console.log("Using API URL:",Kn);const dn=e=>{const t=e.startsWith("/")?e:`/${e}`;return`${Kn.endsWith("/")?Kn.slice(0,-1):Kn}${t}`},om=P.createContext();console.log("Using API URL:",Kn);const Ct=()=>P.useContext(om),Sw=({children:e})=>{const[t,n]=P.useState(null),[r,o]=P.useState(localStorage.getItem("token")),[i,s]=P.useState(!0),[l,a]=P.useState(null);P.useEffect(()=>{r?c():s(!1)},[r]);const c=async()=>{try{s(!0);const y=await W.get(dn("/api/auth/me"),{headers:{Authorization:`Bearer ${r}`}});n(y.data),a(null)}catch(y){console.error("Error fetching user profile:",y),a("Failed to authenticate user"),m()}finally{s(!1)}},f=async(y,v)=>{var x,h;try{s(!0);const p=await W.post(dn("/api/auth/login"),{email:y,password:v}),{token:g,user:S}=p.data;return localStorage.setItem("token",g),o(g),n(S),a(null),S}catch(p){throw console.error("Login error:",p),a(((h=(x=p.response)==null?void 0:x.data)==null?void 0:h.error)||"Failed to login"),p}finally{s(!1)}},d=async y=>{var v,x;try{return s(!0),await W.post(dn("/api/auth/register"),y),a(null),await f(y.email,y.password)}catch(h){throw console.error("Registration error:",h),a(((x=(v=h.response)==null?void 0:v.data)==null?void 0:x.error)||"Failed to register"),h}finally{s(!1)}},m=()=>{localStorage.removeItem("token"),o(null),n(null)},w={currentUser:t,token:r,loading:i,error:l,login:f,register:d,logout:m,isAuthenticated:!!t};return u.jsx(om.Provider,{value:w,children:e})},im=P.createContext();console.log("Using API URL in SubscriptionContext:",Kn);const Au=()=>P.useContext(im),kw=({children:e})=>{const{token:t,isAuthenticated:n}=Ct(),[r,o]=P.useState([]),[i,s]=P.useState(null),[l,a]=P.useState(!1),[c,f]=P.useState(null);P.useEffect(()=>{d(),n&&t&&m()},[n,t]);const d=async()=>{try{a(!0);const x=await W.get(dn("/api/subscription/plans"));o(x.data),f(null)}catch(x){console.error("Error fetching subscription plans:",x),f("Failed to load subscription plans")}finally{a(!1)}},m=async()=>{if(t)try{a(!0);const x=await W.get(dn("/api/subscription/user"),{headers:{Authorization:`Bearer ${t}`}});s(x.data),f(null)}catch(x){console.error("Error fetching user subscription:",x),f("Failed to load subscription information")}finally{a(!1)}},v={subscriptionPlans:r,userSubscription:i,loading:l,error:c,createSubscription:async(x,h)=>{var p,g;if(t)try{a(!0);const S=await W.post(dn("/api/subscription/create"),{plan_id:x,cycle:h},{headers:{Authorization:`Bearer ${t}`}});return await m(),S.data}catch(S){throw console.error("Error creating subscription:",S),f(((g=(p=S.response)==null?void 0:p.data)==null?void 0:g.error)||"Failed to create subscription"),S}finally{a(!1)}},cancelSubscription:async()=>{var x,h;if(!(!t||!i))try{a(!0),await W.post(dn("/api/subscription/cancel"),{},{headers:{Authorization:`Bearer ${t}`}}),await m()}catch(p){throw console.error("Error cancelling subscription:",p),f(((h=(x=p.response)==null?void 0:x.data)==null?void 0:h.error)||"Failed to cancel subscription"),p}finally{a(!1)}},refreshSubscription:m,hasActiveSubscription:!!i&&i.status==="active"};return u.jsx(im.Provider,{value:v,children:e})},Ew=k.section`
  background: linear-gradient(135deg, ${e=>e.theme.colors.primary} 0%, ${e=>e.theme.colors.secondary} 100%);
  color: white;
  padding: 5rem 1rem;
  text-align: center;
`,Cw=k.div`
  max-width: 800px;
  margin: 0 auto;
  
  h1 {
    font-size: 3rem;
    margin-bottom: 1.5rem;
    color: white;
    
    @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
      font-size: 2.5rem;
    }
  }
  
  p {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    opacity: 0.9;
    
    @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
      font-size: 1.1rem;
    }
  }
`,jw=k(ct)`
  display: inline-block;
  background-color: white;
  color: ${e=>e.theme.colors.primary};
  padding: 1rem 2rem;
  border-radius: 4px;
  font-weight: 600;
  font-size: 1.1rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
  }
`,Pw=k.section`
  padding: 5rem 1rem;
  background-color: white;
`,sl=k.h2`
  text-align: center;
  font-size: 2.5rem;
  margin-bottom: 3rem;
  color: ${e=>e.theme.colors.primary};
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    font-size: 2rem;
  }
`,bw=k.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,Ho=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
  }
`,Wo=k.div`
  font-size: 3rem;
  margin-bottom: 1.5rem;
  color: ${e=>e.theme.colors.primary};
`,qo=k.h3`
  font-size: 1.5rem;
  margin-bottom: 1rem;
  color: ${e=>e.theme.colors.primary};
`,Tw=k.section`
  padding: 5rem 1rem;
  background-color: ${e=>e.theme.colors.backgroundDark};
`,Rw=k.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,Cd=k.div`
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: ${e=>e.theme.shadows.medium};
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
  }
  
  ${e=>e.featured&&`
    border: 2px solid ${e.theme.colors.primary};
    transform: scale(1.05);
    
    &:hover {
      transform: scale(1.05) translateY(-5px);
    }
  `}
`,jd=k.div`
  background-color: ${e=>e.featured?e.theme.colors.primary:e.theme.colors.backgroundDark};
  padding: 2rem;
  text-align: center;
  
  h3 {
    font-size: 1.8rem;
    margin-bottom: 0.5rem;
    color: ${e=>e.featured?"white":e.theme.colors.primary};
  }
`,Pd=k.div`
  font-size: 2.5rem;
  font-weight: 700;
  color: ${e=>e.featured?"white":e.theme.colors.primary};
  
  span {
    font-size: 1rem;
    font-weight: 400;
    opacity: 0.8;
  }
`,bd=k.div`
  padding: 2rem;
  
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
    
    li {
      padding: 0.75rem 0;
      border-bottom: 1px solid ${e=>e.theme.colors.border};
      
      &:before {
        content: "✓";
        color: ${e=>e.theme.colors.success};
        margin-right: 0.5rem;
      }
      
      &:last-child {
        border-bottom: none;
      }
    }
  }
`,Td=k(ct)`
  display: block;
  background-color: ${e=>e.featured?e.theme.colors.primary:"white"};
  color: ${e=>e.featured?"white":e.theme.colors.primary};
  text-align: center;
  padding: 1rem;
  font-weight: 600;
  border-top: 1px solid ${e=>e.theme.colors.border};
  transition: all 0.3s ease;
  
  ${e=>!e.featured&&`
    border: 2px solid ${e.theme.colors.primary};
    margin: 0 2rem 2rem;
    border-radius: 4px;
  `}
  
  &:hover {
    background-color: ${e=>e.featured?e.theme.colors.primaryDark:e.theme.colors.primary};
    color: white;
  }
`,$w=k.section`
  padding: 5rem 1rem;
  background-color: white;
`,_w=k.div`
  max-width: 1200px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
`,ll=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  
  p {
    font-style: italic;
    margin-bottom: 1.5rem;
    position: relative;
    
    &:before {
      content: '"';
      font-size: 4rem;
      position: absolute;
      top: -2rem;
      left: -1rem;
      opacity: 0.1;
      color: ${e=>e.theme.colors.primary};
    }
  }
`,al=k.p`
  font-weight: 600;
  color: ${e=>e.theme.colors.primary};
`,Nw=()=>{const{subscriptionPlans:e,loading:t}=Au();return u.jsxs(u.Fragment,{children:[u.jsx(Ew,{children:u.jsxs(Cw,{children:[u.jsx("h1",{children:"Master Psychiatry Questions"}),u.jsx("p",{children:"The ultimate platform for psychiatry residents preparing for PRITE and board exams. Gain access to proven strategies, practice questions, and personalized feedback."}),u.jsx(jw,{to:"/register",children:"Get Started Today"})]})}),u.jsxs(Pw,{children:[u.jsx(sl,{children:"Why Choose CortexQ?"}),u.jsxs(bw,{children:[u.jsxs(Ho,{children:[u.jsx(Wo,{children:"📊"}),u.jsx(qo,{children:"Comprehensive Question Bank"}),u.jsx("p",{children:"Access hundreds of psychiatry board-style questions covering all major topics and question formats."})]}),u.jsxs(Ho,{children:[u.jsx(Wo,{children:"🧠"}),u.jsx(qo,{children:"Strategic Approach"}),u.jsx("p",{children:"Learn proven strategies to tackle even the most challenging question types and examiner tricks."})]}),u.jsxs(Ho,{children:[u.jsx(Wo,{children:"📈"}),u.jsx(qo,{children:"Performance Tracking"}),u.jsx("p",{children:"Monitor your progress with detailed analytics and identify areas for improvement."})]}),u.jsxs(Ho,{children:[u.jsx(Wo,{children:"🔍"}),u.jsx(qo,{children:"Detailed Explanations"}),u.jsx("p",{children:"Understand the reasoning behind each answer with comprehensive explanations and references."})]})]})]}),u.jsxs(Tw,{children:[u.jsx(sl,{children:"Subscription Plans"}),u.jsx(Rw,{children:t?u.jsx("p",{children:"Loading subscription plans..."}):u.jsxs(u.Fragment,{children:[u.jsxs(Cd,{children:[u.jsxs(jd,{children:[u.jsx("h3",{children:"Monthly Plan"}),u.jsxs(Pd,{children:["$9.99",u.jsx("span",{children:"/month"})]})]}),u.jsx(bd,{children:u.jsxs("ul",{children:[u.jsx("li",{children:"Access to all practice questions"}),u.jsx("li",{children:"Basic strategy guides"}),u.jsx("li",{children:"Performance tracking"}),u.jsx("li",{children:"7-day free trial"})]})}),u.jsx(Td,{to:"/subscription",children:"Subscribe Now"})]}),u.jsxs(Cd,{featured:!0,children:[u.jsxs(jd,{featured:!0,children:[u.jsx("h3",{children:"Annual Plan"}),u.jsxs(Pd,{featured:!0,children:["$99.99",u.jsx("span",{children:"/year"})]})]}),u.jsx(bd,{children:u.jsxs("ul",{children:[u.jsx("li",{children:"Access to all practice questions"}),u.jsx("li",{children:"Advanced strategy guides"}),u.jsx("li",{children:"Detailed performance analytics"}),u.jsx("li",{children:"Personalized study recommendations"}),u.jsx("li",{children:"Unlimited practice sessions"}),u.jsx("li",{children:"14-day free trial"}),u.jsx("li",{children:"Save 16% compared to monthly"})]})}),u.jsx(Td,{to:"/subscription",featured:!0,children:"Subscribe Now"})]})]})})]}),u.jsxs($w,{children:[u.jsx(sl,{children:"What Our Users Say"}),u.jsxs(_w,{children:[u.jsxs(ll,{children:[u.jsx("p",{children:"CortexQ helped me identify my weak areas and focus my study time efficiently. I passed my boards with flying colors!"}),u.jsx(al,{children:"- Dr. Sarah J., PGY-4"})]}),u.jsxs(ll,{children:[u.jsx("p",{children:"The question strategies taught me how to approach even the most difficult questions. Highly recommended for all psychiatry residents."}),u.jsx(al,{children:"- Dr. Michael T., PGY-3"})]}),u.jsxs(ll,{children:[u.jsx("p",{children:"The annual subscription has been invaluable throughout my residency. The strategies and practice questions are exactly what I needed."}),u.jsx(al,{children:"- Dr. Lisa R., PGY-2"})]})]})]})]})},Ow=k.div`
  max-width: 500px;
  margin: 4rem auto;
  padding: 2rem;
  background-color: white;
  border-radius: 8px;
  box-shadow: ${e=>e.theme.shadows.medium};
`,Aw=k.div`
  text-align: center;
  margin-bottom: 2rem;
  
  h1 {
    font-size: 2rem;
    color: ${e=>e.theme.colors.primary};
  }
  
  p {
    color: ${e=>e.theme.colors.textLight};
  }
`,Lw=k.form`
  display: flex;
  flex-direction: column;
`,Rd=k.div`
  margin-bottom: 1.5rem;
  
  label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
  }
  
  input {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid ${e=>e.theme.colors.border};
    border-radius: 4px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: ${e=>e.theme.colors.primary};
    }
  }
`,zw=k.button`
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.75rem;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
  }
  
  &:disabled {
    background-color: ${e=>e.theme.colors.textLight};
    cursor: not-allowed;
  }
`,Dw=k.div`
  color: ${e=>e.theme.colors.error};
  background-color: rgba(217, 4, 41, 0.1);
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
`,Iw=k.div`
  text-align: center;
  margin-top: 1.5rem;
  font-size: 0.9rem;
  
  a {
    color: ${e=>e.theme.colors.primary};
    font-weight: 600;
    
    &:hover {
      text-decoration: underline;
    }
  }
`,Fw=()=>{const[e,t]=P.useState(""),[n,r]=P.useState(""),[o,i]=P.useState(""),[s,l]=P.useState(!1),{login:a}=Ct(),c=wo(),f=async d=>{var m,w;if(d.preventDefault(),!e||!n){i("Please enter both email and password");return}try{i(""),l(!0),await a(e,n),c("/dashboard")}catch(y){i(((w=(m=y.response)==null?void 0:m.data)==null?void 0:w.error)||"Failed to login. Please check your credentials.")}finally{l(!1)}};return u.jsxs(Ow,{children:[u.jsxs(Aw,{children:[u.jsx("h1",{children:"Welcome Back"}),u.jsx("p",{children:"Sign in to access your CortexQ account"})]}),o&&u.jsx(Dw,{children:o}),u.jsxs(Lw,{onSubmit:f,children:[u.jsxs(Rd,{children:[u.jsx("label",{htmlFor:"email",children:"Email"}),u.jsx("input",{type:"email",id:"email",value:e,onChange:d=>t(d.target.value),required:!0})]}),u.jsxs(Rd,{children:[u.jsx("label",{htmlFor:"password",children:"Password"}),u.jsx("input",{type:"password",id:"password",value:n,onChange:d=>r(d.target.value),required:!0})]}),u.jsx(zw,{type:"submit",disabled:s,children:s?"Signing in...":"Sign In"})]}),u.jsxs(Iw,{children:["Don't have an account? ",u.jsx(ct,{to:"/register",children:"Sign up"})]})]})},Mw=k.div`
  max-width: 500px;
  margin: 4rem auto;
  padding: 2rem;
  background-color: white;
  border-radius: 8px;
  box-shadow: ${e=>e.theme.shadows.medium};
`,Bw=k.div`
  text-align: center;
  margin-bottom: 2rem;
  
  h1 {
    font-size: 2rem;
    color: ${e=>e.theme.colors.primary};
  }
  
  p {
    color: ${e=>e.theme.colors.textLight};
  }
`,Uw=k.form`
  display: flex;
  flex-direction: column;
`,jr=k.div`
  margin-bottom: 1.5rem;
  
  label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
  }
  
  input {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid ${e=>e.theme.colors.border};
    border-radius: 4px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: ${e=>e.theme.colors.primary};
    }
  }
`,Hw=k.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.mobile}) {
    grid-template-columns: 1fr;
  }
`,Ww=k.button`
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.75rem;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
  }
  
  &:disabled {
    background-color: ${e=>e.theme.colors.textLight};
    cursor: not-allowed;
  }
`,qw=k.div`
  color: ${e=>e.theme.colors.error};
  background-color: rgba(217, 4, 41, 0.1);
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
`,Qw=k.div`
  text-align: center;
  margin-top: 1.5rem;
  font-size: 0.9rem;
  
  a {
    color: ${e=>e.theme.colors.primary};
    font-weight: 600;
    
    &:hover {
      text-decoration: underline;
    }
  }
`,Vw=()=>{const[e,t]=P.useState(""),[n,r]=P.useState(""),[o,i]=P.useState(""),[s,l]=P.useState(""),[a,c]=P.useState(""),[f,d]=P.useState(""),[m,w]=P.useState(!1),{register:y}=Ct(),v=wo(),x=async h=>{var p,g;if(h.preventDefault(),!e||!n||!o||!s||!a){d("Please fill in all fields");return}if(s!==a){d("Passwords do not match");return}if(s.length<8){d("Password must be at least 8 characters long");return}try{d(""),w(!0),await y({first_name:e,last_name:n,email:o,password:s}),v("/dashboard")}catch(S){d(((g=(p=S.response)==null?void 0:p.data)==null?void 0:g.error)||"Failed to create account. Please try again.")}finally{w(!1)}};return u.jsxs(Mw,{children:[u.jsxs(Bw,{children:[u.jsx("h1",{children:"Create Account"}),u.jsx("p",{children:"Join CortexQ and start mastering psychiatry questions"})]}),f&&u.jsx(qw,{children:f}),u.jsxs(Uw,{onSubmit:x,children:[u.jsxs(Hw,{children:[u.jsxs(jr,{children:[u.jsx("label",{htmlFor:"firstName",children:"First Name"}),u.jsx("input",{type:"text",id:"firstName",value:e,onChange:h=>t(h.target.value),required:!0})]}),u.jsxs(jr,{children:[u.jsx("label",{htmlFor:"lastName",children:"Last Name"}),u.jsx("input",{type:"text",id:"lastName",value:n,onChange:h=>r(h.target.value),required:!0})]})]}),u.jsxs(jr,{children:[u.jsx("label",{htmlFor:"email",children:"Email"}),u.jsx("input",{type:"email",id:"email",value:o,onChange:h=>i(h.target.value),required:!0})]}),u.jsxs(jr,{children:[u.jsx("label",{htmlFor:"password",children:"Password"}),u.jsx("input",{type:"password",id:"password",value:s,onChange:h=>l(h.target.value),required:!0,minLength:"8"})]}),u.jsxs(jr,{children:[u.jsx("label",{htmlFor:"confirmPassword",children:"Confirm Password"}),u.jsx("input",{type:"password",id:"confirmPassword",value:a,onChange:h=>c(h.target.value),required:!0})]}),u.jsx(Ww,{type:"submit",disabled:m,children:m?"Creating Account...":"Create Account"})]}),u.jsxs(Qw,{children:["Already have an account? ",u.jsx(ct,{to:"/login",children:"Sign in"})]})]})},Kw=k.div`
  max-width: 1200px;
  margin: 3rem auto;
  padding: 0 1rem;
`,Gw=k.section`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
`,Yw=k.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.mobile}) {
    flex-direction: column;
    align-items: flex-start;
  }
`,Xw=k.h1`
  font-size: 2rem;
  color: ${e=>e.theme.colors.primary};
  margin: 0;
`,Jw=k.p`
  color: ${e=>e.theme.colors.textLight};
  font-size: 0.9rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.mobile}) {
    margin-top: 0.5rem;
  }
`,Zw=k.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
`,ul=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
  }
`,cl=k.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
`,dl=k.h2`
  font-size: 1.5rem;
  color: ${e=>e.theme.colors.primary};
  margin: 0;
`,fl=k.div`
  font-size: 2rem;
  color: ${e=>e.theme.colors.primary};
`,ex=k.div`
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
  padding: 0.75rem;
  border-radius: 4px;
  background-color: ${e=>e.status==="active"?"rgba(56, 176, 0, 0.1)":e.status==="inactive"?"rgba(217, 4, 41, 0.1)":"rgba(255, 190, 11, 0.1)"};
  
  span {
    font-weight: 600;
    margin-left: 0.5rem;
    color: ${e=>e.status==="active"?e.theme.colors.success:e.status==="inactive"?e.theme.colors.error:e.theme.colors.warning};
  }
`,tx=k.div`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background-color: ${e=>e.status==="active"?e.theme.colors.success:e.status==="inactive"?e.theme.colors.error:e.theme.colors.warning};
`,nx=k.div`
  margin-bottom: 1.5rem;
  
  p {
    margin: 0.5rem 0;
    display: flex;
    justify-content: space-between;
    
    span:first-child {
      color: ${e=>e.theme.colors.textLight};
    }
    
    span:last-child {
      font-weight: 600;
    }
  }
`,pl=k(ct)`
  display: inline-block;
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  font-weight: 600;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
    color: white;
  }
`,rx=k.div`
  margin-top: 1rem;
`,$d=k.h3`
  font-size: 1.2rem;
  margin-bottom: 1rem;
  color: ${e=>e.theme.colors.primary};
`,ox=k.div`
  height: 8px;
  background-color: ${e=>e.theme.colors.backgroundDark};
  border-radius: 4px;
  margin-bottom: 0.5rem;
  overflow: hidden;
  
  div {
    height: 100%;
    background-color: ${e=>e.theme.colors.primary};
    width: ${e=>e.progress}%;
    transition: width 0.5s ease;
  }
`,ix=k.div`
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  
  span:last-child {
    font-weight: 600;
  }
`,sx=k.div`
  margin-top: 1rem;
`,lx=k.ul`
  list-style: none;
  padding: 0;
  margin: 0;
  
  li {
    padding: 0.75rem 0;
    border-bottom: 1px solid ${e=>e.theme.colors.border};
    display: flex;
    justify-content: space-between;
    
    &:last-child {
      border-bottom: none;
    }
    
    span:first-child {
      color: ${e=>e.theme.colors.text};
    }
    
    span:last-child {
      color: ${e=>e.theme.colors.textLight};
      font-size: 0.9rem;
    }
  }
`,hl=e=>{const t={year:"numeric",month:"long",day:"numeric"};return new Date(e).toLocaleDateString(void 0,t)},ax=()=>{const{currentUser:e}=Ct(),{userSubscription:t,hasActiveSubscription:n}=Au(),r={questionsCompleted:120,totalQuestions:200,progress:60},o=[{action:"Completed practice session",date:"2025-05-23T14:30:00Z"},{action:"Reviewed strategy guide",date:"2025-05-22T10:15:00Z"},{action:"Updated subscription",date:"2025-05-20T09:45:00Z"}];return u.jsxs(Kw,{children:[u.jsxs(Gw,{children:[u.jsxs(Yw,{children:[u.jsxs(Xw,{children:["Welcome back, ",(e==null?void 0:e.first_name)||"User","!"]}),u.jsxs(Jw,{children:["Last login: ",hl(new Date().toISOString())]})]}),u.jsx("p",{children:"Track your progress, manage your subscription, and continue your PRITE exam preparation."})]}),u.jsxs(Zw,{children:[u.jsxs(ul,{children:[u.jsxs(cl,{children:[u.jsx(dl,{children:"Subscription"}),u.jsx(fl,{children:"💳"})]}),u.jsxs(ex,{status:n?"active":"inactive",children:[u.jsx(tx,{status:n?"active":"inactive"}),u.jsx("span",{children:n?"Active":"Inactive"})]}),t&&u.jsxs(nx,{children:[u.jsxs("p",{children:[u.jsx("span",{children:"Plan:"}),u.jsx("span",{children:t.plan_name||"Premium"})]}),u.jsxs("p",{children:[u.jsx("span",{children:"Billing Cycle:"}),u.jsx("span",{children:t.cycle||"Monthly"})]}),u.jsxs("p",{children:[u.jsx("span",{children:"Next Billing:"}),u.jsx("span",{children:t.next_billing_date?hl(t.next_billing_date):"N/A"})]})]}),u.jsx(pl,{to:"/subscription",children:n?"Manage Subscription":"Subscribe Now"})]}),u.jsxs(ul,{children:[u.jsxs(cl,{children:[u.jsx(dl,{children:"Progress"}),u.jsx(fl,{children:"📊"})]}),u.jsxs(rx,{children:[u.jsx($d,{children:"Practice Questions"}),u.jsx(ox,{progress:r.progress,children:u.jsx("div",{})}),u.jsxs(ix,{children:[u.jsx("span",{children:"Completed"}),u.jsxs("span",{children:[r.questionsCompleted," / ",r.totalQuestions]})]})]}),u.jsxs(sx,{children:[u.jsx($d,{children:"Recent Activity"}),u.jsx(lx,{children:o.map((i,s)=>u.jsxs("li",{children:[u.jsx("span",{children:i.action}),u.jsx("span",{children:hl(i.date)})]},s))})]}),u.jsx(pl,{to:"/practice",style:{marginTop:"1.5rem"},children:"Continue Practice"})]}),u.jsxs(ul,{children:[u.jsxs(cl,{children:[u.jsx(dl,{children:"Strategies"}),u.jsx(fl,{children:"🧠"})]}),u.jsx("p",{children:"Access our comprehensive PRITE exam strategies to improve your performance."}),u.jsxs("ul",{style:{marginBottom:"1.5rem"},children:[u.jsx("li",{children:"Question analysis techniques"}),u.jsx("li",{children:"Time management strategies"}),u.jsx("li",{children:"Common pitfall avoidance"}),u.jsx("li",{children:"High-yield content review"})]}),u.jsx(pl,{to:"/strategies",children:"View Strategies"})]})]})]})};var ux="basil",sm="https://js.stripe.com",cx="".concat(sm,"/").concat(ux,"/stripe.js"),dx=/^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,fx=/^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/;var px=function(t){return dx.test(t)||fx.test(t)},hx=function(){for(var t=document.querySelectorAll('script[src^="'.concat(sm,'"]')),n=0;n<t.length;n++){var r=t[n];if(px(r.src))return r}return null},_d=function(t){var n="",r=document.createElement("script");r.src="".concat(cx).concat(n);var o=document.head||document.body;if(!o)throw new Error("Expected document.body not to be null. Stripe.js requires a <body> element.");return o.appendChild(r),r},Pr=null,Qo=null,Vo=null,mx=function(t){return function(n){t(new Error("Failed to load Stripe.js",{cause:n}))}},gx=function(t,n){return function(){window.Stripe?t(window.Stripe):n(new Error("Stripe.js not available"))}},yx=function(t){return Pr!==null?Pr:(Pr=new Promise(function(n,r){if(typeof window>"u"||typeof document>"u"){n(null);return}if(window.Stripe){n(window.Stripe);return}try{var o=hx();if(!(o&&t)){if(!o)o=_d(t);else if(o&&Vo!==null&&Qo!==null){var i;o.removeEventListener("load",Vo),o.removeEventListener("error",Qo),(i=o.parentNode)===null||i===void 0||i.removeChild(o),o=_d(t)}}Vo=gx(n,r),Qo=mx(r),o.addEventListener("load",Vo),o.addEventListener("error",Qo)}catch(s){r(s);return}}),Pr.catch(function(n){return Pr=null,Promise.reject(n)}))},br,vx=function(){return br||(br=yx(null).catch(function(t){return br=null,Promise.reject(t)}),br)};Promise.resolve().then(function(){return vx()}).catch(function(e){console.warn(e)});const wx=k.div`
  max-width: 1200px;
  margin: 3rem auto;
  padding: 0 1rem;
`,xx=k.div`
  text-align: center;
  margin-bottom: 3rem;
  
  h1 {
    font-size: 2.5rem;
    color: ${e=>e.theme.colors.primary};
    margin-bottom: 1rem;
  }
  
  p {
    font-size: 1.1rem;
    color: ${e=>e.theme.colors.textLight};
    max-width: 700px;
    margin: 0 auto;
  }
`,Sx=k.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
`,kx=k.div`
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: ${e=>e.theme.shadows.medium};
  transition: transform 0.3s ease;
  border: 2px solid ${e=>e.selected?e.theme.colors.primary:"transparent"};
  
  &:hover {
    transform: translateY(-5px);
  }
  
  ${e=>e.featured&&!e.selected&&`
    border: 2px solid ${e.theme.colors.secondary};
  `}
`,Ex=k.div`
  background-color: ${e=>e.featured?e.theme.colors.primary:e.theme.colors.backgroundDark};
  padding: 2rem;
  text-align: center;
  
  h3 {
    font-size: 1.8rem;
    margin-bottom: 0.5rem;
    color: ${e=>e.featured?"white":e.theme.colors.primary};
  }
`,Cx=k.div`
  font-size: 2.5rem;
  font-weight: 700;
  color: ${e=>e.featured?"white":e.theme.colors.primary};
  
  span {
    font-size: 1rem;
    font-weight: 400;
    opacity: 0.8;
  }
`,jx=k.div`
  padding: 2rem;
  
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
    
    li {
      padding: 0.75rem 0;
      border-bottom: 1px solid ${e=>e.theme.colors.border};
      
      &:before {
        content: "✓";
        color: ${e=>e.theme.colors.success};
        margin-right: 0.5rem;
      }
      
      &:last-child {
        border-bottom: none;
      }
    }
  }
`,Px=k.button`
  display: block;
  width: 100%;
  background-color: ${e=>e.selected?e.theme.colors.success:e.featured?e.theme.colors.primary:"white"};
  color: ${e=>e.selected||e.featured?"white":e.theme.colors.primary};
  text-align: center;
  padding: 1rem;
  font-weight: 600;
  border: none;
  border-top: 1px solid ${e=>e.theme.colors.border};
  cursor: pointer;
  transition: all 0.3s ease;
  
  ${e=>!e.featured&&!e.selected&&`
    border: 2px solid ${e.theme.colors.primary};
    margin: 0 2rem 2rem;
    border-radius: 4px;
  `}
  
  &:hover {
    background-color: ${e=>e.selected?e.theme.colors.success:e.featured?e.theme.colors.primaryDark:e.theme.colors.primary};
    color: white;
  }
  
  &:disabled {
    background-color: ${e=>e.theme.colors.textLight};
    cursor: not-allowed;
  }
`,bx=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  margin-bottom: 3rem;
  box-shadow: ${e=>e.theme.shadows.medium};
`,Tx=k.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  
  h2 {
    font-size: 1.8rem;
    color: ${e=>e.theme.colors.primary};
    margin: 0;
  }
`,Rx=k.div`
  display: flex;
  align-items: center;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  background-color: ${e=>e.status==="active"?"rgba(56, 176, 0, 0.1)":e.status==="inactive"?"rgba(217, 4, 41, 0.1)":"rgba(255, 190, 11, 0.1)"};
  
  span {
    font-weight: 600;
    margin-left: 0.5rem;
    color: ${e=>e.status==="active"?e.theme.colors.success:e.status==="inactive"?e.theme.colors.error:e.theme.colors.warning};
  }
`,$x=k.div`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: ${e=>e.status==="active"?e.theme.colors.success:e.status==="inactive"?e.theme.colors.error:e.theme.colors.warning};
`,_x=k.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
  
  div {
    h3 {
      font-size: 1rem;
      color: ${e=>e.theme.colors.textLight};
      margin-bottom: 0.5rem;
    }
    
    p {
      font-size: 1.2rem;
      font-weight: 600;
    }
  }
`,Nx=k.div`
  display: flex;
  gap: 1rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.mobile}) {
    flex-direction: column;
  }
`,Ox=k.button`
  background-color: white;
  color: ${e=>e.theme.colors.error};
  border: 1px solid ${e=>e.theme.colors.error};
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.error};
    color: white;
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,Ax=k.button`
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
  }
  
  &:disabled {
    background-color: ${e=>e.theme.colors.textLight};
    cursor: not-allowed;
  }
`,Lx=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  
  h2 {
    font-size: 1.8rem;
    color: ${e=>e.theme.colors.primary};
    margin-bottom: 1.5rem;
  }
`,zx=k.form`
  margin-top: 2rem;
`,Dx=k.div`
  margin-bottom: 1.5rem;
  
  label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
  }
`,Ix=k.button`
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
  width: 100%;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
  }
  
  &:disabled {
    background-color: ${e=>e.theme.colors.textLight};
    cursor: not-allowed;
  }
`,Fx=k.div`
  color: ${e=>e.theme.colors.error};
  background-color: rgba(217, 4, 41, 0.1);
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
`,Mx=k.div`
  color: ${e=>e.theme.colors.success};
  background-color: rgba(56, 176, 0, 0.1);
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 1.5rem;
  font-size: 0.9rem;
`,Bx=e=>{const t={year:"numeric",month:"long",day:"numeric"};return new Date(e).toLocaleDateString(void 0,t)},Ux=()=>{const{currentUser:e}=Ct(),{subscriptionPlans:t,userSubscription:n,hasActiveSubscription:r,createSubscription:o,cancelSubscription:i,loading:s}=Au(),[l,a]=P.useState(null),[c,f]=P.useState("monthly"),[d,m]=P.useState(!1),[w,y]=P.useState(""),[v,x]=P.useState(""),h=[{id:"plan_monthly",name:"Monthly Plan",price:9.99,cycle:"monthly",features:["Access to all practice questions","Basic strategy guides","Performance tracking","7-day free trial"]},{id:"plan_annual",name:"Annual Plan",price:99.99,cycle:"annual",features:["Access to all practice questions","Advanced strategy guides","Detailed performance analytics","Personalized study recommendations","Unlimited practice sessions","14-day free trial","Save 16% compared to monthly"],featured:!0}],p=C=>{a(C),f(C.cycle)},g=async C=>{if(C.preventDefault(),!l){y("Please select a subscription plan");return}try{y(""),m(!0),await o(l.id,c),x("Subscription created successfully!"),a(null)}catch(j){y(j.message||"Failed to create subscription")}finally{m(!1)}},S=async()=>{if(confirm("Are you sure you want to cancel your subscription? You will lose access to premium content at the end of your billing period."))try{y(""),m(!0),await i(),x("Your subscription has been canceled. You will have access until the end of your current billing period.")}catch(C){y(C.message||"Failed to cancel subscription")}finally{m(!1)}};return u.jsxs(wx,{children:[u.jsxs(xx,{children:[u.jsx("h1",{children:"Subscription Plans"}),u.jsx("p",{children:"Choose the plan that best fits your needs and get access to our comprehensive PRITE exam preparation resources."})]}),w&&u.jsx(Fx,{children:w}),v&&u.jsx(Mx,{children:v}),r&&n&&u.jsxs(bx,{children:[u.jsxs(Tx,{children:[u.jsx("h2",{children:"Current Subscription"}),u.jsxs(Rx,{status:"active",children:[u.jsx($x,{status:"active"}),u.jsx("span",{children:"Active"})]})]}),u.jsxs(_x,{children:[u.jsxs("div",{children:[u.jsx("h3",{children:"Plan"}),u.jsx("p",{children:n.plan_name||"Premium Plan"})]}),u.jsxs("div",{children:[u.jsx("h3",{children:"Billing Cycle"}),u.jsx("p",{children:n.cycle==="annual"?"Annual":"Monthly"})]}),u.jsxs("div",{children:[u.jsx("h3",{children:"Next Billing Date"}),u.jsx("p",{children:n.next_billing_date?Bx(n.next_billing_date):"June 24, 2025"})]}),u.jsxs("div",{children:[u.jsx("h3",{children:"Amount"}),u.jsxs("p",{children:["$",n.amount||(n.cycle==="annual"?"99.99":"9.99")]})]})]}),u.jsxs(Nx,{children:[u.jsx(Ox,{onClick:S,disabled:d,children:"Cancel Subscription"}),n.cycle==="monthly"&&u.jsx(Ax,{onClick:()=>p(h[1]),disabled:d,children:"Upgrade to Annual"})]})]}),u.jsx(Sx,{children:h.map(C=>u.jsxs(kx,{featured:C.featured,selected:l&&l.id===C.id,children:[u.jsxs(Ex,{featured:C.featured,children:[u.jsx("h3",{children:C.name}),u.jsxs(Cx,{featured:C.featured,children:["$",C.price,u.jsxs("span",{children:["/",C.cycle==="annual"?"year":"month"]})]})]}),u.jsx(jx,{children:u.jsx("ul",{children:C.features.map((j,b)=>u.jsx("li",{children:j},b))})}),u.jsx(Px,{featured:C.featured,selected:l&&l.id===C.id,onClick:()=>p(C),disabled:d||r&&(n==null?void 0:n.cycle)===C.cycle,children:l&&l.id===C.id?"Selected":r&&(n==null?void 0:n.cycle)===C.cycle?"Current Plan":"Select Plan"})]},C.id))}),l&&!r&&u.jsxs(Lx,{children:[u.jsx("h2",{children:"Complete Your Subscription"}),u.jsxs("p",{children:["You've selected the ",u.jsx("strong",{children:l.name})," at ",u.jsxs("strong",{children:["$",l.price,"/",l.cycle==="annual"?"year":"month"]}),"."]}),u.jsxs(zx,{onSubmit:g,children:[u.jsxs(Dx,{children:[u.jsx("label",{htmlFor:"card-element",children:"Credit or debit card"}),u.jsx("div",{id:"card-element",style:{padding:"1rem",border:"1px solid #dee2e6",borderRadius:"4px"},children:"[Stripe Card Element Placeholder]"})]}),u.jsx(Ix,{type:"submit",disabled:d,children:d?"Processing...":`Subscribe for $${l.price}`})]})]})]})},Hx=k.div`
  max-width: 1200px;
  margin: 3rem auto;
  padding: 0 1rem;
`,Wx=k.div`
  text-align: center;
  margin-bottom: 3rem;
  
  h1 {
    font-size: 2.5rem;
    color: ${e=>e.theme.colors.primary};
    margin-bottom: 1rem;
  }
  
  p {
    font-size: 1.1rem;
    color: ${e=>e.theme.colors.textLight};
    max-width: 700px;
    margin: 0 auto;
  }
`,qx=k.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
`,Qx=k.div`
  background-color: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: ${e=>e.theme.shadows.medium};
  transition: transform 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-5px);
  }
`,Vx=k.div`
  height: 180px;
  background-color: ${e=>e.theme.colors.backgroundDark};
  background-image: ${e=>e.image?`url(${e.image})`:"none"};
  background-size: cover;
  background-position: center;
  display: flex;
  align-items: center;
  justify-content: center;
  
  span {
    font-size: 3rem;
    color: ${e=>e.theme.colors.primary};
  }
`,Kx=k.div`
  padding: 1.5rem;
  
  h3 {
    font-size: 1.3rem;
    margin-bottom: 0.75rem;
    color: ${e=>e.theme.colors.primary};
  }
  
  p {
    color: ${e=>e.theme.colors.textLight};
    margin-bottom: 1rem;
    font-size: 0.95rem;
    line-height: 1.5;
  }
`,Gx=k.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-top: 1rem;
`,Yx=k.span`
  background-color: ${e=>e.theme.colors.backgroundDark};
  color: ${e=>e.theme.colors.textLight};
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
`,Xx=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  margin-bottom: 3rem;
`,Jx=k.div`
  margin-bottom: 2rem;
  
  h2 {
    font-size: 2rem;
    color: ${e=>e.theme.colors.primary};
    margin-bottom: 1rem;
  }
  
  .meta {
    display: flex;
    gap: 1rem;
    color: ${e=>e.theme.colors.textLight};
    font-size: 0.9rem;
    
    span {
      display: flex;
      align-items: center;
      
      &:before {
        content: '•';
        margin-right: 0.5rem;
      }
      
      &:first-child:before {
        content: '';
        margin-right: 0;
      }
    }
  }
`,Zx=k.div`
  line-height: 1.8;
  
  h3 {
    font-size: 1.5rem;
    color: ${e=>e.theme.colors.primary};
    margin: 2rem 0 1rem;
  }
  
  p {
    margin-bottom: 1.5rem;
  }
  
  ul, ol {
    margin-bottom: 1.5rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.75rem;
    }
  }
  
  blockquote {
    border-left: 4px solid ${e=>e.theme.colors.primary};
    padding-left: 1rem;
    margin-left: 0;
    margin-bottom: 1.5rem;
    font-style: italic;
    color: ${e=>e.theme.colors.textLight};
  }
  
  .example {
    background-color: ${e=>e.theme.colors.backgroundDark};
    padding: 1.5rem;
    border-radius: 8px;
    margin-bottom: 1.5rem;
    
    h4 {
      font-size: 1.2rem;
      margin-bottom: 1rem;
      color: ${e=>e.theme.colors.primary};
    }
  }
`,eS=k.button`
  background: none;
  border: none;
  color: ${e=>e.theme.colors.primary};
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  padding: 0;
  margin-bottom: 1.5rem;
  
  &:before {
    content: '←';
    margin-right: 0.5rem;
  }
  
  &:hover {
    text-decoration: underline;
  }
`,tS=k.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }
`,nS=k.input`
  padding: 0.75rem 1rem;
  border: 1px solid ${e=>e.theme.colors.border};
  border-radius: 4px;
  width: 300px;
  
  &:focus {
    outline: none;
    border-color: ${e=>e.theme.colors.primary};
  }
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    width: 100%;
  }
`,rS=k.div`
  display: flex;
  gap: 0.75rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    flex-wrap: wrap;
  }
`,oS=k.button`
  background-color: ${e=>e.active?e.theme.colors.primary:"white"};
  color: ${e=>e.active?"white":e.theme.colors.text};
  border: 1px solid ${e=>e.active?e.theme.colors.primary:e.theme.colors.border};
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.active?e.theme.colors.primaryDark:e.theme.colors.backgroundDark};
  }
`,iS=[{id:1,title:'Understanding "Which of the Following" Questions',description:"Master the most common question format in the PRITE exam.",icon:"🔍",category:"Question Format",tags:["Common Format","High Yield"],content:`
      <h3>Understanding "Which of the Following" Questions</h3>
      
      <p>The "Which of the following" format is the most common question type in the PRITE exam, accounting for approximately 67% of all questions. Mastering this format is essential for success.</p>
      
      <h3>Key Characteristics</h3>
      
      <ul>
        <li>Presents a stem followed by 5 answer choices (A-E)</li>
        <li>Often includes qualifying words like "MOST," "BEST," "LEAST," etc.</li>
        <li>May contain clinical vignettes describing patient scenarios</li>
        <li>Requires identifying the single best answer among options</li>
      </ul>
      
      <h3>Strategic Approach</h3>
      
      <ol>
        <li><strong>Identify the question type:</strong> Recognize whether it's asking for the most appropriate, least likely, exception, etc.</li>
        <li><strong>Read the stem carefully:</strong> Identify the key information and what is being asked.</li>
        <li><strong>Predict the answer:</strong> Before looking at options, try to formulate your own answer.</li>
        <li><strong>Evaluate each option systematically:</strong> Compare each to your prediction.</li>
        <li><strong>Use process of elimination:</strong> Cross out clearly incorrect options.</li>
        <li><strong>Watch for qualifiers:</strong> Pay special attention to words like "most," "best," "least," etc.</li>
      </ol>
      
      <div class="example">
        <h4>Example Question</h4>
        <p>A 45-year-old man presents with depressed mood, anhedonia, insomnia, and weight loss for the past month following the death of his mother. Which of the following is the MOST appropriate initial treatment?</p>
        <p>A. Supportive psychotherapy<br>
        B. Cognitive-behavioral therapy<br>
        C. Sertraline<br>
        D. Alprazolam<br>
        E. Electroconvulsive therapy</p>
        
        <p><strong>Analysis:</strong> This question uses the qualifier "MOST appropriate initial treatment." The key is to recognize that this is likely an adjustment disorder or possibly major depression, and to identify the standard first-line treatment approach. Options C and D are medications, which may be appropriate but not necessarily as initial treatments. Option E (ECT) would be too aggressive for an initial treatment. Between options A and B, supportive psychotherapy is more appropriate as an initial intervention for grief-related symptoms, making A the correct answer.</p>
      </div>
      
      <h3>Common Traps to Avoid</h3>
      
      <ul>
        <li><strong>Overlooking qualifiers:</strong> Missing words like "MOST," "LEAST," "BEST," etc.</li>
        <li><strong>Selecting familiar options:</strong> Choosing an answer because it's familiar, not because it's correct</li>
        <li><strong>Falling for partially correct answers:</strong> Some options may be partially correct but not the best answer</li>
        <li><strong>Misreading the stem:</strong> Misunderstanding what the question is actually asking</li>
      </ul>
      
      <p>By mastering this question format, you'll be well-prepared to handle the majority of questions on the PRITE exam.</p>
    `},{id:2,title:"Tackling Clinical Vignette Questions",description:"Strategies for approaching patient case scenarios effectively.",icon:"👨‍⚕️",category:"Clinical Reasoning",tags:["Case-Based","Diagnosis"],content:`
      <h3>Tackling Clinical Vignette Questions</h3>
      
      <p>Clinical vignettes appear in approximately 39% of PRITE exam questions. These questions present patient scenarios and test your clinical reasoning and decision-making skills.</p>
      
      <h3>Key Characteristics</h3>
      
      <ul>
        <li>Present a detailed patient scenario or case</li>
        <li>Include demographic information, symptoms, history, and sometimes lab results</li>
        <li>May ask about diagnosis, next steps, or management</li>
        <li>Often require multi-step reasoning</li>
      </ul>
      
      <h3>Strategic Approach</h3>
      
      <ol>
        <li><strong>Organize information systematically:</strong>
          <ul>
            <li>Demographics (age, gender)</li>
            <li>Presenting symptoms</li>
            <li>Duration and course</li>
            <li>Past medical/psychiatric history</li>
            <li>Relevant negatives</li>
            <li>Lab/test results</li>
          </ul>
        </li>
        <li><strong>Generate a differential diagnosis:</strong> Consider 2-3 most likely diagnoses based on the information provided.</li>
        <li><strong>Look for distinguishing features:</strong> Identify key symptoms or findings that differentiate between similar conditions.</li>
        <li><strong>Consider the question focus:</strong> Is it asking about diagnosis, next steps, treatment, or prognosis?</li>
      </ol>
      
      <div class="example">
        <h4>Example Question</h4>
        <p>A 22-year-old college student presents with a 6-month history of persistent fear of embarrassment in social situations. He avoids class presentations and social gatherings due to fear of being judged negatively. His symptoms cause significant distress and academic impairment. Mental status examination reveals anxious affect but is otherwise unremarkable. Which of the following is the MOST likely diagnosis?</p>
        <p>A. Panic disorder<br>
        B. Generalized anxiety disorder<br>
        C. Social anxiety disorder<br>
        D. Avoidant personality disorder<br>
        E. Major depressive disorder with anxious features</p>
        
        <p><strong>Analysis:</strong> This vignette describes a young adult with fear and avoidance specifically related to social situations where he might be judged, causing significant impairment. The key distinguishing features are the social focus of the anxiety and the fear of negative evaluation. This most closely matches the diagnostic criteria for social anxiety disorder (option C).</p>
      </div>
      
      <h3>Common Traps to Avoid</h3>
      
      <ul>
        <li><strong>Focusing on irrelevant details:</strong> Not all information in the vignette is equally important</li>
        <li><strong>Premature closure:</strong> Jumping to a diagnosis before considering all the information</li>
        <li><strong>Anchoring bias:</strong> Fixating on an early piece of information and failing to adjust your thinking</li>
        <li><strong>Availability bias:</strong> Overemphasizing diagnoses you've recently studied or encountered</li>
      </ul>
      
      <h3>Practice Techniques</h3>
      
      <p>To improve your performance on clinical vignettes:</p>
      
      <ul>
        <li>Practice summarizing cases in a structured format</li>
        <li>Develop systematic approaches to common presentations</li>
        <li>Review DSM-5 diagnostic criteria for major disorders</li>
        <li>Practice generating differential diagnoses for various symptom clusters</li>
      </ul>
    `},{id:3,title:"Mastering Questions with Qualifying Words",description:'How to handle questions with terms like "MOST," "BEST," and "LEAST."',icon:"📝",category:"Question Format",tags:["Test-Taking","High Yield"],content:`
      <h3>Mastering Questions with Qualifying Words</h3>
      
      <p>Approximately 38% of PRITE questions contain qualifying words like "MOST," "BEST," "LEAST," etc. These words significantly change how you should approach the question.</p>
      
      <h3>Common Qualifying Words and Their Implications</h3>
      
      <ul>
        <li><strong>MOST/BEST:</strong> Indicates that multiple options may be correct, but one is superior</li>
        <li><strong>LEAST/WORST:</strong> Asks for the option that is least likely, appropriate, or beneficial</li>
        <li><strong>FIRST/INITIAL:</strong> Focuses on the first step in a sequence of actions</li>
        <li><strong>EXCEPT/NOT:</strong> Requires identifying the option that doesn't fit with the others</li>
      </ul>
      
      <h3>Strategic Approach</h3>
      
      <ol>
        <li><strong>Identify the qualifier immediately:</strong> Underline or highlight it mentally</li>
        <li><strong>Rephrase the question:</strong> Restate it in your own words to clarify what's being asked</li>
        <li><strong>Consider all options as potentially correct:</strong> With "MOST/BEST" questions, multiple answers may be partially correct</li>
        <li><strong>Use comparative reasoning:</strong> Evaluate options relative to each other, not just as right or wrong</li>
        <li><strong>Apply clinical guidelines:</strong> For "BEST" questions, consider standard of care and clinical guidelines</li>
      </ol>
      
      <div class="example">
        <h4>Example Question</h4>
        <p>A 35-year-old woman with bipolar I disorder has been stable on lithium for 2 years. She now reports that she is 8 weeks pregnant. Which of the following is the MOST appropriate next step in management?</p>
        <p>A. Continue lithium at the current dose<br>
        B. Discontinue lithium immediately<br>
        C. Switch to valproic acid<br>
        D. Discuss risks/benefits and consider dose reduction or alternative medication<br>
        E. Switch to carbamazepine</p>
        
        <p><strong>Analysis:</strong> This question uses "MOST appropriate" as a qualifier. Options A, B, C, and E all have significant issues: continuing lithium without any changes (A) ignores pregnancy risks; abrupt discontinuation (B) risks relapse; switching to valproic acid (C) or carbamazepine (E) introduces different teratogenic risks. Option D (discussing risks/benefits and considering dose reduction or alternatives) represents the most balanced, patient-centered approach following clinical guidelines, making it the best answer.</p>
      </div>
      
      <h3>Strategies for Specific Qualifiers</h3>
      
      <h4>For "MOST/BEST" Questions:</h4>
      <ul>
        <li>Look for the option that is most comprehensive</li>
        <li>Consider what would be recommended by current practice guidelines</li>
        <li>Look for options that address the most critical aspect of the scenario</li>
      </ul>
      
      <h4>For "LEAST/WORST" Questions:</h4>
      <ul>
        <li>Invert your thinking - look for what would be incorrect or harmful</li>
        <li>Be careful with double negatives</li>
        <li>Consider contraindications and inappropriate treatments</li>
      </ul>
      
      <h4>For "EXCEPT/NOT" Questions:</h4>
      <ul>
        <li>Identify the category or pattern that most options fit into</li>
        <li>Look for the option that doesn't belong with the others</li>
        <li>Verify that the other four options do share a common characteristic</li>
      </ul>
      
      <p>Mastering questions with qualifying words will significantly improve your performance on the PRITE exam, as these questions often test nuanced clinical judgment.</p>
    `},{id:4,title:"Handling Multi-Step Reasoning Questions",description:"Techniques for questions that require complex problem-solving.",icon:"🧩",category:"Clinical Reasoning",tags:["Complex","Problem-Solving"],content:`
      <h3>Handling Multi-Step Reasoning Questions</h3>
      
      <p>Approximately 28% of PRITE questions require multi-step reasoning. These questions test your ability to integrate knowledge and apply it through a series of logical steps.</p>
      
      <h3>Key Characteristics</h3>
      
      <ul>
        <li>Require application of multiple concepts to reach the answer</li>
        <li>Often involve diagnosis followed by treatment decisions</li>
        <li>May include lab interpretation and clinical decision-making</li>
        <li>Test deeper understanding rather than simple recall</li>
      </ul>
      
      <h3>Strategic Approach</h3>
      
      <ol>
        <li><strong>Break down the question into components:</strong> Identify each step in the reasoning process</li>
        <li><strong>Solve one step at a time:</strong> Don't jump ahead to the final answer</li>
        <li><strong>Use scratch paper if needed:</strong> Write down your reasoning for complex questions</li>
        <li><strong>Verify your logic:</strong> Check that each step logically leads to the next</li>
        <li><strong>Consider alternative pathways:</strong> If your first approach doesn't lead to a clear answer</li>
      </ol>
      
      <div class="example">
        <h4>Example Question</h4>
        <p>A 42-year-old man with schizophrenia has been treated with risperidone 4 mg daily for 3 years. He presents with tremor, muscle stiffness, and a shuffling gait. His serum creatine kinase is normal. After confirming a diagnosis of drug-induced parkinsonism, which of the following is the MOST appropriate management?</p>
        <p>A. Add benztropine<br>
        B. Increase risperidone dose<br>
        C. Switch to clozapine<br>
        D. Add propranolol<br>
        E. Switch to haloperidol</p>
        
        <p><strong>Analysis:</strong> This question requires multiple steps of reasoning:</p>
        <ol>
          <li>Recognize the symptoms as drug-induced parkinsonism (already confirmed in the question)</li>
          <li>Know that this is caused by dopamine blockade from risperidone</li>
          <li>Determine the appropriate management for antipsychotic-induced parkinsonism</li>
          <li>Evaluate each option based on this understanding</li>
        </ol>
        <p>Option A (adding benztropine, an anticholinergic) directly addresses the parkinsonism. Option B (increasing risperidone) would worsen symptoms. Option C (switching to clozapine) is reasonable but more drastic than needed initially. Option D (propranolol) treats tremor but not other parkinsonian symptoms. Option E (switching to haloperidol) would likely worsen symptoms as it has stronger D2 blockade. Therefore, A is the most appropriate first step.</p>
      </div>
      
      <h3>Common Types of Multi-Step Questions</h3>
      
      <h4>Diagnosis → Treatment</h4>
      <p>These questions require first determining the diagnosis, then selecting the appropriate treatment based on that diagnosis.</p>
      
      <h4>Lab Interpretation → Clinical Decision</h4>
      <p>These questions require interpreting laboratory or test results, then making a clinical decision based on that interpretation.</p>
      
      <h4>Risk Assessment → Management</h4>
      <p>These questions require assessing risk factors or severity, then determining the appropriate level or type of intervention.</p>
      
      <h3>Practice Techniques</h3>
      
      <ul>
        <li>Practice creating flowcharts for clinical decision-making</li>
        <li>Review algorithms for common psychiatric conditions</li>
        <li>Practice "thinking aloud" through complex cases</li>
        <li>Study the relationships between diagnoses and their first-line treatments</li>
      </ul>
      
      <p>By developing a systematic approach to multi-step reasoning questions, you'll be better equipped to handle some of the most challenging questions on the PRITE exam.</p>
    `},{id:5,title:"Navigating Negative Phrasing Questions",description:'How to approach questions with "EXCEPT," "NOT," and other negative terms.',icon:"❌",category:"Question Format",tags:["Test-Taking","Common Pitfalls"],content:`
      <h3>Navigating Negative Phrasing Questions</h3>
      
      <p>Approximately 9% of PRITE questions use negative phrasing with terms like "EXCEPT," "NOT," "LEAST," etc. These questions can be particularly tricky and require careful attention.</p>
      
      <h3>Key Characteristics</h3>
      
      <ul>
        <li>Ask for the exception to a rule or pattern</li>
        <li>Often contain words like "EXCEPT," "NOT," "LEAST," "FALSE," etc.</li>
        <li>Require identifying the option that doesn't fit with the others</li>
        <li>May use double negatives, which can be confusing</li>
      </ul>
      
      <h3>Strategic Approach</h3>
      
      <ol>
        <li><strong>Identify negative phrasing immediately:</strong> Underline or highlight "EXCEPT," "NOT," etc.</li>
        <li><strong>Rephrase the question positively:</strong> Convert it to what you're actually looking for</li>
        <li><strong>Evaluate each option individually:</strong> Mark each as true or false based on the stem</li>
        <li><strong>Look for the odd one out:</strong> Find the option that doesn't follow the pattern of the others</li>
        <li><strong>Double-check your answer:</strong> Verify that the other four options do fit the pattern</li>
      </ol>
      
      <div class="example">
        <h4>Example Question</h4>
        <p>All of the following are common side effects of clozapine EXCEPT:</p>
        <p>A. Agranulocytosis<br>
        B. Weight gain<br>
        C. Hypersalivation<br>
        D. Seizures<br>
        E. Extrapyramidal symptoms</p>
        
        <p><strong>Analysis:</strong> This question uses "EXCEPT" to ask which option is NOT a common side effect of clozapine. Rephrasing positively: "Which of the following is NOT a common side effect of clozapine?" Options A, B, C, and D are all known side effects of clozapine. Option E (extrapyramidal symptoms) is actually a side effect that clozapine rarely causes compared to other antipsychotics, making it the correct answer (the exception).</p>
      </div>
      
      <h3>Types of Negative Phrasing Questions</h3>
      
      <h4>"All of the following EXCEPT" Format</h4>
      <p>This common format presents a list where four options share a characteristic and one does not.</p>
      <p><strong>Strategy:</strong> Identify the category or rule that applies to most options, then find the exception.</p>
      
      <h4>"Which of the following is NOT" Format</h4>
      <p>Similar to the above, but phrased differently.</p>
      <p><strong>Strategy:</strong> Convert each option to true/false statements and find the false one.</p>
      
      <h4>"LEAST likely" Format</h4>
      <p>Asks for the option that is least probable or appropriate.</p>
      <p><strong>Strategy:</strong> Rank options from most to least likely and select the least likely.</p>
      
      <h3>Common Pitfalls to Avoid</h3>
      
      <ul>
        <li><strong>Missing the negative word:</strong> Always carefully read for "NOT," "EXCEPT," etc.</li>
        <li><strong>Confusion with double negatives:</strong> "Which is NOT inconsistent with..." can be confusing</li>
        <li><strong>Selecting the most correct answer:</strong> Remember you're looking for the exception or incorrect option</li>
        <li><strong>Rushing through options:</strong> Take time to evaluate each option individually</li>
      </ul>
      
      <h3>Practice Techniques</h3>
      
      <ul>
        <li>Develop the habit of underlining negative words in questions</li>
        <li>Practice rephrasing negative questions in positive terms</li>
        <li>Create flashcards with "all of the following EXCEPT" format for key topics</li>
        <li>When studying a topic, practice identifying exceptions to general rules</li>
      </ul>
      
      <p>By mastering negatively phrased questions, you'll avoid a common trap that trips up many test-takers on the PRITE exam.</p>
    `}],sS=()=>{const[e,t]=P.useState(null),[n,r]=P.useState(""),[o,i]=P.useState("All"),{hasActiveSubscription:s}=Ct(),l=["All","Question Format","Clinical Reasoning","Test-Taking","Time Management"],a=iS.filter(d=>{const m=d.title.toLowerCase().includes(n.toLowerCase())||d.description.toLowerCase().includes(n.toLowerCase()),w=o==="All"||d.category===o;return m&&w}),c=d=>{t(d),window.scrollTo(0,0)},f=()=>{t(null)};return u.jsxs(Hx,{children:[u.jsxs(Wx,{children:[u.jsx("h1",{children:"PRITE Exam Strategies"}),u.jsx("p",{children:"Master proven techniques to excel on your psychiatry board exams."})]}),e?u.jsxs(Xx,{children:[u.jsx(eS,{onClick:f,children:"Back to Strategies"}),u.jsxs(Jx,{children:[u.jsx("h2",{children:e.title}),u.jsxs("div",{className:"meta",children:[u.jsx("span",{children:e.category}),u.jsxs("span",{children:["Reading time: ",Math.ceil(e.content.length/1e3)," min"]})]})]}),u.jsx(Zx,{dangerouslySetInnerHTML:{__html:s?e.content:e.content.substring(0,500)+"... <p><strong>Subscribe to access the full content.</strong></p>"}}),!s&&u.jsxs("div",{style:{marginTop:"2rem",textAlign:"center"},children:[u.jsx("p",{children:"Access to full strategy content requires an active subscription."}),u.jsx(Link,{to:"/subscription",style:{display:"inline-block",backgroundColor:"#3a86ff",color:"white",padding:"0.75rem 1.5rem",borderRadius:"4px",fontWeight:"600",marginTop:"1rem"},children:"Subscribe Now"})]})]}):u.jsxs(u.Fragment,{children:[u.jsxs(tS,{children:[u.jsx(nS,{type:"text",placeholder:"Search strategies...",value:n,onChange:d=>r(d.target.value)}),u.jsx(rS,{children:l.map(d=>u.jsx(oS,{active:o===d,onClick:()=>i(d),children:d},d))})]}),u.jsx(qx,{children:a.map(d=>u.jsxs(Qx,{onClick:()=>c(d),children:[u.jsx(Vx,{children:u.jsx("span",{children:d.icon})}),u.jsxs(Kx,{children:[u.jsx("h3",{children:d.title}),u.jsx("p",{children:d.description}),u.jsx(Gx,{children:d.tags.map((m,w)=>u.jsx(Yx,{children:m},w))})]})]},d.id))})]})]})},ml=k.div`
  max-width: 1200px;
  margin: 3rem auto;
  padding: 0 1rem;
`,gl=k.div`
  text-align: center;
  margin-bottom: 3rem;
  
  h1 {
    font-size: 2.5rem;
    color: ${e=>e.theme.colors.primary};
    margin-bottom: 1rem;
  }
  
  p {
    font-size: 1.1rem;
    color: ${e=>e.theme.colors.textLight};
    max-width: 700px;
    margin: 0 auto;
  }
`,lS=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  margin-bottom: 2rem;
`,aS=k.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 1.5rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.mobile}) {
    flex-direction: column;
    gap: 0.5rem;
  }
`,uS=k.div`
  font-weight: 600;
  color: ${e=>e.theme.colors.primary};
`,cS=k.div`
  background-color: ${e=>e.theme.colors.backgroundDark};
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.9rem;
  color: ${e=>e.theme.colors.textLight};
`,dS=k.div`
  font-size: 1.1rem;
  line-height: 1.6;
  margin-bottom: 2rem;
`,fS=k.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,pS=k.label`
  display: flex;
  align-items: flex-start;
  padding: 1rem;
  border: 1px solid ${e=>e.selected?e.correct?e.theme.colors.success:e.theme.colors.error:e.theme.colors.border};
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s ease;
  background-color: ${e=>e.selected?e.correct?"rgba(56, 176, 0, 0.1)":"rgba(217, 4, 41, 0.1)":e.correct&&e.showAnswer?"rgba(56, 176, 0, 0.1)":"white"};
  
  &:hover {
    background-color: ${e=>e.selected||e.correct&&e.showAnswer?e.selected?e.correct?"rgba(56, 176, 0, 0.1)":"rgba(217, 4, 41, 0.1)":"rgba(56, 176, 0, 0.1)":e.theme.colors.backgroundDark};
  }
`,hS=k.input`
  margin-right: 1rem;
  margin-top: 0.25rem;
`,mS=k.div`
  flex: 1;
`,gS=k.span`
  font-weight: 600;
  margin-right: 0.5rem;
`,yS=k.div`
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 1px solid ${e=>e.theme.colors.border};
`,vS=k.h3`
  font-size: 1.3rem;
  color: ${e=>e.theme.colors.primary};
  margin-bottom: 1rem;
`,wS=k.div`
  line-height: 1.6;
  
  p {
    margin-bottom: 1rem;
  }
  
  ul, ol {
    margin-bottom: 1rem;
    padding-left: 1.5rem;
    
    li {
      margin-bottom: 0.5rem;
    }
  }
`,xS=k.div`
  display: flex;
  justify-content: space-between;
  margin-top: 2rem;
`,Tn=k.button`
  background-color: ${e=>e.primary?e.theme.colors.primary:"white"};
  color: ${e=>e.primary?"white":e.theme.colors.primary};
  border: 1px solid ${e=>e.primary?e.theme.colors.primary:e.theme.colors.border};
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.primary?e.theme.colors.primaryDark:e.theme.colors.backgroundDark};
  }
  
  &:disabled {
    background-color: ${e=>e.theme.colors.textLight};
    border-color: ${e=>e.theme.colors.textLight};
    color: white;
    cursor: not-allowed;
  }
`,SS=k.div`
  height: 8px;
  background-color: ${e=>e.theme.colors.backgroundDark};
  border-radius: 4px;
  margin-bottom: 2rem;
  overflow: hidden;
  
  div {
    height: 100%;
    background-color: ${e=>e.theme.colors.primary};
    width: ${e=>e.progress}%;
    transition: width 0.5s ease;
  }
`,kS=k.div`
  text-align: center;
  margin-bottom: 1rem;
  color: ${e=>e.theme.colors.textLight};
  font-size: 0.9rem;
`,Nd=k.div`
  background-color: white;
  border-radius: 8px;
  padding: 2rem;
  box-shadow: ${e=>e.theme.shadows.medium};
  text-align: center;
`,ES=k.div`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background-color: ${e=>{const t=e.score;return t>=80?e.theme.colors.success:t>=60?e.theme.colors.warning:e.theme.colors.error}};
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 2rem;
  
  span {
    font-size: 2.5rem;
    font-weight: 700;
    color: white;
  }
`,Od=k.h2`
  font-size: 2rem;
  color: ${e=>e.theme.colors.primary};
  margin-bottom: 1rem;
`,Ad=k.p`
  font-size: 1.1rem;
  color: ${e=>e.theme.colors.text};
  margin-bottom: 2rem;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
`,CS=k.div`
  display: flex;
  justify-content: center;
  gap: 1rem;
  
  @media (max-width: ${e=>e.theme.breakpoints.mobile}) {
    flex-direction: column;
  }
`,jS=k.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-bottom: 2rem;
  justify-content: center;
`,PS=k.button`
  background-color: ${e=>e.active?e.theme.colors.primary:"white"};
  color: ${e=>e.active?"white":e.theme.colors.text};
  border: 1px solid ${e=>e.active?e.theme.colors.primary:e.theme.colors.border};
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.active?e.theme.colors.primaryDark:e.theme.colors.backgroundDark};
  }
`,Ld=[{id:1,text:"A 45-year-old man presents with depressed mood, anhedonia, insomnia, and weight loss for the past month following the death of his mother. Which of the following is the MOST appropriate initial treatment?",options:[{id:"A",text:"Supportive psychotherapy"},{id:"B",text:"Cognitive-behavioral therapy"},{id:"C",text:"Sertraline"},{id:"D",text:"Alprazolam"},{id:"E",text:"Electroconvulsive therapy"}],correctAnswer:"A",explanation:"This question uses the qualifier 'MOST appropriate initial treatment.' The key is to recognize that this is likely an adjustment disorder or possibly major depression, and to identify the standard first-line treatment approach. Options C and D are medications, which may be appropriate but not necessarily as initial treatments. Option E (ECT) would be too aggressive for an initial treatment. Between options A and B, supportive psychotherapy is more appropriate as an initial intervention for grief-related symptoms, making A the correct answer.",category:"Clinical Management"},{id:2,text:"A 22-year-old college student presents with a 6-month history of persistent fear of embarrassment in social situations. He avoids class presentations and social gatherings due to fear of being judged negatively. His symptoms cause significant distress and academic impairment. Mental status examination reveals anxious affect but is otherwise unremarkable. Which of the following is the MOST likely diagnosis?",options:[{id:"A",text:"Panic disorder"},{id:"B",text:"Generalized anxiety disorder"},{id:"C",text:"Social anxiety disorder"},{id:"D",text:"Avoidant personality disorder"},{id:"E",text:"Major depressive disorder with anxious features"}],correctAnswer:"C",explanation:"This vignette describes a young adult with fear and avoidance specifically related to social situations where he might be judged, causing significant impairment. The key distinguishing features are the social focus of the anxiety and the fear of negative evaluation. This most closely matches the diagnostic criteria for social anxiety disorder (option C).",category:"Diagnosis"},{id:3,text:"A 42-year-old man with schizophrenia has been treated with risperidone 4 mg daily for 3 years. He presents with tremor, muscle stiffness, and a shuffling gait. His serum creatine kinase is normal. After confirming a diagnosis of drug-induced parkinsonism, which of the following is the MOST appropriate management?",options:[{id:"A",text:"Add benztropine"},{id:"B",text:"Increase risperidone dose"},{id:"C",text:"Switch to clozapine"},{id:"D",text:"Add propranolol"},{id:"E",text:"Switch to haloperidol"}],correctAnswer:"A",explanation:"This question requires multiple steps of reasoning: 1) Recognize the symptoms as drug-induced parkinsonism (already confirmed in the question), 2) Know that this is caused by dopamine blockade from risperidone, 3) Determine the appropriate management for antipsychotic-induced parkinsonism, 4) Evaluate each option based on this understanding. Option A (adding benztropine, an anticholinergic) directly addresses the parkinsonism. Option B (increasing risperidone) would worsen symptoms. Option C (switching to clozapine) is reasonable but more drastic than needed initially. Option D (propranolol) treats tremor but not other parkinsonian symptoms. Option E (switching to haloperidol) would likely worsen symptoms as it has stronger D2 blockade. Therefore, A is the most appropriate first step.",category:"Psychopharmacology"},{id:4,text:"All of the following are common side effects of clozapine EXCEPT:",options:[{id:"A",text:"Agranulocytosis"},{id:"B",text:"Weight gain"},{id:"C",text:"Hypersalivation"},{id:"D",text:"Seizures"},{id:"E",text:"Extrapyramidal symptoms"}],correctAnswer:"E",explanation:"This question uses 'EXCEPT' to ask which option is NOT a common side effect of clozapine. Options A, B, C, and D are all known side effects of clozapine. Option E (extrapyramidal symptoms) is actually a side effect that clozapine rarely causes compared to other antipsychotics, making it the correct answer (the exception).",category:"Psychopharmacology"},{id:5,text:"A 35-year-old woman with bipolar I disorder has been stable on lithium for 2 years. She now reports that she is 8 weeks pregnant. Which of the following is the MOST appropriate next step in management?",options:[{id:"A",text:"Continue lithium at the current dose"},{id:"B",text:"Discontinue lithium immediately"},{id:"C",text:"Switch to valproic acid"},{id:"D",text:"Discuss risks/benefits and consider dose reduction or alternative medication"},{id:"E",text:"Switch to carbamazepine"}],correctAnswer:"D",explanation:"This question uses 'MOST appropriate' as a qualifier. Options A, B, C, and E all have significant issues: continuing lithium without any changes (A) ignores pregnancy risks; abrupt discontinuation (B) risks relapse; switching to valproic acid (C) or carbamazepine (E) introduces different teratogenic risks. Option D (discussing risks/benefits and considering dose reduction or alternatives) represents the most balanced, patient-centered approach following clinical guidelines, making it the best answer.",category:"Clinical Management"}],bS=["All","Diagnosis","Clinical Management","Psychopharmacology","Neuroscience","Ethics"],TS=()=>{const[e,t]=P.useState(0),[n,r]=P.useState({}),[o,i]=P.useState(!1),[s,l]=P.useState(!1),[a,c]=P.useState("All"),{hasActiveSubscription:f}=Ct(),d=a==="All"?Ld:Ld.filter(j=>j.category===a),m=d[e],w=(j,b)=>{o||r({...n,[j]:b})},y=()=>{e<d.length-1?(t(e+1),i(!1)):l(!0)},v=()=>{e>0&&(t(e-1),i(!1))},x=()=>{i(!0)},h=()=>{t(0),r({}),i(!1),l(!1)},p=j=>{c(j),t(0),r({}),i(!1),l(!1)},S=(()=>{let j=0;return d.forEach(b=>{n[b.id]===b.correctAnswer&&j++}),{correct:j,total:d.length,percentage:Math.round(j/d.length*100)}})(),C=(e+1)/d.length*100;return f?s?u.jsxs(ml,{children:[u.jsxs(gl,{children:[u.jsx("h1",{children:"Practice Results"}),u.jsx("p",{children:"See how well you did and identify areas for improvement."})]}),u.jsxs(Nd,{children:[u.jsx(ES,{score:S.percentage,children:u.jsxs("span",{children:[S.percentage,"%"]})}),u.jsx(Od,{children:S.percentage>=80?"Excellent Work!":S.percentage>=60?"Good Progress!":"Keep Practicing!"}),u.jsxs(Ad,{children:["You answered ",S.correct," out of ",S.total," questions correctly.",S.percentage>=80?" You're showing mastery of this content area. Keep up the great work!":S.percentage>=60?" You're making good progress, but there's still room for improvement.":" This area needs more focus. Review the related strategy guides and try again."]}),u.jsxs(CS,{children:[u.jsx(Tn,{onClick:h,children:"Try Again"}),u.jsx(Tn,{primary:!0,as:"a",href:"/strategies",children:"Review Strategies"})]})]})]}):u.jsxs(ml,{children:[u.jsxs(gl,{children:[u.jsx("h1",{children:"Practice Questions"}),u.jsx("p",{children:"Test your knowledge with our comprehensive question bank."})]}),u.jsx(jS,{children:bS.map(j=>u.jsx(PS,{active:a===j,onClick:()=>p(j),children:j},j))}),u.jsxs(kS,{children:["Question ",e+1," of ",d.length]}),u.jsx(SS,{progress:C,children:u.jsx("div",{})}),u.jsxs(lS,{children:[u.jsxs(aS,{children:[u.jsxs(uS,{children:["Question ",e+1]}),u.jsx(cS,{children:m.category})]}),u.jsx(dS,{children:m.text}),u.jsx(fS,{children:m.options.map(j=>u.jsxs(pS,{selected:n[m.id]===j.id,correct:j.id===m.correctAnswer,showAnswer:o,children:[u.jsx(hS,{type:"radio",name:`question-${m.id}`,checked:n[m.id]===j.id,onChange:()=>w(m.id,j.id),disabled:o}),u.jsxs(mS,{children:[u.jsxs(gS,{children:[j.id,"."]}),j.text]})]},j.id))}),o&&u.jsxs(yS,{children:[u.jsx(vS,{children:"Explanation"}),u.jsx(wS,{children:m.explanation})]}),u.jsxs(xS,{children:[u.jsx(Tn,{onClick:v,disabled:e===0,children:"Previous"}),o?u.jsx(Tn,{onClick:y,primary:!0,children:e<d.length-1?"Next Question":"See Results"}):u.jsx(Tn,{onClick:x,primary:!0,disabled:!n[m.id],children:"Check Answer"})]})]})]}):u.jsxs(ml,{children:[u.jsxs(gl,{children:[u.jsx("h1",{children:"Practice Questions"}),u.jsx("p",{children:"Test your knowledge with our comprehensive question bank."})]}),u.jsxs(Nd,{children:[u.jsx(Od,{children:"Subscription Required"}),u.jsx(Ad,{children:"Access to practice questions requires an active subscription. Subscribe today to unlock our comprehensive question bank and improve your PRITE exam performance."}),u.jsx(Tn,{primary:!0,as:"a",href:"/subscription",children:"Subscribe Now"})]})]})},RS=k.div`
  max-width: 800px;
  margin: 5rem auto;
  padding: 0 1rem;
  text-align: center;
`,$S=k.h1`
  font-size: 3rem;
  color: ${e=>e.theme.colors.primary};
  margin-bottom: 1.5rem;
`,_S=k.p`
  font-size: 1.2rem;
  color: ${e=>e.theme.colors.textLight};
  margin-bottom: 2rem;
`,NS=k(ct)`
  display: inline-block;
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.75rem 1.5rem;
  border-radius: 4px;
  font-weight: 600;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
    color: white;
  }
`,OS=()=>u.jsxs(RS,{children:[u.jsx($S,{children:"404 - Page Not Found"}),u.jsx(_S,{children:"The page you are looking for doesn't exist or has been moved."}),u.jsx(NS,{to:"/",children:"Return to Home"})]}),AS=k.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  font-size: 1.2rem;
  color: ${e=>e.theme.colors.primary};
`,Ko=({children:e})=>{const{currentUser:t,loading:n}=Ct();return n?u.jsx(AS,{children:u.jsx("p",{children:"Loading..."})}):t?e:u.jsx(bv,{to:"/login",replace:!0})},LS=k.header`
  background-color: white;
  box-shadow: ${e=>e.theme.shadows.small};
  padding: 1rem 0;
  position: sticky;
  top: 0;
  z-index: 100;
`,zS=k.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
`,DS=k(ct)`
  font-size: 1.5rem;
  font-weight: 700;
  color: ${e=>e.theme.colors.primary};
  display: flex;
  align-items: center;
  
  span {
    color: ${e=>e.theme.colors.secondary};
  }
`,IS=k.nav`
  display: flex;
  align-items: center;
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    display: ${e=>e.isOpen?"flex":"none"};
    flex-direction: column;
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background-color: white;
    box-shadow: ${e=>e.theme.shadows.medium};
    padding: 1rem;
  }
`,Go=k(ct)`
  margin: 0 1rem;
  font-weight: 500;
  color: ${e=>e.theme.colors.text};
  position: relative;
  
  &:after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 2px;
    background-color: ${e=>e.theme.colors.primary};
    transition: width 0.3s ease;
  }
  
  &:hover:after, &.active:after {
    width: 100%;
  }
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    margin: 0.5rem 0;
  }
`,zd=k.div`
  display: flex;
  align-items: center;
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    flex-direction: column;
    width: 100%;
    margin-top: 1rem;
  }
`,FS=k(ct)`
  margin-right: 1rem;
  font-weight: 500;
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    margin: 0.5rem 0;
  }
`,MS=k(ct)`
  background-color: ${e=>e.theme.colors.primary};
  color: white;
  padding: 0.5rem 1.5rem;
  border-radius: 4px;
  font-weight: 500;
  transition: background-color 0.3s ease;
  
  &:hover {
    background-color: ${e=>e.theme.colors.primaryDark};
    color: white;
  }
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    width: 100%;
    text-align: center;
    margin-top: 0.5rem;
  }
`,BS=k.button`
  background: none;
  border: none;
  color: ${e=>e.theme.colors.text};
  font-weight: 500;
  cursor: pointer;
  padding: 0;
  
  &:hover {
    color: ${e=>e.theme.colors.primary};
  }
`,US=k.button`
  display: none;
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  
  @media (max-width: ${e=>e.theme.breakpoints.tablet}) {
    display: block;
  }
`,HS=()=>{const[e,t]=Ee.useState(!1),{currentUser:n,logout:r}=Ct(),o=wo(),i=()=>{r(),o("/")},s=()=>{t(!e)};return u.jsx(LS,{children:u.jsxs(zS,{children:[u.jsxs(DS,{to:"/",children:["Cortex",u.jsx("span",{children:"Q"})]}),u.jsx(US,{onClick:s,children:e?"✕":"☰"}),u.jsxs(IS,{isOpen:e,children:[u.jsx(Go,{to:"/",children:"Home"}),u.jsx(Go,{to:"/strategies",children:"Strategies"}),u.jsx(Go,{to:"/practice",children:"Practice"}),n?u.jsxs(u.Fragment,{children:[u.jsx(Go,{to:"/dashboard",children:"Dashboard"}),u.jsx(zd,{children:u.jsx(BS,{onClick:i,children:"Logout"})})]}):u.jsxs(zd,{children:[u.jsx(FS,{to:"/login",children:"Login"}),u.jsx(MS,{to:"/register",children:"Sign Up"})]})]})]})})},WS=k.footer`
  background-color: ${e=>e.theme.colors.backgroundDark};
  padding: 3rem 0 1.5rem;
  margin-top: 3rem;
`,qS=k.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
`,Yo=k.div`
  h3 {
    font-size: 1.2rem;
    margin-bottom: 1.5rem;
    color: ${e=>e.theme.colors.primary};
  }
`,QS=k.div`
  font-size: 1.8rem;
  font-weight: 700;
  margin-bottom: 1rem;
  color: ${e=>e.theme.colors.primary};
  
  span {
    color: ${e=>e.theme.colors.secondary};
  }
`,Dd=k.ul`
  list-style: none;
  padding: 0;
  
  li {
    margin-bottom: 0.75rem;
  }
  
  a {
    color: ${e=>e.theme.colors.text};
    transition: color 0.3s ease;
    
    &:hover {
      color: ${e=>e.theme.colors.primary};
    }
  }
`,VS=k.div`
  max-width: 1200px;
  margin: 2rem auto 0;
  padding: 1.5rem 1rem 0;
  border-top: 1px solid ${e=>e.theme.colors.border};
  text-align: center;
  font-size: 0.9rem;
  color: ${e=>e.theme.colors.textLight};
`,KS=()=>u.jsxs(WS,{children:[u.jsxs(qS,{children:[u.jsxs(Yo,{children:[u.jsxs(QS,{children:["Cortex",u.jsx("span",{children:"Q"})]}),u.jsx("p",{children:"The ultimate platform for psychiatry residents preparing for board exams."})]}),u.jsxs(Yo,{children:[u.jsx("h3",{children:"Quick Links"}),u.jsxs(Dd,{children:[u.jsx("li",{children:u.jsx("a",{href:"/",children:"Home"})}),u.jsx("li",{children:u.jsx("a",{href:"/strategies",children:"Strategies"})}),u.jsx("li",{children:u.jsx("a",{href:"/practice",children:"Practice Questions"})}),u.jsx("li",{children:u.jsx("a",{href:"/subscription",children:"Subscription Plans"})})]})]}),u.jsxs(Yo,{children:[u.jsx("h3",{children:"Resources"}),u.jsxs(Dd,{children:[u.jsx("li",{children:u.jsx("a",{href:"/dashboard",children:"Dashboard"})}),u.jsx("li",{children:u.jsx("a",{href:"/strategies",children:"PRITE Exam Strategies"})}),u.jsx("li",{children:u.jsx("a",{href:"/practice",children:"Practice Questions"})})]})]}),u.jsxs(Yo,{children:[u.jsx("h3",{children:"Contact"}),u.jsx("p",{children:"Email: support@cortexq.com"})]})]}),u.jsx(VS,{children:u.jsxs("p",{children:["© ",new Date().getFullYear()," CortexQ. All rights reserved."]})})]}),GS=k.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`,YS=k.main`
  flex: 1;
`,XS=()=>u.jsxs(GS,{children:[u.jsx(HS,{}),u.jsx(YS,{children:u.jsx(Tv,{})}),u.jsx(KS,{})]});function JS(){return u.jsxs(F0,{theme:W0,children:[u.jsx(H0,{}),u.jsx($v,{children:u.jsxs(ot,{path:"/",element:u.jsx(XS,{}),children:[u.jsx(ot,{index:!0,element:u.jsx(Nw,{})}),u.jsx(ot,{path:"login",element:u.jsx(Fw,{})}),u.jsx(ot,{path:"register",element:u.jsx(Vw,{})}),u.jsx(ot,{path:"dashboard",element:u.jsx(Ko,{children:u.jsx(ax,{})})}),u.jsx(ot,{path:"subscription",element:u.jsx(Ko,{children:u.jsx(Ux,{})})}),u.jsx(ot,{path:"strategies",element:u.jsx(Ko,{children:u.jsx(sS,{})})}),u.jsx(ot,{path:"practice",element:u.jsx(Ko,{children:u.jsx(TS,{})})}),u.jsx(ot,{path:"*",element:u.jsx(OS,{})})]})})]})}yl.createRoot(document.getElementById("root")).render(u.jsx(Ee.StrictMode,{children:u.jsx(Dv,{children:u.jsx(Sw,{children:u.jsx(kw,{children:u.jsx(JS,{})})})})}));
